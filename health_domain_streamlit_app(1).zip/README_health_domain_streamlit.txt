Health Domain Configuration - Snowflake Streamlit

1. Create or open a Streamlit app in Snowflake.
2. Replace the generated Python code with streamlit_app.py.
3. Ensure the app role has SELECT on DSE_JOB_CONFIG and DSE_TESTPLAN.
4. Ensure the app role has SELECT, INSERT, UPDATE on DSE_HEALTH_DOMAIN.
5. Update the three table constants at the top of streamlit_app.py if fully-qualified names are needed.

Expected DSE_TESTPLAN columns:
JOBID, DSID, TESTCASEDESCRIPTION, ACT_IND, ENVIRONMENT_ID

The UI generates ASSOCIATED_JOBS JSON internally. Business users do not enter JSON.
