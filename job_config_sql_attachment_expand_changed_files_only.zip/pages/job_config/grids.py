
from src.pages.utils.src_agstyler import draw_grid


class Color:
    RED_LIGHT = "#fcccbb"
    GREEN_LIGHT = "#abf7b1"

    BLUE = "#8ecae6"
    GREEN = "#219ebc"
    ORANGE = "#ffb703"
    PINK_RED = "#fb8500"


SQL_ATTACHMENT_GRID_STYLE = {
    'editable': True,
    'wrapText': True,
    'autoHeight': True,
    'width': 520,
    'minWidth': 420,
    'cellStyle': {'whiteSpace': 'pre-line', 'lineHeight': '18px'},
    'cellEditor': 'agLargeTextCellEditor',
    'cellEditorPopup': True,
    'cellEditorParams': {
        'maxLength': 10000,
        'rows': 12,
        'cols': 90,
    },
}


def job_config_edit_grid(df, cbox: bool = False, key=''):
    key = f"Job Config : editable : {key}"

    formatter = {
        'JOBID': ('JOBID', {'editable': False}),
        'JOBNAME': ('JOBNAME', {'editable': True}),
        'JOBDESCRIPTION': ('JOBDESCRIPTION', {'editable': True}),
        'EXECUTIONSTEP': ('EXECUTIONTYPE', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': ['POST-CHECK', 'PRE-CHECK', 'None']}
        }),
        'EMAILTO': ('EMAILTO', {'editable': True}),
        'FAILUREEMAILTO': ('FAILUREEMAILTO', {'editable': True}),
        'JOB_FAILED_QUERY': ('SQL_ATTACHMENT', SQL_ATTACHMENT_GRID_STYLE),
        'JOBTIMEOUT': ('JOBTIMEOUT', {'editable': True}),
        'FORCEFAIL': ('FORCEFAIL', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': ["ON", "OFF", 'None']}
        }),


        'PROD': ('PROD', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': [False, True]}
        }),
        'STAGE': ('STAGE', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': [False, True]}
        }),
        'DEV': ('DEV', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': [False, True]}
        }),
    }
    grid_options = None
    custom_css = None
    selection = 'multiple'
    use_checkbox = cbox

    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=True,
        auto_height=True,
        pagination=True,
        max_height=650
    )


def job_config_select_grid(df, cbox: bool = False, key=''):
    key = f"Job Config : select : {key}"

    formatter = {
        'JOBID': ('JOBID', {'editable': False}),
        'JOBNAME': ('JOBNAME', {'editable': False}),
        'JOBDESCRIPTION': ('JOBDESCRIPTION', {'editable': False}),
        'EXECUTIONSTEP': ('EXECUTIONTYPE', {'editable': False}),
        'EMAILTO': ('EMAILTO', {'editable': False}),
        'FAILUREEMAILTO': ('FAILUREEMAILTO', {'editable': False}),
        'JOBTIMEOUT': ('JOBTIMEOUT', {'editable': False}),
        'FORCEFAIL': ('FORCEFAIL', {'editable': True}),
    }
    grid_options = None
    custom_css = None
    selection = 'single'
    use_checkbox = cbox

    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=False,
        auto_height=True,
        pagination=True
    )


def job_config_final_grid(df, key=''):
    key = f"Job Config : final : {key}"

    formatter = {
        'JOBID': ('JOBID', {'editable': False}),
        'JOBNAME': ('JOBNAME', {'editable': True}),
        'JOBDESCRIPTION': ('JOBDESCRIPTION', {'editable': False}),
        'EXECUTIONSTEP': ('EXECUTIONTYPE', {'editable': False}),
        'EMAILTO': ('EMAILTO', {'editable': False}),
        'FAILUREEMAILTO': ('FAILUREEMAILTO', {'editable': False}),
        'JOB_FAILED_QUERY': ('SQL_ATTACHMENT', SQL_ATTACHMENT_GRID_STYLE),
        'JOBTIMEOUT': ('JOBTIMEOUT', {'editable': False}),
        'FORCEFAIL': ('FORCEFAIL', {'editable': False}),
        'PROD': ('PROD', {'editable': False}),
        'STAGE': ('STAGE', {'editable': False}),
        'DEV': ('DEV', {'editable': False}),
    }
    grid_options = {
        'rowClassRules': {
            'deleted-rows': "data.COLOR_FLAG == 'deleted'",
            'edited-rows': "data.COLOR_FLAG == 'edited'",
            'added-rows': "data.COLOR_FLAG == 'added'"
        }
    }

    custom_css = {
        '.deleted-rows': {'background-color': Color.RED_LIGHT},
        '.edited-rows': {'background-color': Color.GREEN_LIGHT},
        '.added-rows': {'background-color': Color.BLUE},
        # '.ag.background-color': Color.GREEN,
    }
    selection = 'multiple'
    use_checkbox = False
    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=True,
        auto_height=True,
        pagination=True,
        max_height=650,
    )


def job_config_edit_grid_athena(df, cbox: bool = False, key=''):
    key = f"Job Config : editable : {key}"

    formatter = {
        'JOBID': ('JOBID', {'editable': False}),
        'JOBNAME': ('JOBNAME', {'editable': True}),
        'JOBDESCRIPTION': ('JOBDESCRIPTION', {'editable': True}),
        'EXECUTIONSTEP': ('EXECUTIONTYPE', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': ['POST-CHECK', 'PRE-CHECK', 'None']}
        }),
        'EMAILTO': ('EMAILTO', {'editable': True}),
        'FAILUREEMAILTO': ('FAILUREEMAILTO', {'editable': True}),
        'JOBTIMEOUT': ('JOBTIMEOUT', {'editable': True}),
        'FORCEFAIL': ('FORCEFAIL', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': ["ON", "OFF", 'None']}
        }),

        'AWS_ACCESS_KEY_ID': ('AWS_ACCESS_KEY_ID', {'editable': True}),
        'AWS_SECRET_ACCESS_KEY': ('AWS_SECRET_ACCESS_KEY', {'editable': True}),
        'AWS_S3_BUCKET_DIR': ('AWS_S3_BUCKET_DIR', {'editable': True}),
        'AWS_REGION_NAME': ('AWS_REGION_NAME', {'editable': True}),
        'AWS_SCHEMA_NAME': ('AWS_SCHEMA_NAME', {'editable': True}),
    }
    grid_options = None
    custom_css = None
    selection = 'multiple'
    use_checkbox = cbox

    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=False,
        auto_height=True,
        pagination=True
    )


def job_config_final_grid_athena(df, key=''):
    key = f"Job Config : final : {key}"

    formatter = {
        'JOBID': ('JOBID', {'editable': False}),
        'JOBNAME': ('JOBNAME', {'editable': True}),
        'JOBDESCRIPTION': ('JOBDESCRIPTION', {'editable': False}),
        'EXECUTIONSTEP': ('EXECUTIONTYPE', {'editable': False}),
        'EMAILTO': ('EMAILTO', {'editable': False}),
        'FAILUREEMAILTO': ('FAILUREEMAILTO', {'editable': False}),
        'JOBTIMEOUT': ('JOBTIMEOUT', {'editable': False}),
        'FORCEFAIL': ('FORCEFAIL', {'editable': False}),

        'AWS_ACCESS_KEY_ID': ('AWS_ACCESS_KEY_ID', {'editable': False}),
        'AWS_SECRET_ACCESS_KEY': ('AWS_SECRET_ACCESS_KEY', {'editable': False}),
        'AWS_S3_BUCKET_DIR': ('AWS_S3_BUCKET_DIR', {'editable': False}),
        'AWS_REGION_NAME': ('AWS_REGION_NAME', {'editable': False}),
        'AWS_SCHEMA_NAME': ('AWS_SCHEMA_NAME', {'editable': False}),
    }
    grid_options = {
        'rowClassRules': {
            'deleted-rows': "data.COLOR_FLAG == 'deleted'",
            'edited-rows': "data.COLOR_FLAG == 'edited'",
            'added-rows': "data.COLOR_FLAG == 'added'"
        }
    }

    custom_css = {
        '.deleted-rows': {'background-color': Color.RED_LIGHT},
        '.edited-rows': {'background-color': Color.GREEN_LIGHT},
        '.added-rows': {'background-color': Color.BLUE},
        # '.ag.background-color': Color.GREEN,
    }
    selection = 'multiple'
    use_checkbox = False
    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=False,
        auto_height=True,
        pagination=True,
    )
