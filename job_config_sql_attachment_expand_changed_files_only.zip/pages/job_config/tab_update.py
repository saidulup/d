
import random
import json
import streamlit as st
from streamlit import session_state as sst
import numpy as np
import pandas as pd

from src.pages.data_utils import get_job_config_table, product_warehouse_status
from src.pages.job_config.grids import *
from src.pages.job_config.db import update_job_config, get_job_env_states, generate_job_id
import time


SQL_ATTACHMENT_FORMAT_EXAMPLE = '''[
  {
    "name": "tab1",
    "query": "select 1"
  },
  {
    "name": "tab2",
    "query": "select 2"
  }
]'''
SQL_ATTACHMENT_SAMPLE = SQL_ATTACHMENT_FORMAT_EXAMPLE
SQL_ATTACHMENT_SAMPLE_OBJECT = [
    {"name": "tab1", "query": "select 1"},
    {"name": "tab2", "query": "select 2"},
]


def _is_empty_value(value):
    if pd.isna(value):
        return True
    return str(value).strip().lower() in {'', 'none', 'nan', 'nat'}


def _is_sql_attachment_sample(value):
    if _is_empty_value(value):
        return False

    value = str(value).strip()
    if value == SQL_ATTACHMENT_SAMPLE:
        return True

    try:
        return json.loads(value) == SQL_ATTACHMENT_SAMPLE_OBJECT
    except Exception:
        return False


def display_sql_attachment_sample(value):
    if _is_empty_value(value):
        return SQL_ATTACHMENT_SAMPLE
    return value


def normalize_sql_attachment_for_save(value):
    if _is_empty_value(value) or _is_sql_attachment_sample(value):
        return None
    return str(value).strip()


def validate_sql_attachment(value):
    value = normalize_sql_attachment_for_save(value)
    if value is None:
        return True, None

    try:
        parsed_value = json.loads(value)
    except json.JSONDecodeError:
        return False, 'SQL_ATTACHMENT must be valid JSON.'

    if not isinstance(parsed_value, list) or len(parsed_value) == 0:
        return False, 'SQL_ATTACHMENT must be a non-empty JSON array.'

    for item in parsed_value:
        if not isinstance(item, dict):
            return False, 'Each SQL_ATTACHMENT entry must be a JSON object.'
        if 'name' not in item or 'query' not in item:
            return False, 'Each SQL_ATTACHMENT entry must have name and query fields.'
        if str(item.get('name', '')).strip() == '' or str(item.get('query', '')).strip() == '':
            return False, 'SQL_ATTACHMENT name and query cannot be empty when saving an attachment.'

    return True, None


def get_sql_attachment_validation_errors(df):
    failed_records = []
    for index, row in df.iterrows():
        is_valid, error_message = validate_sql_attachment(row.get('JOB_FAILED_QUERY'))
        if not is_valid:
            failed_records.append({
                'ROW': index + 1,
                'JOBID': row.get('JOBID'),
                'JOBNAME': row.get('JOBNAME'),
                'SQL_ATTACHMENT': row.get('JOB_FAILED_QUERY'),
                'ERROR': error_message,
            })
    return failed_records


def fetch_job_environments(jobid, env_table):
    job_envs = env_table[env_table['JOBID'] == str(jobid)]['ENVIRONEMNT_ID'].tolist()
    job_envs = [str(x).lower() for x in job_envs]
    prod_flag = False
    stg_flag = False
    dev_flag = False
    if '1' in job_envs:
        prod_flag = True
    if '2' in job_envs:
        stg_flag = True
    if '3' in job_envs:
        dev_flag = True
    return prod_flag, stg_flag, dev_flag

@st.fragment()
def render_ac_job_config(product_id, product_name, product_data_domain, product_db, product_warehouse, random_id):
    tab_key = 'ac-jobconfig' + str(random_id)

    st.text(' ')
    warehouse_status = product_warehouse_status(product_warehouse)
    database_status = 'Not Found' if str(product_db).lower() in ['none', 'nan', ''] else ''
    st.markdown(f"""
    ###### Product Id : :blue[{product_id}], Product Name : :blue[{product_name}], Data Domain : :blue[{product_data_domain}], Warehouse : :blue[{product_warehouse} {warehouse_status}]
    """)
    st.markdown(f"##### :blue[Job Config Table]")

    if sst.get('jc_env_table') is None:
        with st.spinner('Loading...'):
            env_table = get_job_env_states(product_warehouse)
            sst['jc_env_table'] = env_table # environment table
    env_table = sst['jc_env_table']

    if sst.get('disp_job_config') is None:
        with st.spinner('Loading...'):
            job_config_df = get_job_config_table(product_id, product_warehouse)
            job_config_df['JOB_FAILED_QUERY'] = job_config_df['JOB_FAILED_QUERY'].apply(display_sql_attachment_sample)

            job_config_df['COLOR_FLAG'] = 'edited'
            job_config_df['PROD'] = False
            job_config_df['STAGE'] = False
            job_config_df['DEV'] = False

            for index, row in job_config_df.iterrows():
                prod_flag, stg_flag, dev_flag = fetch_job_environments(row['JOBID'], env_table)
                job_config_df.at[index, 'PROD'] = prod_flag
                job_config_df.at[index, 'STAGE'] = stg_flag
                job_config_df.at[index, 'DEV'] = dev_flag

        disp_job_config = job_config_df
        sst['disp_job_config'] = disp_job_config.sort_values(by=['JOBID'], ascending=False)
        sst['disp_job_config_key'] = f'{tab_key} : display job config grid : {random.randint(0, 1000)}'

    disp_job_config = sst['disp_job_config']
    disp_job_config_key = sst.get('disp_job_config_key')

    grid_edit_job_config = job_config_edit_grid(
        disp_job_config,
        cbox=True,
        key=disp_job_config_key
    )
    add_col, duplicate_col, _ = st.columns([1, 1, 6], gap='small')
    with add_col:
        on_add = st.button('➕ :green[Add]', use_container_width=True)
        if on_add:
            temp_df = grid_edit_job_config['data'].replace("None", np.nan)
            start_jobid = generate_job_id()
            nrows, ncols = temp_df.shape
            temp_df.loc[nrows] = [""] * ncols
            temp_df.loc[nrows, 'JOBID'] = start_jobid
            # set prod, stage, dev flags
            temp_df.loc[nrows, 'PROD'] = True
            temp_df.loc[nrows, 'STAGE'] = True
            temp_df.loc[nrows, 'DEV'] = True
            temp_df.loc[nrows, 'JOB_FAILED_QUERY'] = SQL_ATTACHMENT_SAMPLE

            temp_df.loc[nrows, 'COLOR_FLAG'] = 'added'
            temp_df['JOBID'] = temp_df['JOBID'].astype('int64')

            sst['disp_job_config'] = temp_df.sort_values(by=['JOBID'], ascending=False)
            sst['disp_job_config_key'] = f'{tab_key} : display job config grid : {random.randint(0, 1000)}'
            st.rerun()

    with duplicate_col:
        on_duplicate = st.button('📄 Duplicate', use_container_width=True)
        if on_duplicate:
            temp_df = grid_edit_job_config['data'].replace("None", np.nan)
            drecord = temp_df.iloc[0].to_frame().T.reset_index(drop=True)
            temp_df = pd.concat([drecord, temp_df], ignore_index=True).reset_index(drop=True)
            start_jobid = generate_job_id()

            temp_df.loc[0, 'JOBID'] = start_jobid
            temp_df.loc[0, 'COLOR_FLAG'] = 'added'
            temp_df['JOBID'] = temp_df['JOBID'].astype('int64')
            sst['disp_job_config'] = temp_df.sort_values(by=['JOBID'], ascending=False)
            sst['disp_job_config_key'] = f'{tab_key} : display job config grid : {random.randint(0, 1000)}'
            st.rerun()

    srows_edit_job_config = grid_edit_job_config['selected_rows']
    if len(srows_edit_job_config) > 0:
        edited_rows = pd.DataFrame(srows_edit_job_config).drop(columns=['_selectedRowNodeInfo'])
        save_jc_data = edited_rows

        sst['unsaved_job_config_changes'] = len(save_jc_data)
        # compare whether the dataframes are same
        if not save_jc_data.equals(sst.get('final_jc_data', pd.DataFrame())):
            sst['final_jc_data'] = save_jc_data
            sst['final_jc_data_key'] = f'{tab_key} : final job config grid : {random.randint(0, 1000)}'

        final_jc_data = sst['final_jc_data']
        final_jc_data_key = sst['final_jc_data_key']

        final_jc_data = job_config_final_grid(final_jc_data, key=final_jc_data_key)
        final_jc_data = pd.DataFrame(final_jc_data['data'])

        if len(final_jc_data) > 0:
            if warehouse_status == 'Not Found' or database_status == 'Not Found':
                st.markdown(f"Databases : :blue[{product_db} {database_status}], Warehouse : :blue[{product_warehouse} {warehouse_status}]")
                st.warning(f"Cannot Save changes")
            else:
                save_col, cancel_col, _ = st.columns([1, 1, 6], gap='small')
                with cancel_col:
                    on_cancel = st.button('❌ :red[Cancel]', use_container_width=True)
                    if on_cancel:
                        sst['disp_job_config'] = None
                        sst['disp_job_config_key'] = f'{tab_key} : display job config grid : {random.randint(0, 1000)}'
                        st.rerun()
                with save_col:
                    submit_update = st.button('💾 Save', key=f"{tab_key}_update_job_config", use_container_width=True)
                if submit_update:
                    # save_jc_data.to_csv('jconfig.csv', index=False)
                    # set selected values for newly added records
                    final_jc_data['PRODUCT_ID'] = product_id

                    validation_errors = get_sql_attachment_validation_errors(final_jc_data)
                    if len(validation_errors) > 0:
                        st.error('SQL_ATTACHMENT must be valid JSON in the expected format.')
                        st.code(SQL_ATTACHMENT_FORMAT_EXAMPLE, language='json')
                        st.dataframe(pd.DataFrame(validation_errors), hide_index=True)
                        return

                    with st.spinner():
                        # The sample JSON is only a display helper. If user did not change it, save NULL/empty.
                        final_jc_data['JOB_FAILED_QUERY'] = final_jc_data['JOB_FAILED_QUERY'].apply(normalize_sql_attachment_for_save)

                        status, msg = update_job_config(
                            final_jc_data,
                            product_db,
                            product_warehouse
                        )
                    if status == 'Success':
                        st.success('Records Successfully Updated')
                        # st.dataframe(save_jc_data, hide_index=True)
                        with st.spinner('Reloading in 5 sec'):
                            time.sleep(5)
                            # reload_page('Success', 5)
                            reset_states = [
                                'disp_job_config',
                                'disp_job_config_key',
                                'jc_env_table',
                                'unsaved_job_config_changes',
                                'final_jc_data',
                                'final_jc_data_key',
                            ]
                            for state in reset_states:
                                if sst.get(state) is not None:
                                    del sst[state]
                            st.rerun()

                    else:
                        st.warning('The following error occurred while updating the records')
                        st.dataframe(msg['failed_records'])