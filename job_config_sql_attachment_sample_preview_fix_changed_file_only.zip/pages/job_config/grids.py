from st_aggrid.shared import JsCode

from src.pages.utils.src_agstyler import draw_grid


class Color:
    RED_LIGHT = "#fcccbb"
    GREEN_LIGHT = "#abf7b1"

    BLUE = "#8ecae6"
    GREEN = "#219ebc"
    ORANGE = "#ffb703"
    PINK_RED = "#fb8500"


SQL_ATTACHMENT_CELL_EDITOR_SELECTOR = JsCode("""
function(params) {
    const value = params.value == null ? '' : String(params.value);
    const lineCount = value.split(/\r?\n/).length;
    const estimatedLines = Math.ceil(value.length / 110);
    const rows = Math.max(5, Math.min(24, Math.max(lineCount, estimatedLines)));
    const cols = value.length > 3000 ? 150 : (value.length > 1200 ? 125 : 95);

    return {
        component: 'agLargeTextCellEditor',
        popup: true,
        popupPosition: 'under',
        params: {
            maxLength: 1000000,
            rows: rows,
            cols: cols
        }
    };
}
""")


SQL_ATTACHMENT_PREVIEW_RENDERER = JsCode("""
function(params) {
    const rawValue = params.value == null ? '' : String(params.value);
    const value = rawValue.trim();

    if (!value) {
        return '';
    }

    // Show a short stable preview in the grid cell.
    // Full JSON/SQL is still kept in the cell value and opens in the editor.
    try {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed)) {
            const isSampleFormat = parsed.length === 2
                && parsed[0] && parsed[1]
                && String(parsed[0].name || '').trim().toLowerCase() === 'tab1'
                && String(parsed[0].query || '').trim().toLowerCase() === 'select 1'
                && String(parsed[1].name || '').trim().toLowerCase() === 'tab2'
                && String(parsed[1].query || '').trim().toLowerCase() === 'select 2';

            if (isSampleFormat) {
                return 'Sample JSON format - edit to add SQL attachment';
            }

            const names = parsed
                .map(function(item) { return item && item.name ? String(item.name).trim() : ''; })
                .filter(function(name) { return name.length > 0; });

            if (names.length > 0) {
                return names.join(', ');
            }
        }
    } catch (e) {
        // Not parseable for preview; fall back to compact plain text.
    }

    return value.replace(/\s+/g, ' ').substring(0, 300);
}
""")


SQL_ATTACHMENT_TOOLTIP_GETTER = JsCode("""
function(params) {
    return params.value == null ? '' : String(params.value);
}
""")


SQL_ATTACHMENT_GRID_STYLE = {
    'editable': True,
    # Keep normal compact grid view. Editor popup grows only when JSON/SQL is large.
    'width': 420,
    'minWidth': 300,
    'cellStyle': {
        'whiteSpace': 'nowrap',
        'overflow': 'hidden',
        'textOverflow': 'ellipsis',
    },
    'cellRenderer': SQL_ATTACHMENT_PREVIEW_RENDERER,
    'tooltipValueGetter': SQL_ATTACHMENT_TOOLTIP_GETTER,
    'cellEditorSelector': SQL_ATTACHMENT_CELL_EDITOR_SELECTOR,
}


SQL_ATTACHMENT_EDITOR_CSS = {
    '.ag-popup-editor': {
        'z-index': '99999 !important',
    },
    '.ag-large-text': {
        'max-width': '92vw !important',
        'max-height': '70vh !important',
    },
    '.ag-large-text-input': {
        'max-width': '90vw !important',
        'max-height': '68vh !important',
        'white-space': 'pre-wrap !important',
        'overflow-wrap': 'anywhere !important',
        'word-break': 'break-word !important',
        'overflow': 'auto !important',
        'resize': 'both !important',
        'font-family': 'monospace !important',
        'font-size': '12px !important',
        'line-height': '1.35 !important',
    },
    '.ag-large-text textarea': {
        'max-width': '90vw !important',
        'max-height': '68vh !important',
        'white-space': 'pre-wrap !important',
        'overflow-wrap': 'anywhere !important',
        'word-break': 'break-word !important',
        'overflow': 'auto !important',
        'resize': 'both !important',
        'font-family': 'monospace !important',
        'font-size': '12px !important',
        'line-height': '1.35 !important',
    },
    '.ag-popup-editor textarea': {
        'white-space': 'pre-wrap !important',
        'overflow-wrap': 'anywhere !important',
        'word-break': 'break-word !important',
        'overflow': 'auto !important',
    },
}


def job_config_edit_grid(df, cbox: bool = False, key=''):
    key = f"Job Config : editable : {key}"

    formatter = {
        'JOBID': ('JOBID', {'editable': False}),
        'JOBNAME': ('JOBNAME', {'editable': True}),
        'JOBDESCRIPTION': ('JOBDESCRIPTION', {'editable': True}),
        'EXECUTIONSTEP': ('EXECUTIONTYPE', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': ['POST-CHECK', 'PRE-CHECK', 'None']}
        }),
        'EMAILTO': ('EMAILTO', {'editable': True}),
        'FAILUREEMAILTO': ('FAILUREEMAILTO', {'editable': True}),
        'JOB_FAILED_QUERY': ('SQL_ATTACHMENT', SQL_ATTACHMENT_GRID_STYLE),
        'JOBTIMEOUT': ('JOBTIMEOUT', {'editable': True}),
        'FORCEFAIL': ('FORCEFAIL', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': ["ON", "OFF", 'None']}
        }),


        'PROD': ('PROD', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': [False, True]}
        }),
        'STAGE': ('STAGE', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': [False, True]}
        }),
        'DEV': ('DEV', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': [False, True]}
        }),
    }
    grid_options = {
        # Close SQL_ATTACHMENT popup editor when user clicks outside the grid.
        'stopEditingWhenCellsLoseFocus': True,
    }
    custom_css = SQL_ATTACHMENT_EDITOR_CSS.copy()
    selection = 'multiple'
    use_checkbox = cbox

    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=False,
        auto_height=False,
        pagination=True
    )


def job_config_select_grid(df, cbox: bool = False, key=''):
    key = f"Job Config : select : {key}"

    formatter = {
        'JOBID': ('JOBID', {'editable': False}),
        'JOBNAME': ('JOBNAME', {'editable': False}),
        'JOBDESCRIPTION': ('JOBDESCRIPTION', {'editable': False}),
        'EXECUTIONSTEP': ('EXECUTIONTYPE', {'editable': False}),
        'EMAILTO': ('EMAILTO', {'editable': False}),
        'FAILUREEMAILTO': ('FAILUREEMAILTO', {'editable': False}),
        'JOBTIMEOUT': ('JOBTIMEOUT', {'editable': False}),
        'FORCEFAIL': ('FORCEFAIL', {'editable': True}),
    }
    grid_options = None
    custom_css = None
    selection = 'single'
    use_checkbox = cbox

    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=False,
        auto_height=True,
        pagination=True
    )


def job_config_final_grid(df, key=''):
    key = f"Job Config : final : {key}"

    formatter = {
        'JOBID': ('JOBID', {'editable': False}),
        'JOBNAME': ('JOBNAME', {'editable': True}),
        'JOBDESCRIPTION': ('JOBDESCRIPTION', {'editable': False}),
        'EXECUTIONSTEP': ('EXECUTIONTYPE', {'editable': False}),
        'EMAILTO': ('EMAILTO', {'editable': False}),
        'FAILUREEMAILTO': ('FAILUREEMAILTO', {'editable': False}),
        'JOB_FAILED_QUERY': ('SQL_ATTACHMENT', SQL_ATTACHMENT_GRID_STYLE),
        'JOBTIMEOUT': ('JOBTIMEOUT', {'editable': False}),
        'FORCEFAIL': ('FORCEFAIL', {'editable': False}),
        'PROD': ('PROD', {'editable': False}),
        'STAGE': ('STAGE', {'editable': False}),
        'DEV': ('DEV', {'editable': False}),
    }
    grid_options = {
        # Close SQL_ATTACHMENT popup editor when user clicks outside the grid.
        'stopEditingWhenCellsLoseFocus': True,
        'rowClassRules': {
            'deleted-rows': "data.COLOR_FLAG == 'deleted'",
            'edited-rows': "data.COLOR_FLAG == 'edited'",
            'added-rows': "data.COLOR_FLAG == 'added'"
        }
    }

    custom_css = {
        '.deleted-rows': {'background-color': Color.RED_LIGHT},
        '.edited-rows': {'background-color': Color.GREEN_LIGHT},
        '.added-rows': {'background-color': Color.BLUE},
        # '.ag.background-color': Color.GREEN,
    }
    custom_css.update(SQL_ATTACHMENT_EDITOR_CSS)
    selection = 'multiple'
    use_checkbox = False
    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=False,
        auto_height=False,
        pagination=True
    )


def job_config_edit_grid_athena(df, cbox: bool = False, key=''):
    key = f"Job Config : editable : {key}"

    formatter = {
        'JOBID': ('JOBID', {'editable': False}),
        'JOBNAME': ('JOBNAME', {'editable': True}),
        'JOBDESCRIPTION': ('JOBDESCRIPTION', {'editable': True}),
        'EXECUTIONSTEP': ('EXECUTIONTYPE', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': ['POST-CHECK', 'PRE-CHECK', 'None']}
        }),
        'EMAILTO': ('EMAILTO', {'editable': True}),
        'FAILUREEMAILTO': ('FAILUREEMAILTO', {'editable': True}),
        'JOBTIMEOUT': ('JOBTIMEOUT', {'editable': True}),
        'FORCEFAIL': ('FORCEFAIL', {
            'editable': True,
            'cellEditor': 'agSelectCellEditor',
            'cellEditorParams': {
                'values': ["ON", "OFF", 'None']}
        }),

        'AWS_ACCESS_KEY_ID': ('AWS_ACCESS_KEY_ID', {'editable': True}),
        'AWS_SECRET_ACCESS_KEY': ('AWS_SECRET_ACCESS_KEY', {'editable': True}),
        'AWS_S3_BUCKET_DIR': ('AWS_S3_BUCKET_DIR', {'editable': True}),
        'AWS_REGION_NAME': ('AWS_REGION_NAME', {'editable': True}),
        'AWS_SCHEMA_NAME': ('AWS_SCHEMA_NAME', {'editable': True}),
    }
    grid_options = None
    custom_css = None
    selection = 'multiple'
    use_checkbox = cbox

    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=False,
        auto_height=True,
        pagination=True
    )


def job_config_final_grid_athena(df, key=''):
    key = f"Job Config : final : {key}"

    formatter = {
        'JOBID': ('JOBID', {'editable': False}),
        'JOBNAME': ('JOBNAME', {'editable': True}),
        'JOBDESCRIPTION': ('JOBDESCRIPTION', {'editable': False}),
        'EXECUTIONSTEP': ('EXECUTIONTYPE', {'editable': False}),
        'EMAILTO': ('EMAILTO', {'editable': False}),
        'FAILUREEMAILTO': ('FAILUREEMAILTO', {'editable': False}),
        'JOBTIMEOUT': ('JOBTIMEOUT', {'editable': False}),
        'FORCEFAIL': ('FORCEFAIL', {'editable': False}),

        'AWS_ACCESS_KEY_ID': ('AWS_ACCESS_KEY_ID', {'editable': False}),
        'AWS_SECRET_ACCESS_KEY': ('AWS_SECRET_ACCESS_KEY', {'editable': False}),
        'AWS_S3_BUCKET_DIR': ('AWS_S3_BUCKET_DIR', {'editable': False}),
        'AWS_REGION_NAME': ('AWS_REGION_NAME', {'editable': False}),
        'AWS_SCHEMA_NAME': ('AWS_SCHEMA_NAME', {'editable': False}),
    }
    grid_options = {
        'rowClassRules': {
            'deleted-rows': "data.COLOR_FLAG == 'deleted'",
            'edited-rows': "data.COLOR_FLAG == 'edited'",
            'added-rows': "data.COLOR_FLAG == 'added'"
        }
    }

    custom_css = {
        '.deleted-rows': {'background-color': Color.RED_LIGHT},
        '.edited-rows': {'background-color': Color.GREEN_LIGHT},
        '.added-rows': {'background-color': Color.BLUE},
        # '.ag.background-color': Color.GREEN,
    }
    selection = 'multiple'
    use_checkbox = False
    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=False,
        auto_height=True,
        pagination=True,
    )
