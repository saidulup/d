
import os
import streamlit as st
from loguru import logger
from streamlit import session_state as sst
from streamlit_js_eval import streamlit_js_eval

APP_URL = os.environ.get('REDIRECT_URI')
JWT_COOKIE = os.environ.get('AUTH_COOKIE')

from src.auth.token import create_jwt_token, decode_jwt_token
from src.auth.cookie import set_cookie,get_cookie, del_cookie, disp_all_cookies


def on_login(user_data:dict):
    """ auth_type: snowflake, azure"""
    user_name = user_data.get('user_name')

    # No of days after which cookie should expire
    expiration_days = 1

    logger.info(f"Creating auth token {user_name}")
    token = create_jwt_token({'user_name': user_name, 'user_data': user_data}, expiration_days, 'day')

    logger.info(f"Storing auth cookie {JWT_COOKIE}")
    set_cookie(JWT_COOKIE, token, expiration_days, 'day')

    sst['user_name'] = user_name
    sst['user_data'] = user_data
    sst['login_status'] = True

    logger.info('User Logged in')
    st.success('User Logged in')


    # Rerun the app, removes all unnecessary data, loads user info freshly from cookies
    st.rerun()


def on_logout():
    # Remove cookies
    del_cookie(JWT_COOKIE)

    # Remove session state
    sst.clear()

    logout_url = f"{APP_URL}/.auth/logout"
    logger.info(f"Logout redirect url: {logout_url}")
    try:
        # Inject JavaScript to redirect

        # Run JavaScript to redirect
        js_code = f"window.location.href = '{logout_url}';"
        streamlit_js_eval(js_code, key="redirect")
    except Exception as e:
        logger.error("Error redirecting user to logout url")

    logger.info('User Logged out')
    st.success('User Logged out')
    st.rerun()


def check_login_status():
    disp_all_cookies()

    user_name = None
    user_data = None
    try:
        payload = decode_jwt_token(get_cookie(JWT_COOKIE))
        if payload.get('Error') is not None:
            login_status = False
            user_name = None
            user_data = None
        else:
            user_name = payload.get('user_name')
            user_name = payload.get('user_name')
            if user_name is not None:
                login_status = True
                user_data = payload.get('user_data')
            else:
                login_status = False
                user_name = None
                user_data = None
    except Exception as e:
        logger.error('Error in checking login status:')
        logger.error(e)
        login_status = False

    sst['login_status'] = login_status
    sst['user_name'] = user_name
    sst['user_data'] = user_data

    logger.info(f"User Login status: {login_status}, {user_name}")
    return login_status


def check_login_status2():
    sst['login_status'] = True
    sst['user_name'] = 'default'
    sst['user_data'] = 'default'
    return True
