import streamlit as st
from streamlit import session_state as sst
from src.auth.auth_functions import on_logout, on_login


def login_form():
    if not sst.get('login_status'):
        _, login_col, _ = st.columns([5, 4, 5])
        with login_col:
            with st.form(key='login form'):
                st.markdown('#### :blue[DSA Username]')
                user_name = st.text_input(
                    label='MSID',
                    placeholder='Enter your MSID',

                )
                submit_login = st.form_submit_button(
                    label='Submit',
                    use_container_width=True
                )

                if submit_login:
                    if not user_name:
                        st.error('Please enter your MSID')
                    else:
                        with st.spinner('Logging in ...'):
                            user_data = {'user_name': user_name}
                            on_login(user_data)


def logout_button():
    if sst.get('login_status'):
        if st.button('Logout', key='logout-user', use_container_width=True):
            st.button('Confirm Logout', key='confirm logout', use_container_width=True, on_click=on_logout)
            st.write(sst.get('user_name'))