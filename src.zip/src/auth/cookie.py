
import streamlit as st
from loguru import logger
from datetime import datetime, timedelta
import extra_streamlit_components as stx


@st.cache_resource()
def get_manager():
    return stx.CookieManager()


cookie_manager = get_manager()


def set_cookie(name, value, expiry_val=1, expiry_units='day'):
    if expiry_units == 'day':
        expires_at = datetime.now() + timedelta(days=expiry_val)
    elif expiry_units == 'hour':
        expires_at = datetime.now() + timedelta(hours=expiry_val)
    elif expiry_units == 'minute':
        expires_at = datetime.now() + timedelta(minutes=expiry_val)
    elif expiry_units == 'second':
        expires_at = datetime.now() + timedelta(seconds=expiry_val)
    else:
        logger.error(f"Invalid expiry unit: {expiry_units}")
        return False

    cookie_manager.set(
        cookie=name,
        val=value,
       expires_at=expires_at
    )

    logger.info(f"Cookie stored successfully: {name}")
    return True


def get_cookie(cookie_name):
    logger.info(f"Getting Cookie: {cookie_name}")
    # st.success(f'Geting Cookie')
    # st.text(f'Name: {cookie_name}')
    cookie = cookie_manager.get(cookie=cookie_name)
    # st.text(f'Data: {cookie}')
    return cookie


def del_cookie(cookie_name):
    cookie_manager.delete(cookie_name, key=cookie_name)
    # st.write(f'Deleted {cookie_name}')


def disp_all_cookies():
    cookie_manager.get_all()
    # st.markdown('#### All available Cookies')
    # st.write(cookie_manager.get_all())


# disp_all_cookies()
