
import os
from jose import jwt
from loguru import logger
from datetime import datetime, timedelta


SECRET_KEY = os.environ.get('JWT_SECRET_KEY')
ALGORITHM = os.environ.get('JWT_ALGORITHM')


def create_jwt_token(payload, expiry_value=1, expiry_units='day'):
    """Create a jwt token with the payload, upon successful login"""

    # Set the token expiration time
    if expiry_units == 'day':
        token_exp_min = expiry_value * 24 * 60
    elif expiry_units == 'hour':
        token_exp_min = expiry_value * 60
    elif expiry_units == 'minute':
        token_exp_min = expiry_value
    else:
        print(f"Invalid expiry unit: {expiry_units}")
        return False



    # In order to ensure cookie expires before payload
    token_exp_min = token_exp_min + 5

    expires_at = datetime.utcnow() + timedelta(minutes=token_exp_min)

    # Add the expiration time to the payload
    payload["exp"] = expires_at

    # Create the JWT token
    token = jwt.encode(payload, SECRET_KEY, ALGORITHM)
    # st.write(f'Token created: {token}')
    # Return the token as a string
    return token


def decode_jwt_token(token):
    """Decode the token and verify the signature"""
    if token is None:
        return {'Error': 'Token does not exist'}
    try:
        payload = jwt.decode(token, SECRET_KEY, ALGORITHM)
        return payload
    except jwt.ExpiredSignatureError:
        print("Token has expired.")
        return {'Error': 'Token Expired'}
    except jwt.JWTClaimsError:
        print("Invalid token signature.")
        return {'Error': 'Invalid Token'}

