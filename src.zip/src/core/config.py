

import os
from dotenv import load_dotenv

ROOT_PATH = os.environ.get('ROOT_PATH')
ENV_TYPE = os.environ.get('ENV_TYPE', 'prod').lower().strip()

file_path = ROOT_PATH+'/src/core/'+ENV_TYPE+'.env'
load_dotenv(dotenv_path=file_path, verbose=True)

SnowCreds = {
    'user': os.environ.get('SNOWFLAKE_USER'),
    'account': os.environ.get('SNOWFLAKE_ACCOUNT'),
    'role': os.environ.get('SNOWFLAKE_ROLE'),
    'warehouse': os.environ.get('SNOWFLAKE_WAREHOUSE'),
    'database': os.environ.get('SNOWFLAKE_DATABASE'),
    'password': os.environ.get('SNOWFLAKE_PASSWORD'),
    'pk_file': os.environ.get('SNOWFLAKE_PRIVATE_KEY'),
    'pk_password': os.environ.get('SNOWFLAKE_PRIVATE_KEY_PASSWORD'),
}

print(f"{ENV_TYPE} variables loaded successfully.")
