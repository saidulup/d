PRODUCT_CREATION_DL = [
    'saidulu.pagidimarry5@optum.com'
]

PRODUCT_OWNERS=['saidulu.pagidimarry5@optum.com']
