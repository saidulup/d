

from pyathena import connect
import pandas as pd


def validate_athena_connection(region, bucket, schema_name, access_key, secret_key):
    """Validate connection details for Athena using pyathena"""
    try:
        # Attempt to establish connection to Athena
        conn = connect(
            region_name=region,
            s3_staging_dir=bucket,
            schema_name=schema_name,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key
        )
        # Execute a simple query to validate connection
        query = f"SELECT distinct table_schema  FROM information_schema.tables WHERE table_schema = '{schema_name}'; "
        df = pd.read_sql(query, conn)
        if df.empty:
            raise Exception("Incorrect Schema")
        conn.close()
        return {
            "status": "success",
            "message": "Connection & Schema validation successful"
        }
    except Exception as e:
        print(f"Connection validation failed: {str(e)}")
        return {
            "status": "error",
            "message": f"Connection validation failed: {str(e)}"
        }
