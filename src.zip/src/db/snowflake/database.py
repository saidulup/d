
import streamlit as st
from snowflake.snowpark import Session
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import pandas as pd

import base64
from src.core.config import SnowCreds


@st.cache_resource(ttl=300)
def get_snowpark_session():
    """Session used irrespective of product"""
    connection_parameters = {
        "user": SnowCreds['user'],
        "account": SnowCreds['account'],
        "role": SnowCreds['role'],
        "warehouse": SnowCreds['warehouse'],
        "database": SnowCreds['database'],
    }
    if str(SnowCreds.get('password')).strip().lower() not in ['none', '']:
        connection_parameters.update({'password': SnowCreds['password']})
    else:
        connection_parameters.update({'private_key': rsa_key_decode(SnowCreds['pk_file'], SnowCreds['pk_password'])})

    # Create a session using default credentials
    #(connection_parameters['private_key'])
    session = Session.builder.configs(connection_parameters).create()

    # Use the secondary roles associated with the user
    session.sql('use secondary roles all;').collect()

    # ignore_case = """alter session set quoted_identifiers_ignore_case = true;"""
    # session.sql(ignore_case).collect()
    # print(session.sql("select current_database()").collect())

    return session


@st.cache_resource(ttl=300)
def get_snowpark_product_session(warehouse=None):
    """Session used for every product"""
    connection_parameters = {
        "user": SnowCreds['user'],
        "account": SnowCreds['account'],
        "role": SnowCreds['role'],
        "warehouse": SnowCreds['warehouse'],
        "database": SnowCreds['database'],
    }

    if str(SnowCreds.get('password')).strip().lower() not in ['none', '']:
        connection_parameters.update({'password': SnowCreds['password']})
    else:
        connection_parameters.update({'private_key': rsa_key_decode(SnowCreds['pk_file'], SnowCreds['pk_password'])})

    # Create a session using default credentials
    session = Session.builder.configs(connection_parameters).create()

    # Use the secondary roles associated with the user
    session.sql('use secondary roles all;').collect()

    # Format the value
    warehouse = str(warehouse).lower()

    # Switch to the provided warehouse
    try:
        session.use_warehouse(warehouse)
        print(f"Warehouse found : {warehouse}")
    except Exception as e:
        print(f"Warehouse : {warehouse} doesn't exist , Using default warehouse: {SnowCreds['warehouse']}")

    # ignore_case = """alter session set quoted_identifiers_ignore_case = true;"""
    # session.sql(ignore_case).collect()
    # print(session.sql("select current_database()").collect())

    return session


def rsa_key_decode(private_key_file: str, pk_password: str):
    try:
        base64_bytes = private_key_file.encode('ascii')
        decoded_string = base64.b64decode(base64_bytes)
        p_key = decoded_string.decode('ascii')
        p_key = serialization.load_pem_private_key(
            p_key.encode(),
            password= None if pk_password in {None, ''} else pk_password.encode(),
            backend=default_backend()
        )

        pkb = p_key.private_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption())
        return pkb
    except Exception as e:
        return private_key_file
