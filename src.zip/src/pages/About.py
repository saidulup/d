

import streamlit as st
from streamlit import session_state as sst


from src.pages.utils.console_components import back_button
from src.auth.auth_widgets import logout_button


st.set_page_config(layout="wide", initial_sidebar_state='collapsed')

page_key = 'job_config_page'
unsaved_changes_state = 'unsaved_job_config_changes'
page_states = []
back_page = 'pages/1_Admin_Console.py'


def main():
    # Logout Button
    with st.sidebar:
        logout_button()

    # Go Back button
    back_button(page_key, back_page, unsaved_changes_state, page_states)

    st.markdown(f"### ❄️ :blue[About DSE Admin Console]")
