import streamlit as st
from streamlit import session_state as sst
import extra_streamlit_components as stx
import datetime
import time
import pandas as pd


st.set_page_config(layout='wide')
st.write("# Cookie Manager")

@st.cache_resource(experimental_allow_widgets=True)
def get_manager():
    return stx.CookieManager()


cookie_manager = get_manager()

cookie_tab, state_tab = st.tabs(["Cookies", "State"])

with cookie_tab:
    select = cookie_manager.get_all(key='Test')
    df = pd.DataFrame(select.items(), columns=['Cookie', 'Value'])
    df['Select'] = False
    df = df[['Select', 'Cookie', 'Value']]

    edf = st.data_editor(
        data=df,
        hide_index=True,
        column_config={
            'Select': {'editable': True},
            'Cookie': {'editable': False},
            'Value': {'editable': False}
        }
    )

    selected_cookies = edf.loc[edf['Select'] == True]

    # Fetch and display the first selected Cookies
    if not selected_cookies.empty:
        cookie_data = cookie_manager.get(selected_cookies['Cookie'].tolist()[0])

        st.write("Selected Cookie Data:")
        st.write(cookie_data)

        # Button to delete the selected Cookies
        if st.button("Delete Selected Cookies"):
            for cookie in selected_cookies['Cookie'].tolist():
                cookie_manager.delete(cookie, key=cookie)
            st.write("Deleted Selected Cookies")
            time.sleep(3)
            st.rerun()


    with st.expander("Add Cookie"):
        st.subheader("Set Cookie:")
        cookie = st.text_input("Cookie", key="1")
        val = st.text_input("Value")
        if st.button("Add"):
            cookie_manager.set(cookie, val, expires_at=datetime.datetime(year=2026, month=5, day=27))
            st.write("Added Cookie")
            print('Added Cookie')
            print(cookie_manager.get_all())

            time.sleep(3)
            st.rerun()

with state_tab:
    st.markdown("#### All States")
    st.write(sst.to_dict())