
import pandas as pd
import numpy as np

df = pd.DataFrame({
    'col1': [1,2,3, None],
    'col2': [1,2,3, 4]
})

row = df.iloc[-1]

print(row['col1'] is np.nan, row['col1'] is None, row['col1'].is_na)