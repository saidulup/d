
import streamlit as st
from streamlit import session_state as sst


import random
from loguru import logger
from collections import defaultdict


from src.pages.data_utils import get_product_data
from src.pages.utils.elements import format_streamlit_page, hide_navbar
from src.auth.auth_widgets import logout_button

page_key = 'ac'
st.set_page_config(layout="wide", initial_sidebar_state='collapsed')



def nested_dict():
    return defaultdict(nested_dict)


@st.cache_data(ttl=120)
def product_search_index(product_data):
    logger.info('Building product search index')

    # names -> data domain -> warehouse,db,id,conn_type
    tree = nested_dict()

    for _, row in product_data.iterrows():
        product_name = row['PRODUCT_NAME']
        data_domain = row['PRODUCT_DATA_DOMAIN']
        warehouse = row['PRODUCT_WAREHOUSE']
        db = row['PRODUCT_DB']
        conn_type = row['PRODUCT_CONN_TYPE']

        # Create set/list of product names child in the tree if it doesn't exist
        tree['PRODUCT_NAMES'] = tree.get('PRODUCT_NAMES', set())
        tree['PRODUCT_NAMES'].add(product_name)

        product_node = tree[product_name]

        product_node['DATA_DOMAINS'] = product_node.get('DATA_DOMAINS', set())
        product_node['DATA_DOMAINS'].add(data_domain)


        domain_node = product_node[data_domain]
        domain_node['WAREHOUSE'] = warehouse
        domain_node['DB'] = db
        domain_node['CONN_TYPE'] = conn_type
        domain_node['ID'] = row['PRODUCT_ID']

    # Converting all sets to lists before returning
    def convert_sets(obj):
        if isinstance(obj, dict):
            return {k: convert_sets(v) for k, v in obj.items()}
        elif isinstance(obj, set):
            lis = list(obj)
            lis.sort()
            return  lis
        else:
            return obj

    return convert_sets(tree)


def main():
    with st.sidebar:
        logout_button()

    _, product_config_col, product_approval_col, about_col = st.columns([10, 1.5, 1.5, 1], gap='small')

    st.markdown(f"### ❄️ :blue[Admin Console]")

    with product_config_col:
        # st.markdown(f'<a href="{product_url}" target="_self">Product</a>', unsafe_allow_html=True)
        st.page_link("pages/6_Product_Config.py", label='Product Config', use_container_width=True)

    with product_approval_col:
        st.page_link("pages/7_Product_Approval.py", label='Product Approval', use_container_width=True)

    with about_col:
        st.page_link("pages/99_About.py", label='About', use_container_width=True)

    if sst.get('ac_product_config_df') is None:
        logger.info('Loading Product Config Data from DB')
        sst['ac_product_config_df'] = get_product_data()

    product_data = sst['ac_product_config_df']
    search_index = product_search_index(product_data)

    with st.container():
        product_ids = [None] + product_data['PRODUCT_ID'].unique().tolist()
        product_names = [None] + product_data['PRODUCT_NAME'].unique().tolist()

        product_name_col, product_data_domain_col, product_id_col = st.columns([4, 4, 4])

        with product_name_col:
            product_name = st.selectbox(
                label='Select Product Name',
                options=search_index['PRODUCT_NAMES'],
                index=0,
                key=f'{page_key} product name',
            )

        with product_data_domain_col:
            data_domain = st.selectbox(
                label='Select Data Domain',
                options=search_index[product_name].get('DATA_DOMAINS', []),
                index=0,
                key=f'{page_key} data domain',
            )

        with product_id_col:
            product_id = search_index[product_name][data_domain].get('ID', None)
            product_warehouse = search_index[product_name][data_domain].get('WAREHOUSE', None)
            product_db = search_index[product_name][data_domain].get('DB', None)
            product_conn_type = search_index[product_name][data_domain].get('CONN_TYPE', None)

            st.selectbox(
                label='Select Product ID',
                options=product_ids,
                index=product_ids.index(product_id) if product_id in product_ids else 0,
                key=f'{page_key} product id',
                disabled=True
            )


        if product_id is None:
            st.info('Select a valid product')

            # Delete filtered data
            sst['filter_data'] = None

            st.stop()


        if product_id == sst.get('previous_product_id'):
            pass
        else:
            # Reset states, record latest filtered data
            logger.info('Product ID changed, resetting previous product id')
            reset_states = [
                # states in test_design config
                'tp_job_config_df',
                'tp_threshold_df',
                'previous_tp_job_id',
                'tp_testplan_df',
                'tp_testplan_df_key',
                'edited_tp_testplan_df',
                'tp_test_results_df',
                'unsaved_testplan_changes',

                'new_test_thresholds_df',
                'new_test_thresholds_df_key',
                'edited_new_test_threshold_df',

                'edit_test_thresholds_df',
                'edit_test_thresholds_df_key',
                'edited_edit_test_threshold_df',

                # states in job config
                'jc_env_table',
                'disp_job_config',
                'disp_job_config_key',
                'unsaved_job_config_changes',
                'final_jc_data',
                'final_jc_data_key',
                'disp_job_exec',
                'disp_job_exec_key',
                'jc_audit_log_df',
                'unmasked_job_config',

                # states in product config
                'pc_product_table',

                # states in task scheduler
                'ts_list_tasks',
                'ts_task_list',
                'ts_task_hist',

                # states in threshold config
                'thc_threshold_df',
                'thc_threshold_df_key',
                'edited_thc_threshold_df',
                'unsaved_threshold_config_changes',

            ]
            for state in reset_states:
                if sst.get(state) is not None:
                    del sst[state]

            logger.info('Product exists, Saving filtered data')
            sst['filter_data'] = {
                'product_id': product_id,
                'product_name': product_name,
                'data_domain': data_domain,
                'product_database': product_db,
                'product_warehouse': product_warehouse,
                'product_conn_type': product_conn_type,
                'random_id': random.randint(0, 1000)
            }

            sst['previous_product_id'] = product_id

    # Display the below actions only if product exists and its data has been filtered out
    if sst.get('filter_data') is not None:
        st.text('')
        st.text('')
        jconfig_col, testplan_col, threshold_col, task_scheduler_col,  _ = st.columns([1, 1, 1, 1, 3])
        with jconfig_col:
            if st.button('Job Config', key=f'{page_key}_job_config_visit', use_container_width=True):
                st.switch_page('pages/2_Job_Config.py')

        with testplan_col:
            if st.button('Test Design', key=f'{page_key}_test_design_visit', use_container_width=True):
                st.switch_page('pages/3_Test_Design.py')

        with threshold_col:
            if st.button('Threshold Config', key=f'{page_key}_threshold_config_visit', use_container_width=True):
                st.switch_page('pages/4_Threshold_Config.py')

        with task_scheduler_col:
            if st.button('Task Scheduler', key=f'{page_key}_task_scheduler_visit', use_container_width=True):
                st.switch_page('pages/5_Task_Scheduler.py')

