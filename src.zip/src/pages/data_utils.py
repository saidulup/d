

import os
import pandas as pd
import streamlit as st
from loguru import logger
from src.db.snowflake.database import get_snowpark_session, get_snowpark_product_session



@st.cache_data(ttl=300)
def product_warehouse_status(warehouse):
    """
    Verify whether the current user/credentials have access to the given warehouse
    """
    # Get a snowpark session for this warehouse
    session = get_snowpark_product_session(warehouse)

    # Get the current warehouse
    current_warehouse = session.get_current_warehouse()

    # remove "" from warehouse
    current_warehouse = str(current_warehouse).replace('"', '').upper()

    if current_warehouse == str(warehouse).upper():
        # Product warehouse exists
        return ''
    else:
        # Product warehouse does not exist
        return 'Not Found'


def get_product_data():
    session = get_snowpark_session()

    product_table_name = os.environ['PRODUCT_TABLE_NAME']

    product_df = session.sql(f"""
    select distinct product_id, product_name, product_data_domain, product_warehouse, product_db, product_conn_type
    from {product_table_name} 
    where 
        ds_usage_flag='true' and
        product_id is not null and
        product_name is not null and
        product_data_domain is not null
    order by product_name asc, product_data_domain asc, product_db asc
    """).collect()
    product_df = pd.DataFrame(product_df)

    if product_df.empty:
        product_df = pd.DataFrame(columns=['PRODUCT_ID', 'PRODUCT_NAME', 'PRODUCT_DATA_DOMAIN', 'PRODUCT_WAREHOUSE', 'PRODUCT_DB', 'PRODUCT_CONN_TYPE'])

    return product_df


def get_job_config_table(product_id, warehouse):
    session = get_snowpark_product_session(warehouse)

    job_config_table_name = os.environ['JOB_CONFIG_TABLE_NAME']

    query = f"""
    select distinct 
        JOBID, ENVIRONMENT_ID, JOBNAME, JOBDESCRIPTION, EXECUTIONSTEP,
        EMAILID, EMAILTO, FAILUREEMAILTO, EMAILFROM, REPLYTO,
        JOBTIMEOUT, INSERTTIMESTAMP, CREATEDBYUSERID, JOB_FAILED_QUERY,
        PRODUCT_ID, FORCEFAIL
    from {job_config_table_name}
    where 
        product_id = {product_id}
        and jobid is not null
    """
    job_config_table = pd.DataFrame(session.sql(query).collect())

    if job_config_table.empty:
        cols = [
            'JOBID', 'ENVIRONMENT_ID', 'JOBNAME', 'JOBDESCRIPTION', 'EXECUTIONSTEP',
            'EMAILID', 'EMAILTO', 'FAILUREEMAILTO', 'EMAILFROM', 'REPLYTO',
            'JOBTIMEOUT', 'INSERTTIMESTAMP', 'CREATEDBYUSERID', 'JOB_FAILED_QUERY',
            'PRODUCT_ID', 'FORCEFAIL'
        ]
        job_config_table = pd.DataFrame(columns=cols)

    return job_config_table


def get_test_plan(job_id, warehouse):
    session = get_snowpark_product_session(warehouse)

    test_plan_table_name = os.environ['TESTPLAN_TABLE_NAME']

    query = f"""
    select distinct 
        JOBID, JOBNAME, DSID, SECONDARYDSID, TESTTYPE,
        TESTCASEDESCRIPTION, SOURCEPRESQL, SOURCETESTSCRIPT,
        TARGETPRESQL, TARGETTESTSCRIPT, DS_COVERAGE_OBJECT,
        EXECUTIONSTEP, RESULTSETCOLS,
        RESULTSETCOLNAME, ENABLEDFLAG, CRITICALITY, THRESHOLDID,
        DATAVALIDATIONFLAG, FREQUENCYCHECK, TESTCATEGORY,
        CREATEDBYUSERID, INSERTTIMESTAMP, TARGETTABLE, SCHEDULER_FREQ,
        SCHEDULER_EXECUTED_AT
    from {test_plan_table_name}
    where
        jobid = {job_id}
        and jobid is not null
        and dsid is not null
    order by dsid desc
    """

    test_plan_table = pd.DataFrame(session.sql(query).collect())
    if test_plan_table.empty:
        cols = [
            'JOBID', 'JOBNAME', 'DSID', 'SECONDARYDSID', 'TESTTYPE',
           'TESTCASEDESCRIPTION', 'SOURCEPRESQL', 'SOURCETESTSCRIPT',
           'TARGETPRESQL', 'TARGETTESTSCRIPT', 'DS_COVERAGE_OBJECT',
            'EXECUTIONSTEP', 'RESULTSETCOLS',
           'RESULTSETCOLNAME', 'ENABLEDFLAG', 'CRITICALITY', 'THRESHOLDID',
           'DATAVALIDATIONFLAG', 'FREQUENCYCHECK', 'TESTCATEGORY',
           'CREATEDBYUSERID', 'INSERTTIMESTAMP', 'TARGETTABLE', 'SCHEDULER_FREQ',
           'SCHEDULER_EXECUTED_AT',
        ]
        test_plan_table = pd.DataFrame(columns=cols)

    return test_plan_table


def get_threshold_table(warehouse):
    session = get_snowpark_product_session(warehouse)

    threshold_table_name = os.environ['THRESHOLD_TABLE_NAME']

    query = f"""
    select distinct 
        THRESHOLDID, THRESHOLDTYPE, MINWARNINGTHRESHOLD,
        MAXWARNINGTHRESHOLD, MINFAILTHRESHOLD, MAXFAILTHRESHOLD,
        FLOORVALUE, CEILINGVALUE, JANUARY, FEBRUARY, MARCH, APRIL,
        MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER,
        DECEMBER
    from {threshold_table_name}
    order by THRESHOLDID
    """

    threshold_table = pd.DataFrame(session.sql(query).collect())
    if threshold_table.empty:
        cols = [
            'THRESHOLDID', 'THRESHOLDTYPE', 'MINWARNINGTHRESHOLD',
            'MAXWARNINGTHRESHOLD', 'MINFAILTHRESHOLD', 'MAXFAILTHRESHOLD',
            'FLOORVALUE', 'CEILINGVALUE', 'JANUARY', 'FEBRUARY', 'MARCH', 'APRIL',
            'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER',
            'DECEMBER'
        ]
        threshold_table = pd.DataFrame(columns=cols)
    return threshold_table


def get_product_table(warehouse):
    session = get_snowpark_product_session(warehouse)

    product_table_name = os.environ['PRODUCT_TABLE_NAME']

    query = f"""
    select distinct
        PRODUCT_ID, PRODUCT_ABBRV, PRODUCT_NAME, PRODUCT_DATA_DOMAIN,
        DQ_ANALYST_OWNER, PRODUCT_DB, PRODUCT_POD_SCHEMA,
        PRODUCT_SECURE_GROUP, DS_SERVICE_ACCOUNT_SECURE_ROLE, EMAILID,
        INSERTTIMESTAMP, CREATEDBYUSERID, PRODUCT_WAREHOUSE,
        DS_USAGE_FLAG, PRODUCT_CONN_TYPE
    from {product_table_name}
    where product_id is not null
    """

    product_table = pd.DataFrame(session.sql(query).collect())
    if product_table.empty:
        cols = ['PRODUCT_ID', 'PRODUCT_ABBRV', 'PRODUCT_NAME', 'PRODUCT_DATA_DOMAIN',
           'DQ_ANALYST_OWNER', 'PRODUCT_DB', 'PRODUCT_POD_SCHEMA',
           'PRODUCT_SECURE_GROUP', 'DS_SERVICE_ACCOUNT_SECURE_ROLE', 'EMAILID',
           'INSERTTIMESTAMP', 'CREATEDBYUSERID', 'PRODUCT_WAREHOUSE',
           'DS_USAGE_FLAG', 'PRODUCT_CONN_TYPE'
        ]
        product_table = pd.DataFrame(columns=cols)
    return product_table


def get_test_categories(warehouse) -> list:
    session = get_snowpark_product_session(warehouse)

    test_category_table_name = os.environ['TESTCATEGORY_TABLE_NAME']

    query = f"""
    select distinct category
    from {test_category_table_name}
    order by category
    """

    test_category_table = pd.DataFrame(session.sql(query).collect())
    if test_category_table.empty:
        return []
    else:
        test_categories = test_category_table['CATEGORY'].tolist()
        return test_categories