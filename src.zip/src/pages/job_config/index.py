
import streamlit as st
from streamlit import session_state as sst

from src.pages.job_config.tab_update import render_ac_job_config
from src.pages.job_config.tab_athena_update import render_ac_job_config as render_ac_job_config_athena
from src.pages.job_config.tab_execute import render_ac_job_execute
from src.pages.job_config.tab_athena_execute import render_ac_job_execute as render_ac_job_execute_athena

from src.pages.utils.console_components import back_button
from src.auth.auth_widgets import logout_button

st.set_page_config(layout="wide", initial_sidebar_state='collapsed')

if sst.get('filter_data') is None:
    # if st.button('⬅️ Back', key='back from jobconfig', type='primary'):
    st.switch_page('app.py')


page_key = 'job_config_page'
unsaved_changes_state = 'unsaved_job_config_changes'
page_states = [
    'jc_env_table',
    'disp_job_config',
    'disp_job_config_key',
    'unsaved_job_config_changes',
    'final_jc_data',
    'final_jc_data_key',
    'disp_job_exec',
    'disp_job_exec_key',
    'jc_audit_log_df',
    'unmasked_job_config',

]
back_page = 'pages/1_Admin_Console.py'

def main():
    # Logout Button
    with st.sidebar:
        logout_button()

    # Go Back button
    back_button(page_key, back_page, unsaved_changes_state, page_states)

    selected_product_id = sst['filter_data']['product_id']
    selected_product_name = sst['filter_data']['product_name']
    selected_data_domain = sst['filter_data']['data_domain']
    selected_database = sst['filter_data']['product_database']
    selected_warehouse = sst['filter_data']['product_warehouse']
    selected_conn_type = str(sst['filter_data']['product_conn_type']).lower()
    selected_conn_type = 'snowflake' if selected_conn_type in ['none', 'nan', ''] else selected_conn_type

    random_id = sst['filter_data']['random_id']

    st.markdown(f"### ❄️ :blue[Job Config - {selected_conn_type.title()}] ")
    config_tab, execute_tab = st.tabs(["Configure Job", "Execute Job"])
    with config_tab:
        if selected_conn_type == 'snowflake':
            render_ac_job_config(
                selected_product_id, selected_product_name, selected_data_domain,
                selected_database, selected_warehouse, random_id
            )
        elif selected_conn_type == 'athena':
            render_ac_job_config_athena(
                selected_product_id, selected_product_name, selected_data_domain,
                selected_database, selected_warehouse, random_id
            )

    with execute_tab:
        if selected_conn_type == 'snowflake':
            render_ac_job_execute(
                selected_product_id, selected_product_name, selected_data_domain,
                selected_database, selected_warehouse, random_id
            )
        elif selected_conn_type == 'athena':
            render_ac_job_execute_athena(
                selected_product_id, selected_product_name, selected_data_domain,
                selected_database, selected_warehouse, random_id
            )
