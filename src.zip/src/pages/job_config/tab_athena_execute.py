
import random
import streamlit as st
from streamlit import session_state as sst

from src.pages.utils.elements import space
from src.pages.data_utils import get_job_config_table
from src.pages.job_config.db import execute_job_athena, get_execution_logs, get_auditlogs
from src.pages.job_config.grids import *


@st.fragment()
def render_ac_job_execute(product_id, product_name, product_data_domain, product_db, product_warehouse, random_id):
    tab_key = 'ac-job execution' + str(random_id)

    st.text(' ')

    st.markdown(f"""
    ###### Product Id : :blue[{product_id}], Product Name : :blue[{product_name}], Data Domain : :blue[{product_data_domain}]], Warehouse : :blue[{product_warehouse}]
    """)

    with st.spinner('Loading...'):
        job_config_df = get_job_config_table(product_id, product_warehouse)

    st.markdown(f"##### :blue[Job Config Table]")

    if sst.get('disp_job_exec') is None:
        disp_job_config = job_config_df
        sst['disp_job_exec'] = disp_job_config.sort_values(by=['JOBID'], ascending=False)
        sst['disp_job_exec_key'] = f'{tab_key} : display job config grid for exec : {random.randint(0, 1000)}'

    disp_job_config = sst['disp_job_exec']
    disp_job_config_key = sst['disp_job_exec_key']

    grid_edit_job_config = job_config_select_grid(
        disp_job_config,
        cbox=True,
        key=disp_job_config_key
    )

    selected_rows = grid_edit_job_config['selected_rows']
    if len(selected_rows) > 0:
        selected_job = selected_rows[0]
        st.markdown(f"##### :blue[Execute Job]")
        jobname = selected_job.get('JOBNAME')
        estep = selected_job.get('EXECUTIONSTEP')

        if str(jobname).strip().lower() in {'none', 'nan', ''} or str(estep).strip().lower() in {'none', 'nan', ''}:
            st.warning("Please select a valid job to execute")
        else:
            msg_col, button_col, _ = st.columns([4, 1, 3])

            with msg_col:
                st.markdown(f"##### :blue[Execute Job] - {jobname} : {estep}")
            with button_col:
                on_execute = st.button(
                    label='🚀 Execute',
                    key=f"{tab_key}_execute_job",
                    # use_container_width=True
                )
            with st.spinner('Executing ..'):
                if on_execute:
                    execute_job_athena(jobname, estep)
                    # st.markdown(f"{selected_job_name} : {selected_exec_step} : {exec_flag}")

            with st.expander("Execution Logs", expanded=True):
                env_id = 1 # athena products by default run in prod
                run_id = None
                audit_log_title_col, audit_log_refresh_col = st.columns([5, 1])
                with audit_log_title_col:
                    st.markdown(f"##### :blue[Audit Logs]")
                with audit_log_refresh_col:
                    refresh_logs = st.button(
                        label='Refresh',
                        key=f"{tab_key}_refresh",
                    )
                    if refresh_logs:
                        if sst.get('jc_audit_log_df') is not None:
                            del sst['jc_audit_log_df']

                with st.spinner('Loading Audit Logs..'):
                    if sst.get('jc_audit_log_df') is None:
                        # comment this before moving
                        # product_warehouse, jobname, estep, env_id, run_id = 'nware', 'DCDR_Release_PoC_v1', 'POST-CHECK', 1, None

                        audit_logs = get_auditlogs(product_warehouse, jobname, estep, env_id, run_id)
                        sst['jc_audit_log_df'] = audit_logs

                    audit_logs = sst['jc_audit_log_df']

                df_with_selections = audit_logs.copy()
                df_with_selections.insert(0, "Select", False)
                disable_columns = list(audit_logs.columns)

                # Get dataframe row-selections from user with st.data_editor
                edited_df = st.data_editor(
                    data=df_with_selections,
                    # height=height,
                    hide_index=True,
                    column_config={"Select": st.column_config.CheckboxColumn(required=True)},
                    disabled=disable_columns,
                )

                # Filter the dataframe using the temporary column, then drop the column
                selected_rows = edited_df[edited_df.Select]


                if not selected_rows.empty:
                    st.markdown(f"##### :blue[Execution Logs]")

                    with st.spinner('Loading Execution Logs..'):
                        # comment this before moving
                        # product_warehouse, jobname, estep, env_id = 'nware', 'DCDR_Release_PoC_v1', 'POST-CHECK', 1

                        run_id = selected_rows['RUNID'].values[0]
                        exec_logs = get_execution_logs(product_warehouse, jobname, estep, env_id, run_id)

                    st.dataframe(exec_logs, use_container_width=True, hide_index=True)


