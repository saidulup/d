
import json
import random
import streamlit as st
from streamlit import session_state as sst
import numpy as np
import pandas as pd

from src.pages.data_utils import get_job_config_table
from src.pages.job_config.grids import *
from src.pages.job_config.db import update_job_config_athena, get_job_env_states, generate_job_id
import time



def fetch_job_environment_conn_creds(jobid, env_table):
    conn_creds = env_table[env_table['JOBID'] == str(jobid)]['NON_SNOWFLAKE_CONN_CREDS']
    # Parse this json string
    if conn_creds.empty is False:
        try:
            data = json.loads(conn_creds.iloc[0])
            return {
                'AWS_ACCESS_KEY_ID': data.get('AWS_ACCESS_KEY_ID', ''),
                'AWS_SECRET_ACCESS_KEY': data.get('AWS_SECRET_ACCESS_KEY', ''),
                'AWS_S3_BUCKET_DIR': data.get('AWS_S3_BUCKET_DIR', ''),
                'AWS_REGION_NAME': data.get('AWS_REGION_NAME', ''),
                'AWS_SCHEMA_NAME': data.get('AWS_SCHEMA_NAME', '')
            }
        except Exception as e:
            pass
    return {
        'AWS_ACCESS_KEY_ID': '',
        'AWS_SECRET_ACCESS_KEY': '',
        'AWS_S3_BUCKET_DIR': '',
        'AWS_REGION_NAME': '',
        'AWS_SCHEMA_NAME': ''

    }


def mask_athena_conn_creds(actual_data):
    """replace athena connection credentials with xxx"""
    masked_data = actual_data.copy()
    for index, row in masked_data.iterrows():
        if row['AWS_ACCESS_KEY_ID'] != '':
            masked_data.loc[index, 'AWS_ACCESS_KEY_ID'] = '***'
        if row['AWS_SECRET_ACCESS_KEY'] != '':
            masked_data.loc[index, 'AWS_SECRET_ACCESS_KEY'] = '***'
        # if row['AWS_S3_BUCKET_DIR'] != '':
        #     masked_data.loc[index, 'AWS_S3_BUCKET_DIR'] = '***'
        # if row['AWS_REGION_NAME'] != '':
        #     masked_data.loc[index, 'AWS_REGION_NAME'] = '***'
        # if row['AWS_SCHEMA_NAME'] != '':
        #     masked_data.loc[index, 'AWS_SCHEMA_NAME'] = '***'
    return masked_data


def unmask_athena_conn_creds(masked_data, actual_data):
    """replace athena connection credentials with actual data if the masked data is xxx"""
    for index, row in masked_data.iterrows():
        jobid = row['JOBID']
        job_data = actual_data.loc[actual_data['JOBID'] == jobid]
        # If the job data is empty, then this is a new record accept whatever is there in the masked data
        if job_data.empty:
            continue
        job_data = job_data.to_dict(orient='records')[0]

        if row['AWS_ACCESS_KEY_ID'] == '***':
            masked_data.loc[index, 'AWS_ACCESS_KEY_ID'] = job_data['AWS_ACCESS_KEY_ID']
        if row['AWS_SECRET_ACCESS_KEY'] == '***':
             masked_data.loc[index, 'AWS_SECRET_ACCESS_KEY'] = job_data['AWS_SECRET_ACCESS_KEY']
        # if row['AWS_S3_BUCKET_DIR'] == '***':
        #     masked_data.loc[index, 'AWS_S3_BUCKET_DIR'] = job_data['AWS_S3_BUCKET_DIR']
        # if row['AWS_REGION_NAME'] == '***':
        #     masked_data.loc[index, 'AWS_REGION_NAME'] = job_data['AWS_REGION_NAME']
        # if row['AWS_SCHEMA_NAME'] == '***':
        #     masked_data.loc[index, 'AWS_SCHEMA_NAME'] = job_data['AWS_SCHEMA_NAME']
    return masked_data


@st.fragment()
def render_ac_job_config(product_id, product_name, product_data_domain, product_db, product_warehouse, random_id):
    tab_key = 'ac-jobconfig-athena' + str(random_id)

    st.text(' ')
    st.markdown(f"""
    ###### Product Id : :blue[{product_id}], Product Name : :blue[{product_name}], Data Domain : :blue[{product_data_domain}], Warehouse : :blue[{product_warehouse}]
    """)
    st.markdown(f"##### :blue[Job Config Table]")

    if sst.get('jc_env_table') is None:
        with st.spinner('Loading...'):
            env_table = get_job_env_states(product_warehouse)
            sst['jc_env_table'] = env_table # environment table
    env_table = sst['jc_env_table']

    if sst.get('disp_job_config') is None:
        with st.spinner('Loading...'):
            job_config_df = get_job_config_table(product_id, product_warehouse)

            job_config_df['COLOR_FLAG'] = 'edited'
            job_config_df['AWS_ACCESS_KEY_ID'] = ''
            job_config_df['AWS_SECRET_ACCESS_KEY'] = ''
            job_config_df['AWS_S3_BUCKET_DIR'] = ''
            job_config_df['AWS_REGION_NAME'] = ''
            job_config_df['AWS_SCHEMA_NAME'] = ''

            for index, row in job_config_df.iterrows():
                job_env_creds = fetch_job_environment_conn_creds(row['JOBID'], env_table)
                job_config_df.loc[index, 'AWS_ACCESS_KEY_ID'] = job_env_creds['AWS_ACCESS_KEY_ID']
                job_config_df.loc[index, 'AWS_SECRET_ACCESS_KEY'] = job_env_creds['AWS_SECRET_ACCESS_KEY']
                job_config_df.loc[index, 'AWS_S3_BUCKET_DIR'] = job_env_creds['AWS_S3_BUCKET_DIR']
                job_config_df.loc[index, 'AWS_REGION_NAME'] = job_env_creds['AWS_REGION_NAME']
                job_config_df.loc[index, 'AWS_SCHEMA_NAME'] = job_env_creds['AWS_SCHEMA_NAME']

            # Mask the credentials
            masked_job_config_df = mask_athena_conn_creds(job_config_df)

        sst['unmasked_job_config'] = job_config_df
        sst['disp_job_config'] = masked_job_config_df.sort_values(by=['JOBID'], ascending=False)
        sst['disp_job_config_key'] = f'{tab_key} : display job config grid : {random.randint(0, 1000)}'

    disp_job_config = sst['disp_job_config']
    disp_job_config_key = sst['disp_job_config_key']

    grid_edit_job_config = job_config_edit_grid_athena(
        disp_job_config,
        cbox=True,
        key=disp_job_config_key
    )
    add_col, duplicate_col, _ = st.columns([1, 1, 6], gap='small')
    with add_col:
        on_add = st.button('➕ :green[Add]', use_container_width=True)
        if on_add:
            temp_df = grid_edit_job_config['data'].replace("None", np.nan)
            start_jobid = generate_job_id()
            nrows, ncols = temp_df.shape
            temp_df.loc[nrows] = [""] * ncols
            temp_df.loc[nrows, 'JOBID'] = start_jobid
            # set prod, stage, dev flags
            temp_df.loc[nrows, 'PROD'] = True
            temp_df.loc[nrows, 'STAGE'] = True
            temp_df.loc[nrows, 'DEV'] = True

            temp_df.loc[nrows, 'COLOR_FLAG'] = 'added'
            temp_df['JOBID'] = temp_df['JOBID'].astype('int64')

            sst['disp_job_config'] = temp_df.sort_values(by=['JOBID'], ascending=False)
            sst['disp_job_config_key'] = f'{tab_key} : display job config grid : {random.randint(0, 1000)}'
            st.rerun()

    with duplicate_col:
        on_duplicate = st.button('📄 Duplicate', use_container_width=True)
        if on_duplicate:
            # store the unmasked config data temporarily
            unmasked_temp_df = sst.get('unmasked_job_config')
            # store the data in the grid to a temp variable
            temp_df = grid_edit_job_config['data'].replace("None", np.nan)
            drecord = temp_df.iloc[0].to_frame().T.reset_index(drop=True)

            # add this record to the top of the grid
            temp_df = pd.concat([drecord, temp_df], ignore_index=True).reset_index(drop=True)
            # set the jobid for the new record
            start_jobid = generate_job_id()

            # set prod, stage, dev flags
            temp_df.loc[0, 'JOBID'] = start_jobid
            temp_df.loc[0, 'COLOR_FLAG'] = 'added'
            temp_df['JOBID'] = temp_df['JOBID'].astype('int64')

            # update a record into unmasked df as well
            unmasked_record = unmasked_temp_df.iloc[0].to_frame().T.reset_index(drop=True)
            unmasked_temp_df = pd.concat([unmasked_record, unmasked_temp_df], ignore_index=True).reset_index(drop=True)
            unmasked_temp_df.loc[0, 'JOBID'] = start_jobid
            unmasked_temp_df.loc[0, 'COLOR_FLAG'] = 'added'
            unmasked_temp_df['JOBID'] = unmasked_temp_df['JOBID'].astype('int64')

            sst['unmasked_job_config'] = unmasked_temp_df
            sst['disp_job_config'] = temp_df.sort_values(by=['JOBID'], ascending=False)
            sst['disp_job_config_key'] = f'{tab_key} : display job config grid : {random.randint(0, 1000)}'
            st.rerun()

    srows_edit_job_config = grid_edit_job_config['selected_rows']
    if len(srows_edit_job_config) > 0:
        edited_rows = pd.DataFrame(srows_edit_job_config).drop(columns=['_selectedRowNodeInfo'])
        save_jc_data = edited_rows

        sst['unsaved_job_config_changes'] = len(save_jc_data)
        # compare whether the dataframes are same
        if not save_jc_data.equals(sst.get('final_jc_data', pd.DataFrame())):
            sst['final_jc_data'] = save_jc_data
            sst['final_jc_data_key'] = f'{tab_key} : final job config grid : {random.randint(0, 1000)}'

        final_jc_data = sst['final_jc_data']
        final_jc_data_key = sst['final_jc_data_key']

        final_jc_data = job_config_final_grid_athena(final_jc_data, key=final_jc_data_key)
        final_jc_data = pd.DataFrame(final_jc_data['data'])

        if len(final_jc_data) > 0:
            save_col, cancel_col, _ = st.columns([1, 1, 6], gap='small')
            with cancel_col:
                on_cancel = st.button('❌ :red[Cancel]', use_container_width=True)
                if on_cancel:
                    sst['unmasked_job_config'] = None
                    sst['disp_job_config'] = None
                    sst['disp_job_config_key'] = f'{tab_key} : display job config grid : {random.randint(0, 1000)}'
                    st.rerun()
            with save_col:
                submit_update = st.button('💾 Save', key=f"{tab_key}_update_job_config", use_container_width=True)
            if submit_update:
                # save_jc_data.to_csv('jconfig.csv', index=False)
                # set selected values for newly added records
                final_jc_data['PRODUCT_ID'] = product_id

                with st.spinner():
                    unmasked_job_config_df = sst.get('unmasked_job_config')
                    unmasked_data = unmask_athena_conn_creds(final_jc_data, unmasked_job_config_df)
                    status, msg = update_job_config_athena(
                        unmasked_data,
                        product_db,
                        product_warehouse
                    )
                if status == 'Success':
                    st.success('Records Successfully Updated')
                    # st.dataframe(save_jc_data, hide_index=True)
                    with st.spinner('Reloading in 5 sec'):
                        time.sleep(5)
                        # reload_page('Success', 5)
                        reset_states = [
                            'unmasked_job_config',
                            'disp_job_config',
                            'disp_job_config_key',
                            'jc_env_table',
                            'unsaved_job_config_changes',
                            'final_jc_data',
                            'final_jc_data_key',
                        ]
                        for state in reset_states:
                            if sst.get(state) is not None:
                                del sst[state]
                        st.rerun()

                else:
                    st.warning('The following error occurred while updating the records')
                    st.dataframe(msg['failed_records'])
