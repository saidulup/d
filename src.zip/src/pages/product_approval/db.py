

import os
import pandas as pd
import streamlit as st
from src.db.snowflake.database import get_snowpark_session


def approve_products(products_df):
    # Table names
    product_table = os.environ.get('PRODUCT_TABLE_NAME')

    session = get_snowpark_session()

    # Start transaction
    session.sql("begin").collect()

    error_log = []
    for index, row in products_df.iterrows():
        update_product_query = ""
        try:
            update_product_query = f"""
            update {product_table}
            set DS_USAGE_FLAG = True
            where 
                PRODUCT_ID = {row["PRODUCT_ID"]} and 
                PRODUCT_NAME = '{row["PRODUCT_NAME"]}' and
                DS_USAGE_FLAG = False
            """
            session.sql(update_product_query).collect()
        except Exception as e:
            error_log.append({"PRODUCT_ID": row["PRODUCT_ID"], "PRODUCT_NAME": row['PRODUCT_NAME'], "UPDATE_QUERY": update_product_query, "ERROR": str(e)})

    error_df = pd.DataFrame(error_log)
    if not error_df.empty:
        session.sql("rollback").collect()
        st.error('Error occurred while approving follwing products')
        st.dataframe(error_df)
    else:
        session.sql("commit").collect()
        # session.sql("rollback").collect()
        return 'Success'


# delete records from the product table
def reject_products(products_df):
    # Table names
    product_table = os.environ.get('PRODUCT_TABLE_NAME')

    session = get_snowpark_session()

    # Start transaction
    session.sql("begin").collect()

    error_log = []
    for index, row in products_df.iterrows():
        delete_product_query = ""
        try:
            delete_product_query = f"""
            delete from {product_table}
            where 
                PRODUCT_ID = {row["PRODUCT_ID"]} and 
                PRODUCT_NAME = '{row["PRODUCT_NAME"]}' and
                DS_USAGE_FLAG = False
            """
            session.sql(delete_product_query).collect()
        except Exception as e:
            error_log.append({"PRODUCT_ID": row["PRODUCT_ID"], "PRODUCT_NAME": row['PRODUCT_NAME'], "DELETE_QUERY": delete_product_query, "ERROR": str(e)})

    error_df = pd.DataFrame(error_log)
    if not error_df.empty:
        session.sql("rollback").collect()
        st.error('Error occurred while rejecting follwing products')
        st.dataframe(error_df)
    else:
        session.sql("commit").collect()
        # session.sql("rollback").collect()
        return 'Success'
