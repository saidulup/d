

import os


from src.services.mail import dispatch_mail


def dispatch_product_approval_mail(product_data):
    try:
        target_mails = [str(product_data['DQ_ANALYST_OWNER']).strip()]
        app_url = os.environ.get('DSA_APP_URL')

        # Email to dispatch list users who have access to approve the newly created prodcut
        body = f"""
        <html>
        <head>
          <style>
            body {{
              font-family: Arial, sans-serif;
              font-size: 14px;
              line-height: 1.5;
              color: #333333;
              background-color: #f5f5f5;
              padding: 20px;
            }}
            h1 {{
              font-size: 24px;
              color: #003366;
              margin-bottom: 20px;
            }}
            p {{
              margin-bottom: 10px;
            }}
            ul {{
              margin-top: 0;
              margin-bottom: 20px;
              padding-left: 20px;
            }}
            li {{
              margin-bottom: 5px;
            }}
            a {{
              color: #003366;
              text-decoration: none;
            }}
            .button {{
              display: inline-block;
              padding: 10px 20px;
              background-color: #003366;
              color: #ffffff;
              text-decoration: none;
              border-radius: 4px;
              margin-top: 20px;
            }}
          </style>
        </head>
        <body>
          <h1>DSE Product Approved</h1>
          <p>Dear DQ Analyst Owner,</p>
          <p>DSE product associated with you has been approved , Here is q quick overview of the product:</p>
          <ul>
        <li><strong>Product ID:</strong> {product_data['PRODUCT_ID']}</li>
            <li><strong>Product Name:</strong> {product_data['PRODUCT_NAME']}</li>
            <li><strong>Product DB:</strong> {product_data['PRODUCT_DB']}</li>
            <li><strong>Product POD Schema:</strong> {product_data['PRODUCT_POD_SCHEMA']}</li>
            <li><strong>Product Connection Type:</strong> {product_data['PRODUCT_CONN_TYPE']}</li>
            <li><strong>Product Data Domain:</strong> {product_data['PRODUCT_DATA_DOMAIN']}</li>
            <li><strong>Product Secure Group:</strong>
            {product_data['PRODUCT_SECURE_GROUP']}</li>
            <li><strong>DQ Analyst Owner:</strong> {product_data['DQ_ANALYST_OWNER']}</li>
            </ul>
            <p>Please visit DSA-Console application, link below to work on this project:</p>
            <p>Link: {app_url}</p>
            <p>Thank you for your attention to this matter.</p>
            <p>Best regards,</p>
            <p>Your DSE Team</p>
        </body>
        </html>
        """

        subject = "DSE Product Approval Notification"
        return dispatch_mail(subject, body, target_mails)
    except Exception as e:
        print(f'An error occurred while sending one of the mails , Error is {e}')


def dispatch_product_rejection_mail(product_data):
    try:

        target_mails = [str(product_data['DQ_ANALYST_OWNER']).strip()]
        app_url = os.environ.get('DSA_APP_URL')

        # Email to dispatch list users who have access to approve the newly created prodcut
        body = f"""
        <html>
        <head>
          <style>
            body {{
              font-family: Arial, sans-serif;
              font-size: 14px;
              line-height: 1.5;
              color: #333333;
              background-color: #f5f5f5;
              padding: 20px;
            }}
            h1 {{
              font-size: 24px;
              color: #003366;
              margin-bottom: 20px;
            }}
            p {{
              margin-bottom: 10px;
            }}
            ul {{
              margin-top: 0;
              margin-bottom: 20px;
              padding-left: 20px;
            }}
            li {{
              margin-bottom: 5px;
            }}
            a {{
              color: #003366;
              text-decoration: none;
            }}
            .button {{
              display: inline-block;
              padding: 10px 20px;
              background-color: #003366;
              color: #ffffff;
              text-decoration: none;
              border-radius: 4px;
              margin-top: 20px;
            }}
          </style>
        </head>
        <body>
          <h1>DSE Product Rejected</h1>
          <p>Dear DQ Analyst Owner,</p>
            <p>DSE product associated with you has been rejected , Here is a quick overview of the product:</p>
          <ul>
            <li><strong>Product ID:</strong> {product_data['PRODUCT_ID']}</li>
            <li><strong>Product Name:</strong> {product_data['PRODUCT_NAME']}</li>
            <li><strong>Product DB:</strong> {product_data['PRODUCT_DB']}</li>
            <li><strong>Product POD Schema:</strong> {product_data['PRODUCT_POD_SCHEMA']}</li>
            <li><strong>Product Connection Type:</strong> {product_data['PRODUCT_CONN_TYPE']}</li>
            <li><strong>Product Data Domain:</strong> {product_data['PRODUCT_DATA_DOMAIN']}</li>
            <li><strong>Product Secure Group:</strong>
            {product_data['PRODUCT_SECURE_GROUP']}</li>
            <li><strong>DQ Analyst Owner:</strong> {product_data['DQ_ANALYST_OWNER']}</li>
            </ul>
            <br>
            <h3>Rejection Reason</h3>
            <p class="">{product_data['COMMENT']}</p>
            
            <p>Please visit DSA-Console application, link below to recreate the product</p>
            <p>Link: {app_url}</p>
            <p>Thank you for your attention to this matter.</p>
            <p>Best regards,</p>
            <p>Your DSE Team</p>
        </body>
        </html>
        """
        subject = "DSE Product Rejection Notification"

        return dispatch_mail(subject, body, target_mails)
    except Exception as e:
        print(f'An error occurred while sending one of the mails , Error is {e}')
