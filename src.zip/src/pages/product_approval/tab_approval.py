

import streamlit as st
from streamlit import session_state as sst

from src.pages.product_approval.db import approve_products, reject_products
from src.pages.data_utils import get_product_table
from src.pages.utils.elements import reload_page, space
from src.core.constants import PRODUCT_OWNERS
from src.pages.product_approval.mail import dispatch_product_approval_mail, dispatch_product_rejection_mail


@st.fragment()
def render_product_approval_tab():
    st.text('')
    if sst.get('pa_product_table', None) is None:
        df = get_product_table(None)
        # filter data on username and approv
        df = df[df['DS_USAGE_FLAG'] == False].reset_index(drop=True)
        df['COMMENT'] = ['' for _ in range(len(df))]
        sst['pa_product_table'] = df

    product_df = sst['pa_product_table']
    if product_df.empty:
        st.info("DSE Product table is empty.")
    else:
        # Rearrange columns for easy reading
        columns = [
            'PRODUCT_ID', 'PRODUCT_ABBRV', 'PRODUCT_NAME', 'PRODUCT_DATA_DOMAIN', 'COMMENT', 'DQ_ANALYST_OWNER', 'PRODUCT_DB',
            'PRODUCT_POD_SCHEMA', 'PRODUCT_SECURE_GROUP', 'DS_SERVICE_ACCOUNT_SECURE_ROLE', 'EMAILID',
            'INSERTTIMESTAMP', 'CREATEDBYUSERID', 'PRODUCT_WAREHOUSE', 'DS_USAGE_FLAG', 'PRODUCT_CONN_TYPE'
        ]
        product_df = product_df[columns]


        # if user is not in PRODUCT_OWNERS, just display df and dont provide any controls
        username = sst.get('user_name', '').lower()
        # print(product_df.columns.tolist())
        if username not in [p.lower() for p in PRODUCT_OWNERS]:

            st.dataframe(product_df, hide_index=True)
            st.warning("You don't have access to approve or reject products.")
            return
        else:
            height = 600 if len(product_df) > 10 else 300
            df_with_selections = product_df.copy()
            df_with_selections.insert(0, "", False)
            disable_columns = list(product_df.columns)
            if 'COMMENT' in disable_columns:
                disable_columns.remove('COMMENT')


            # Get dataframe row-selections from user with st.data_editor
            edited_df = st.data_editor(
                data=df_with_selections,
                height=height,
                hide_index=True,
                column_order=[
                    '', 'PRODUCT_ID', 'PRODUCT_NAME', 'PRODUCT_ABBRV',
                    'PRODUCT_DATA_DOMAIN', 'DQ_ANALYST_OWNER', 'PRODUCT_DB', 'PRODUCT_POD_SCHEMA',
                    'PRODUCT_SECURE_GROUP', 'DS_SERVICE_ACCOUNT_SECURE_ROLE', 'EMAILID',
                    'INSERTTIMESTAMP', 'CREATEDBYUSERID', 'PRODUCT_WAREHOUSE', 'DS_USAGE_FLAG', 'PRODUCT_CONN_TYPE'
                ],
                column_config={
                    "": st.column_config.CheckboxColumn(required=True, pinned=True),
                    'PRODUCT_NAME': st.column_config.TextColumn(pinned=True),
                    'PRODUCT_ABBRV': st.column_config.TextColumn(pinned=True),
                },
                disabled=disable_columns,
            )

            # Filter the dataframe using the temporary column, then drop the column
            selected_rows = edited_df[edited_df[""] == True]

            approv_col, reject_col, _ = st.columns([1, 1, 6])
            with approv_col:
                approv_selected = st.button(
                    label=":blue[Approve]",
                    help="Approve selected records",
                    key="approve",
                    use_container_width=True
                )
                if approv_selected:
                    sst['pa_approv_selected'] = True
                    sst['pa_reject_selected'] = False

            with reject_col:
                reject_selected = st.button(
                    label=":red[Reject]",
                    help="Reject selected records",
                    key="reject",
                    use_container_width=True
                )
                if reject_selected:
                    sst['pa_reject_selected'] = True
                    sst['pa_approv_selected'] = False

            if sst.get('pa_approv_selected', False):
                approval_confirmation_text = "APPROVE"
                text_col, button_col, _ = st.columns([3, 1, 2])
                approval_confirmation_input = text_col.text_input(
                    label=f"Type '{approval_confirmation_text}' to confirm",
                    placeholder=approval_confirmation_text,
                    key="confirm_approv_text",
                )
                with button_col:
                    space()
                    confirm_approval = st.button(
                        label="Confirm",
                        help="Confirm the approval",
                        key="confirm_approv",
                        use_container_width=True
                    )

                if confirm_approval:
                    if approval_confirmation_input != approval_confirmation_text:
                        st.error(f"Confirmation text should be '{approval_confirmation_text}'")
                    else:
                        with st.spinner('Approving selected products...'):
                            result = approve_products(selected_rows)
                        if result == 'Success':
                            st.success('Selected Products approved successfully.')

                            with st.spinner('Dispatching Approval Notification emails...'):
                                failed_mails = []
                                for index, row in selected_rows.iterrows():
                                    status = dispatch_product_approval_mail(row)
                                    if not status:
                                        st.error(f'Failed to send Approval Notification for Product : {row["PRODUCT_NAME"]} to {row["DQ_ANALYST_OWNER"]}')
                                        failed_mails.append(row)
                            if failed_mails:
                                st.warning(f'Failed to send Approval notifications for {len(failed_mails)} products.')
                                reload_page(result, 20)
                            else:
                                st.success('All Approval notifications sent successfully.')
                                reload_page(result)

            if sst.get('pa_reject_selected', False):
                # check whether the comment is provided for all the selected products
                if '' in selected_rows['COMMENT'].str.strip().to_list():
                    st.error('Please provide comments for all the selected products before rejecting')
                    return
                rejection_confirmation_text = "REJECT"
                text_col, button_col, _ = st.columns([3, 1, 2])
                rejection_confirmation_input = text_col.text_input(
                    label=f"Type '{rejection_confirmation_text}' to confirm",
                    placeholder=rejection_confirmation_text,
                    key="confirm_reject_text",
                )
                with button_col:
                    space()
                    confirm_rejection = st.button(
                        label="Confirm",
                        help="Confirm the rejection",
                        key="confirm_reject",
                        use_container_width=True
                    )

                if confirm_rejection:
                    if rejection_confirmation_input != rejection_confirmation_text:
                        st.error(f"Confirmation text should be '{rejection_confirmation_text}'")
                    else:
                        with st.spinner('Rejecting selected products...'):
                            result = reject_products(selected_rows)


                        if result == 'Success':
                            st.success('Selected Products rejected & removed successfully.')
                            with st.spinner('Dispatching Rejection Notification emails...'):
                                failed_mails = []
                                for index, row in selected_rows.iterrows():
                                    status = dispatch_product_rejection_mail(row)
                                    if not status:
                                        st.error(
                                            f'Failed to send Rejection Notification for Product : {row["PRODUCT_NAME"]} to {row["DQ_ANALYST_OWNER"]}')
                                        failed_mails.append(row)
                            if failed_mails:
                                st.warning(f'Failed to send Rejection notifications for {len(failed_mails)} products.')
                                reload_page(result, 20)
                            else:
                                st.success('All Rejection notifications sent successfully.')
                                reload_page(result, 10)
