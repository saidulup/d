


import os
from datetime import datetime
import streamlit as st
import pandas as pd
from streamlit import session_state as sst
from src.db.snowflake.database import get_snowpark_session

def generate_product_id():
    """Get next id from the sequence used to generate Product ID"""
    session = get_snowpark_session()

    seq_name = os.environ.get("DSE_PRODUCT_ID_SEQ")

    query = f"select {seq_name}.nextval as id"
    df = pd.DataFrame(session.sql(query).collect())
    if df.empty:
        raise Exception('Unable to generate Product ID, sequence is empty')

    new_id = df['ID'][0]
    return new_id



def insert_product_table_record(product_data):
    # Table names
    product_table = os.environ.get('PRODUCT_TABLE_NAME')

    emailid = user = sst.get('user_name')

    session = get_snowpark_session()

    insert_query = f"""
    insert into {product_table} (
    PRODUCT_ID, PRODUCT_NAME, PRODUCT_ABBRV, 
     PRODUCT_WAREHOUSE, PRODUCT_DB, PRODUCT_POD_SCHEMA, PRODUCT_CONN_TYPE,
    PRODUCT_DATA_DOMAIN, PRODUCT_SECURE_GROUP,
    DQ_ANALYST_OWNER, DS_SERVICE_ACCOUNT_SECURE_ROLE,
    INSERTTIMESTAMP, EMAILID, CREATEDBYUSERID, DS_USAGE_FLAG
    ) values (
    '{product_data['product_id']}', '{product_data['product_name']}', '{product_data['product_abbr']}',
    '{product_data['product_warehouse']}', '{product_data['product_db']}', '{product_data['product_schema']}', '{product_data['product_conn_type']}',
    '{product_data['product_data_domain']}', '{product_data['product_secure_group']}',
    '{product_data['dq_analyst_owner']}', '{product_data['ds_service_account_secure_role']}',
    '{datetime.now()}', '{emailid}', '{user}', 'False'
    )
    """
    try:
        session.sql(insert_query).collect()
        return 'Success'
    except Exception as e:
        st.error('Error inserting data into product table')
        print(e)
        return 'Failed'
