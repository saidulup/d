

import os
from src.core.constants import PRODUCT_CREATION_DL
from src.services.mail import dispatch_mail


def dispatch_email(product_data):
    """Function to send the mail """
    try:
        target_mails = PRODUCT_CREATION_DL
        app_url = os.environ.get('DSA_APP_URL')

        # Email to dispatch list users who have access to approve the newly created prodcut
        body = f"""
        <html>
        <head>
          <style>
            body {{
              font-family: Arial, sans-serif;
              font-size: 14px;
              line-height: 1.5;
              color: #333333;
              background-color: #f5f5f5;
              padding: 20px;
            }}
            h1 {{
              font-size: 24px;
              color: #003366;
              margin-bottom: 20px;
            }}
            p {{
              margin-bottom: 10px;
            }}
            ul {{
              margin-top: 0;
              margin-bottom: 20px;
              padding-left: 20px;
            }}
            li {{
              margin-bottom: 5px;
            }}
            a {{
              color: #003366;
              text-decoration: none;
            }}
            .button {{
              display: inline-block;
              padding: 10px 20px;
              background-color: #003366;
              color: #ffffff;
              text-decoration: none;
              border-radius: 4px;
              margin-top: 20px;
            }}
          </style>
        </head>
        <body>
          <h1>New DSE Product Created</h1>
          <p>Dear Team,</p>
          <p>A new DSE product has been created. Please review and approve the product details:</p>
          <ul>
            <li><strong>Product ID:</strong> {product_data['product_id']}</li>
            <li><strong>Product Name:</strong> {product_data['product_name']}</li>
            <li><strong>Product DB:</strong> {product_data['product_db']}</li>
            <li><strong>Product POD Schema:</strong> {product_data['product_schema']}</li>
            <li><strong>Product Connection Type:</strong> {product_data['product_conn_type']}</li>
            <li><strong>Product Data Domain:</strong> {product_data['product_data_domain']}</li>
            <li><strong>Product Secure Group:</strong> {product_data['product_secure_group']}</li>
            <li><strong>DQ Analyst Owner:</strong> {product_data['dq_analyst_owner']}</li>
          </ul>
          <p>Please visit DSA-Console application, link below to review and approve the product:</p>
          <p>Link: {app_url}</p>
          <p>Thank you for your attention to this matter.</p>
          <p>Best regards,</p>
          <p>Your DSE Team</p>
        </body>
        </html>
        """

        # message.add_header('to convey config to server')
        subject = "DSE Product Creation Notification"
        return dispatch_mail(subject, body, target_mails)
    except Exception as e:
        print(f'An error occurred while sending one of the mails , Error is {e}')
