
import streamlit as st
from streamlit import session_state as sst

from src.pages.product_config.db import insert_product_table_record, generate_product_id
from src.pages.data_utils import get_product_table
from src.pages.utils.elements import reload_page
from src.pages.product_config.mail import dispatch_email

@st.fragment()
def render_product_tab():
    st.text('')
    if sst.get('pc_product_table', None) is None:
        sst['pc_product_table'] = get_product_table(None)

    product_df = sst['pc_product_table']
    if product_df.empty:
        st.info("DSE Product table is empty.")
    else:
        start_product_id = None

        product_df['PRODUCT_ID'] = product_df['PRODUCT_ID'].astype(str)
        st.dataframe(product_df, hide_index=True, height=200)

        key = 'update dse_product'
        with st.form(key=f"{key} form", border=True):
            st.markdown('##### :green[Add New Product]')

            col1, col2, col3 = st.columns([1, 1, 1])
            with col1:
                _ = st.text_input(
                    label='Product ID',
                    value=start_product_id,
                    disabled=True,
                    key=f"{key} product_id"
                )

                product_warehouse = st.text_input(
                    label='Product Warehouse',
                    value='',
                    placeholder='Enter product warehouse',
                    key=f"{key} product_warehouse"
                ).strip()

                product_conn_type = st.selectbox(
                    label='Product Connection Type',
                    options=['snowflake', 'athena'],
                    key=f"{key} product_conn_type"

                )

            with col2:
                product_name = st.text_input(
                    label='Product Name',
                    value='',
                    placeholder='Enter product name',
                    key=f"{key} product_name"
                ).strip()

                product_db = st.text_input(
                    label='Product DB',
                    value='',
                    placeholder='Enter product db',
                    key=f"{key} product_db"
                ).strip()

                product_data_domain = st.text_input(
                    label='Product Data Domain',
                    value='',
                    placeholder='Enter product data domain',
                    key=f"{key} product_data_domain"
                ).strip()

            with col3:
                product_abbr = st.text_input(
                    label='Product Abbreviation',
                    value='',
                    placeholder='Enter product abbreviation',
                    key=f"{key} product_abbr"
                ).strip()

                product_schema = st.text_input(
                    label='Product POD-Schema',
                    value='',
                    placeholder='Enter product schema',
                    key=f"{key} product_schema"
                ).strip()

                dq_analyst_owner = st.text_input(
                    label='DQ Analyst Owner',
                    value='',
                    placeholder='Enter DQ analyst owner',
                    key=f"{key} dq_analyst_owner"
                ).strip()

            acol1, acol2 = st.columns([1, 1])
            with acol1:

                product_secure_group = st.text_input(
                    label='Product Secure Group',
                    value='',
                    placeholder='Enter product secure group',
                    key=f"{key} product_secure_group"
                ).strip()

            with acol2:

                ds_service_account_secure_role = st.text_input(
                    label='DS Service Account Secure Role',
                    value='',
                    placeholder='Enter DS service account secure role',
                    key=f"{key} ds_service_account_secure_role"
                ).strip()

            submit_product_form = st.form_submit_button(label='Add Product')

        if submit_product_form:
            form_data = {
                'product_id': generate_product_id(),
                'product_name': product_name,
                'product_abbr': product_abbr,
                'product_warehouse': product_warehouse,
                'product_db': product_db,
                'product_schema': product_schema,
                'product_conn_type': product_conn_type,
                'product_data_domain': product_data_domain,
                'product_secure_group': product_secure_group,
                'dq_analyst_owner': dq_analyst_owner,
                'ds_service_account_secure_role': ds_service_account_secure_role
            }

            validation_states = []

            if product_name == '':
                validation_states.append('Product Name cannot be empty.')

            if product_abbr == '':
                validation_states.append('Product Abbreviation cannot be empty.')

            if len(product_abbr) > 10:
                validation_states.append('Product Abbreviation cannot be more than 10 characters.')

            if product_conn_type == '':
                validation_states.append('Product Connection Type cannot be empty.')

            if product_conn_type == 'snowflake':
                if product_warehouse == '':
                    validation_states.append('Product Warehouse cannot be empty.')

                if product_db == '':
                    validation_states.append('Product DB cannot be empty.')

                if product_schema == '':
                    validation_states.append('Product POD-Schema cannot be empty.')

                if product_secure_group == '':
                    validation_states.append('Product Secure Group cannot be empty.')

                if ds_service_account_secure_role == '':
                    validation_states.append('DS Service Account Secure Role cannot be empty.')

            if product_data_domain == '':
                validation_states.append('Product Data Domain cannot be empty.')

            if dq_analyst_owner == '':
                validation_states.append('DQ Analyst Owner cannot be empty.')

            if len(validation_states) > 0:
                for e in validation_states:
                    st.warning(e)
                return
            else:
                with st.spinner('Adding product...'):
                    status = insert_product_table_record(form_data)
                if status == 'Success':
                    st.info('Product added successfully.')
                    with st.spinner('Dispatching Project creation notification to Product Owners...'):
                        # send email
                        message_status = dispatch_email(form_data)
                        if message_status:
                            st.success('Project creation notification dispatched successfully.')
                        else:
                            st.error('Failed to dispatch Project creation notification.')
                    sst['pc_product_table'] = None
                    reload_page(status, 10)
