
import time
import streamlit as st
import os
from src.db.snowflake.database import get_snowpark_session, get_snowpark_product_session
import pandas as pd


@st.cache_data(ttl=300)
def get_warehouse_list():
    """Get the list of all available warehouses"""
    session = get_snowpark_session()
    warehouse_list = pd.DataFrame(session.sql(f"show warehouses").collect())
    if warehouse_list.empty:
        warehouse_list = None
    else:
        # print(warehouse_list)
        warehouse_list = warehouse_list['name'].tolist()
    return warehouse_list


@st.cache_data(ttl=300)
def get_database_list():
    """Get the list of all available databases"""
    session = get_snowpark_session()
    database_list = pd.DataFrame(session.sql(f"show databases").collect())
    if database_list.empty:
        database_list = []
    else:
        database_list = database_list['name'].tolist()
    # return database_list # uncomment in production
    return ['DSA_DB'] # comment in production


@st.cache_data(ttl=300)
def get_schema_list(role, warehouse, database):
    """Get the list of all available schemas"""
    session = get_snowpark_session()
    try:
        session.sql(f"use warehouse {warehouse}").collect()
        session.sql(f"use role {role}").collect()
        session.sql(f"use database {database}").collect()

        schema_list = pd.DataFrame(session.sql(f"show schemas in database {database}").collect())
        if schema_list.empty:
            schema_list = []
        else:
            schema_list = schema_list['name'].tolist()
        return schema_list
    except:
        print("Error in task_scheduler/get_schema_list")
        return []

def get_job_config_table(product_id, warehouse):
    session = get_snowpark_product_session(warehouse)

    job_config_table_name = os.environ['JOB_CONFIG_TABLE_NAME']

    job_config_table = session.sql(f"select * from {job_config_table_name} where product_id = {product_id};").collect()
    job_config_table = pd.DataFrame(job_config_table)

    if job_config_table.empty:
        job_config_desc = pd.DataFrame(session.sql(f'desc table {job_config_table_name};').collect())
        job_config_table = pd.DataFrame(columns=job_config_desc['name'].tolist())

    return job_config_table



def load_data_task_list(task_prefix):
    # load_dt = current_dt()
    session = get_snowpark_session()
    df_task = pd.DataFrame(session.sql(f"SHOW TASKS LIKE '{task_prefix}%' IN ACCOUNT ;").collect())
    df_task.columns = [c.upper() for c in df_task.columns]
    cols = [
        'CREATED_ON', 'NAME', 'STATE', 'DEFINITION', 'WAREHOUSE', 'DATABASE_NAME', 'SCHEMA_NAME', 'OWNER', 'COMMENT',
        'SCHEDULE', 'PREDECESSORS', 'CONDITION', 'ALLOW_OVERLAPPING_EXECUTION', 'ERROR_INTEGRATION',
        'LAST_COMMITTED_ON', 'LAST_SUSPENDED_ON', 'ID'
        ]

    if df_task.empty:
        return pd.DataFrame(columns=cols)
    else:
        df_task = df_task[cols]
        df_task['CREATED_ON'] = df_task['CREATED_ON'].dt.strftime('%Y-%m-%d %H:%M:%S')
        df_task['STATE'] = df_task['STATE'].str.upper()
        return df_task


def load_data_task_hist(task_names):
    session = get_snowpark_session()
    cols = [
        'NAME', 'DATABASE_NAME', 'SCHEMA_NAME', 'SCHEDULED_TIME', 'STATE', 'QUERY_START_TIME', 'COMPLETED_TIME',
        'ERROR_CODE', 'ERROR_MESSAGE', 'QUERY_ID', 'NEXT_SCHEDULED_TIME', 'SCHEDULED_FROM'
    ]

    df_hist_list = []

    for task_name in task_names:
        query_task_history = f"""
            SELECT *
            FROM TABLE(SNOWFLAKE.INFORMATION_SCHEMA.TASK_HISTORY(result_limit => 1000,
            task_name=>'{task_name}')) 
            ORDER BY SCHEDULED_TIME 
            DESC;
            """
        df_hist = pd.DataFrame(session.sql(query_task_history).collect())
        df_hist.columns = [c.upper() for c in df_hist.columns]

        if not df_hist.empty:
            df_hist = df_hist[cols]
            df_hist['SCHEDULED_TIME'] = df_hist['SCHEDULED_TIME'].dt.strftime('%m-%d-%y %H:%M:%S')
            df_hist['STATE'] = df_hist['STATE'].str.upper()
            df_hist_list.append(df_hist)
    if len(df_hist_list) == 0:
        return pd.DataFrame(columns=cols)
    else:
        df_hist = pd.concat(df_hist_list, axis=0, ignore_index=True).reset_index(drop=True)
    return df_hist


def get_environment_table():
    session = get_snowpark_session()

    environment_table_name = os.environ['ENV_TABLE_NAME']

    environment_table = pd.DataFrame(session.sql(f"select * from {environment_table_name};").collect())
    if environment_table.empty:
        environment_table = pd.DataFrame(columns=[
            'JOBID', 'ENVIRONEMNT_ID', 'DBNAME', 'WAREHOUSE_NAME', 'SNOW_ROLE', 'CONNECTION_TYPE'
        ])
    else:
        environment_table['DBNArME'] = environment_table['DBNAME'].astype(str).str.upper()
        environment_table['WAREHOUSE_NAME'] = environment_table['WAREHOUSE_NAME'].astype(str).str.upper()

    return environment_table


