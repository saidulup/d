
import os
import pandas as pd
from src.db.snowflake.database import get_snowpark_session
import streamlit as st


@st.cache_data(ttl=120)
def task_exists(task_name):
    session = get_snowpark_session()
    task_db = os.environ.get('TASK_DATABASE')
    task_schema = os.environ.get('TASK_SCHEMA')
    try:
        session.sql(f'USE DATABASE {task_db}').collect()
        session.sql(f'USE SCHEMA {task_schema}').collect()
        result = pd.DataFrame(session.sql(f"SHOW TASKS LIKE '{task_name}'").collect())
        if result.empty:
            return False
        else:
            return True
    except Exception as e:
        st.error('Error checking task')
        st.error(e)
        return


def create_snowflake_task(warehouse,  proc_name, task_name, jname, estep, env_id, sfreq, cron_string):
    create_task_query = f"""
    CREATE TASK {task_name}
    WAREHOUSE = {warehouse}
    SCHEDULE = 'USING CRON {cron_string} UTC'
    AS
    CALL {proc_name}('{jname}', '{estep}', '{env_id}', '{sfreq}' );
    """
    task_db = os.environ.get('TASK_DATABASE')
    task_schema = os.environ.get('TASK_SCHEMA')
    session = get_snowpark_session()

    try:
        # Create the task
        session.sql(f'USE DATABASE {task_db}').collect()
        session.sql(f'USE SCHEMA {task_schema}').collect()
        session.sql(create_task_query).collect()
        # Created task will always be in suspended state, so resume it
        session.sql(f'ALTER TASK {task_name} RESUME').collect()
        st.success('Task created successfully')
        return 'Success'

    except Exception as e:
        st.error(f'Error occurred while trying to create task : {task_db}.{task_schema}.{task_name}')
        st.error(e)


def update_snowflake_task(warehouse, proc_name, task_name, jname, estep, env_id, sfreq, cron_string):
    create_task_query = f"""
    CREATE OR REPLACE TASK {task_name}
    WAREHOUSE = {warehouse}
    SCHEDULE = 'USING CRON {cron_string} UTC'
    AS
    CALL {proc_name}('{jname}', '{estep}', '{env_id}', '{sfreq}');
    """

    task_db = os.environ.get('TASK_DATABASE')
    task_schema = os.environ.get('TASK_SCHEMA')
    session = get_snowpark_session()
    try:
        session.sql(f'USE DATABASE {task_db}').collect()
        session.sql(f'USE SCHEMA {task_schema}').collect()
        result = pd.DataFrame(session.sql(create_task_query).collect())
        # Created task will always be in suspended state, so resume it
        session.sql(f'ALTER TASK {task_name} RESUME').collect()
        st.success('Task Updated successfully')
        return 'Success'

    except Exception as e:
        st.error(f'Error occurred while trying to updating task : {task_db}.{task_schema}.{task_name}')
        st.error(e)
        return


def delete_snowflake_task(database, schema, task_name):
    session = get_snowpark_session()
    try:
        session.sql(f'USE DATABASE {database}').collect()
        session.sql(f'USE SCHEMA {schema}').collect()
        session.sql(f'DROP TASK {task_name}').collect()

        st.success('Task deleted successfully')
        return 'Success'

    except Exception as e:
        st.error(f'Error occurred while trying to delete task : {task_name}')
        st.error(e)


def execute_snowflake_task(warehouse, database, schema, task_name):
    session = get_snowpark_session()

    try:
        session.sql(f'use warehouse {warehouse}').collect()
        session.sql(f'use database {database}').collect()
        session.sql(f'use schema {schema}').collect()

        # Create the task
        session.sql(f" EXECUTE TASK {task_name}; ").collect()

        st.success('Task Executed successfully')
        return 'Success'

    except Exception as e:
        st.error('Error Executing task')
        st.error(e)
        return


def suspend_snowflake_task(database, schema, task_name):
    session = get_snowpark_session()
    try:
        session.sql(f'USE DATABASE {database}').collect()
        session.sql(f'USE SCHEMA {schema}').collect()
        session.sql(f'ALTER TASK {task_name} SUSPEND').collect()

        st.success('Task suspended successfully')
        return 'Success'

    except Exception as e:
        st.error(f'Error occurred while trying to suspend task : {task_name}')
        st.error(e)
        return


def resume_snowflake_task(database, schema, task_name):
    session = get_snowpark_session()
    try:
        session.sql(f'USE DATABASE {database}').collect()
        session.sql(f'USE SCHEMA {schema}').collect()
        session.sql(f'ALTER TASK {task_name} RESUME').collect()

        st.success('Task resumed successfully')
        return 'Success'

    except Exception as e:
        st.error('Error resuming task')
        st.error(e)
        return