
import time
import streamlit as st
from streamlit import session_state as sst

from src.pages.task_scheduler.tab_manage import render_task_scheduler_manage_tab
from src.pages.task_scheduler.tab_monitor import render_task_monitoring_tab
from src.pages.data_utils import product_warehouse_status, get_job_config_table


from src.pages.utils.console_components import back_button
from src.auth.auth_widgets import logout_button


st.set_page_config(layout="wide", initial_sidebar_state='collapsed')

if sst.get('filter_data') is None:
    # if st.button('⬅️ Back', key='back from jobconfig', type='primary'):
    st.switch_page('app.py')


page_key = 'task_scheduler_page'
unsaved_changes_state = '' # No unsaved changes state for task scheduler
page_states = [
    'ts_list_tasks',
    'ts_task_list',
    'ts_task_hist',
]
back_page = 'pages/1_Admin_Console.py'



def main():
    # Logout Button
    with st.sidebar:
        logout_button()

    # Go Back button
    back_button(page_key, back_page, unsaved_changes_state, page_states)

    product_data = sst['filter_data']
    product_id = product_data['product_id']
    product_name = product_data['product_name']
    product_data_domain = product_data['data_domain']
    product_database = product_data['product_database']
    product_warehouse = product_data['product_warehouse']
    warehouse_state = product_warehouse_status(product_warehouse)


    title_col, _, refresh_col = st.columns([5, 1, 1])

    title_col.markdown(f"### ❄️ :blue[Task Scheduler]")

    with refresh_col:
        st.text('')
        if st.button('Refresh', key='refresh_task_scheduler'):
            del_tasks = [
                'temp_job_config',
                'ts_list_tasks',
                'ts_task_list',
                'ts_task_hist',
            ]
            for key in del_tasks:
                if sst.get(key) is not None:
                    del sst[key]
    st.markdown(f"""
    ###### Product Id : :blue[{product_id}], Product Name : :blue[{product_name}], Data Domain : :blue[{product_data_domain}], Warehouse : :blue[{product_warehouse} {warehouse_state}]
    """)

    if sst.get('temp_job_config') is None:
        sst['temp_job_config'] = get_job_config_table(product_id, product_warehouse)
    jobconfig_df = sst['temp_job_config']
    if jobconfig_df.empty:
        st.warning('Jobs not yet configured for this product, please configure jobs first.')
        jobnames = []
        st.stop()
    else:
        jobnames = jobconfig_df['JOBNAME'].unique().tolist()
    product_data['jobnames'] = jobnames

    with st.container():
        manage_tab, monitor_tab = st.tabs(['Manage', 'Monitor'])

        with manage_tab:
            render_task_scheduler_manage_tab(product_data, warehouse_state)

        with monitor_tab:
            render_task_monitoring_tab(product_data)

