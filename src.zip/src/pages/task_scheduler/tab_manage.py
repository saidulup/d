
import re
import os
import pandas as pd
import streamlit as st
from streamlit import session_state as sst

from src.pages.task_scheduler.f_data import  load_data_task_list
from src.pages.task_scheduler.v_tasks import tasks_edit_grid
from src.pages.task_scheduler.w_create import render_task_scheduler_create_tab
from src.pages.task_scheduler.w_update import render_task_scheduler_update_tab
from src.pages.task_scheduler.f_manage import delete_snowflake_task, execute_snowflake_task, suspend_snowflake_task, resume_snowflake_task
from src.pages.utils.elements import refresh_page


def task_prefix_generator(product_name: str, product_data_domain: str):
    task_prefix = os.environ.get('TASK_PREFIX', '').upper()
    if not product_data_domain:
        product_task_prefix = f'{task_prefix}_{product_name}'.upper()
    else:
        product_task_prefix = f'{task_prefix}_{product_name}_{product_data_domain}'.upper()

    # Replace whitespace with _
    product_task_prefix = re.sub(r'\s', '_', product_task_prefix)

    # Strip any special chars except A-Z, a-z, 0-9, and _
    product_task_prefix = re.sub(r'[^A-Za-z0-9_]', '', product_task_prefix)
    return product_task_prefix

@st.fragment()
def render_task_scheduler_manage_tab(product_data: dict, warehouse_state: str):
    key = 'manage_tasks'
    product_task_prefix = task_prefix_generator(product_data['product_name'], product_data['data_domain'])

    if sst.get('ts_list_tasks') is None:
        sst['ts_list_tasks'] = load_data_task_list(product_task_prefix)

    df = sst['ts_list_tasks']
    if df.empty:
        st.info('No tasks to display')

    grid = tasks_edit_grid(df, cbox=True, key='manage tasks')
    selected_tasks = pd.DataFrame(grid['selected_rows'])

    action = st.radio(
        label='Action',
        options=['Add New', 'Edit Selected', 'State'],
        index=None,
        horizontal=True,

        key=f'{key}_action',
        label_visibility='collapsed'
    )
    if action == 'Add New':
        render_task_scheduler_create_tab(product_task_prefix, product_data, warehouse_state, key='create from manage tab')

    elif action == 'Edit Selected':
        if selected_tasks.empty:
            st.warning('No tasks selected')
        else:
            old_task_data = selected_tasks.iloc[0].to_dict()
            render_task_scheduler_update_tab(product_data, warehouse_state, old_task_data, key='update from manage tab')

    elif action == 'State':
        st.text('')
        state_action_col, action_col = st.columns([1, 5])
        with state_action_col:
            with st.container(border=True):
                state_action = st.radio(
                    label='State/Action',
                    options=['Resume', 'Execute', 'Suspend', 'Delete'],
                    index=None,
                    # horizontal=True,

                    key=f'{key}_state_action',
                    # label_visibility='collapsed'
                )
        with action_col:
            st.text('')
            with st.container(border=True):
                if selected_tasks.empty:
                    st.warning('No tasks selected')
                else:
                    task_warehouse = selected_tasks['WAREHOUSE'].iloc[0]
                    task_database = selected_tasks['DATABASE_NAME'].iloc[0]
                    task_schema = selected_tasks['SCHEMA_NAME'].iloc[0]
                    selected_task_name = selected_tasks['NAME'].iloc[0]

                    if state_action == 'Suspend':
                        suspend_text_col, suspend_button_col = st.columns([1, 1])
                        with suspend_text_col:
                            suspend_confirmation = st.text_input(
                                label='Type SUSPEND to confirm',
                                placeholder='SUSPEND',
                                value='',
                                key=f'{key}_suspend_confirmation',
                            ).strip()
                        with suspend_button_col:
                            st.text('')
                            st.text('')
                            suspend_confirmation_button = st.button(
                                label='Confirm Suspension',
                                key=f'{key}_suspend_confirmation_button',
                            )

                        if suspend_confirmation_button and suspend_confirmation == 'SUSPEND':
                            with st.spinner('Suspending tasks...'):
                                status = suspend_snowflake_task(task_database, task_schema, selected_task_name)

                            refresh_page(status, ['ts_list_tasks'], 5)

                    elif state_action == 'Resume':
                        resume_text_col, resume_button_col = st.columns([1, 1])
                        with resume_text_col:
                            resume_confirmation = st.text_input(
                                label='Type RESUME to confirm',
                                placeholder='RESUME',
                                value='',
                                key=f'{key}_resume_confirmation',
                            ).strip()
                        with resume_button_col:
                            st.text('')
                            st.text('')
                            resume_confirmation_button = st.button(
                                label='Confirm Resumption',
                                key=f'{key}_resume_confirmation_button',
                            )

                        if resume_confirmation_button and resume_confirmation == 'RESUME':
                            with st.spinner('Resuming tasks...'):
                                status = resume_snowflake_task(task_database, task_schema, selected_task_name)

                            refresh_page(status, ['ts_list_tasks'], 5)

                    elif state_action == 'Delete':
                        delete_text_col, delete_button_col = st.columns([1, 1])
                        with delete_text_col:
                            delete_confirmation = st.text_input(
                                label='Type DELETE to confirm',
                                placeholder='DELETE',
                                value='',
                                key=f'{key}_delete_confirmation',
                            ).strip()
                        with delete_button_col:
                            st.text('')
                            st.text('')
                            delete_confirmation_button = st.button(
                                label='Confirm Deletion',
                                key=f'{key}_delete_confirmation_button',
                            )

                        if delete_confirmation_button and delete_confirmation == 'DELETE':
                            with st.spinner('Deleting tasks...'):
                                status = delete_snowflake_task(task_database, task_schema, selected_task_name)

                            refresh_page(status, ['ts_list_tasks'], 5)

                    elif state_action == 'Execute':
                        execute_text_col, execute_button_col = st.columns([1, 1])
                        with execute_text_col:
                            execute_confirmation = st.text_input(
                                label='Type EXECUTE to confirm',
                                placeholder='EXECUTE',
                                value='',
                                key=f'{key}_execute_confirmation',
                            ).strip()
                        with execute_button_col:
                            st.text('')
                            st.text('')
                            execute_confirmation_button = st.button(
                                label='Confirm Execution',
                                key=f'{key}_execute_confirmation_button',
                            )

                        if execute_confirmation_button and execute_confirmation == 'EXECUTE':
                            with st.spinner('Executing tasks...'):
                                status = execute_snowflake_task(task_warehouse, task_database, task_schema, selected_task_name)

                            refresh_page(status, ['ts_list_tasks'], 5)
