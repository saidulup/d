
# import statement START
import re
import os
import pandas as pd
import streamlit as st
from streamlit import session_state as sst

import plotly.express as px
from src.pages.task_scheduler.f_data import load_data_task_list, load_data_task_hist
from src.db.snowflake.database import get_snowpark_session

from src.pages.task_scheduler.v_tasks import tasks_edit_grid


# Variable declaration START
session = get_snowpark_session()
red_color = '#ff006e'
sky_blue = '#48cae4'
blue_color = '#3a86ff'


def task_prefix_generator(product_name: str, product_data_domain: str):
    task_prefix = os.environ.get('TASK_PREFIX', '').upper()
    if not product_data_domain:
        product_task_prefix = f'{task_prefix}_{product_name}'.upper()
    else:
        product_task_prefix = f'{task_prefix}_{product_name}_{product_data_domain}'.upper()

    # Replace whitespace with _
    product_task_prefix = re.sub(r'\s', '_', product_task_prefix)

    # Strip any special chars except A-Z, a-z, 0-9, and _
    product_task_prefix = re.sub(r'[^A-Za-z0-9_]', '', product_task_prefix)
    return product_task_prefix


def metric_card(label='', value=0, color=''):
    st.write(f"""
    <div style='width:90%; margin:auto; padding:.5rem 1rem; border: solid 2px {sky_blue}; border-radius:4px; shadow:3px'>
        <p style='font-size:1rem ;padding:0px; margin:0px; line-height:2rem'>
        {label} <br>
        <span style='text-align:right; font-size:2rem;  padding:0px; color: {color}; '>{value}</span>
        </p>
    </div>
    """, unsafe_allow_html=True)

@st.fragment()
def render_task_monitoring_tab(product_data: dict):
    product_task_prefix = task_prefix_generator(product_data['product_name'], product_data['data_domain'])
    with st.spinner("Please wait while we load the Data from Snowflake..."):
        if sst.get('ts_task_list') is None:
            sst['ts_task_list'] = load_data_task_list(product_task_prefix)

        if sst.get('ts_task_hist') is None:
            sst['ts_task_hist'] = load_data_task_hist(sst['ts_task_list']['NAME'].unique().tolist())

    task_list = sst.get('ts_task_list')
    task_hist = sst.get('ts_task_hist')

    # from task list
    total_task_count = len(task_list)
    suspended_task_count = len(task_list[task_list['STATE'] == 'SUSPENDED'])
    running_task_count = len(task_list[task_list['STATE'] == 'STARTED'])

    # from task history
    successful_task_count = len(task_hist[task_hist['STATE'] == 'SUCCEEDED'])
    failed_task_count = len(task_hist[(task_hist['STATE'] == 'FAILED') | (task_hist['STATE'] == 'FAILED_AND_AUTO_SUSPENDED')])
    executing_task_count = len(task_hist[task_hist['STATE'] == 'EXECUTING'])

    # Unexecuted tasks, # tasks that are scheduled(running) but not yet executed once
    # tasks that are found in task list but not in task history or present in task history but with state as scheduled
    value_counts = task_hist['NAME'].value_counts()
    temp_df = task_hist.copy()
    temp_df['VALUE_COUNTS'] = task_hist['NAME'].apply(lambda x: value_counts[x])
    temp_df = temp_df.loc[(temp_df['VALUE_COUNTS'] <= 1) & (temp_df['STATE'] == 'SCHEDULED')]
    unexecuted_task_count = len(temp_df)
    list_names = task_list['NAME'].unique().tolist()
    hist_names = task_hist['NAME'].unique().tolist()

    unexecuted_task_count = unexecuted_task_count + len([x for x in list_names if x not in hist_names])
    with st.container():
        cols = st.columns([1, 1, 1, 1, 1, 1, 1], gap='small')

        with cols[0]:
            metric_card(
                label="Total Tasks",
                value=total_task_count,
                color=blue_color
            )

        with cols[1]:
            metric_card(
                label="Suspended",
                value=suspended_task_count,
                color=red_color
            )

        with cols[2]:
            metric_card(
                label="Started",
                value=running_task_count,
                color=red_color
            )

        with cols[3]:
            metric_card(
                label="Successful",
                value=successful_task_count,
                color=blue_color
            )

        with cols[4]:
            metric_card(
                label="Failed",
                value=failed_task_count,
                color=red_color
            )

        with cols[5]:
            metric_card(
                label="Executing",
                value=executing_task_count,
                color=blue_color
            )

        with cols[6]:
            metric_card(
                label="UnExecuted",
                value=unexecuted_task_count,
                color=red_color
            )

    if task_list.empty:
        st.info('No Tasks to display')
        return

    st.write('')
    grid = tasks_edit_grid(task_list, cbox=True, key='task list')

    selected_tasks = pd.DataFrame(grid['selected_rows'])
    if selected_tasks.empty:
        st.info('Select a Task to view the Execution History')
        return

    selected_task_name = selected_tasks['NAME'].iloc[0]

    grid_tab, chart_tab = st.tabs(['Task Execution History', 'Task Execution Chart'])

    with chart_tab:
        task_records = task_hist.loc[
            (task_hist['NAME'] == selected_task_name) &
            (task_hist['STATE'] != 'SCHEDULED')
        ]
        task_records = task_records.reset_index(drop=True)

        sun_burst_col, line_col = st.columns([1, 5])
        with sun_burst_col:
            scheduled_records = task_records.loc[
                (task_records['SCHEDULED_FROM'] == 'SCHEDULE') &
                (task_records['STATE'] != 'SCHEDULED')
                ]
            manual_records = task_records.loc[task_records['SCHEDULED_FROM'] == 'EXECUTE TASK']

            scheduled_runs = len(scheduled_records)
            scheduled_successful_runs = len(scheduled_records.loc[scheduled_records['STATE'] == 'SUCCEEDED'])
            scheduled_failed_runs = len(scheduled_records.loc[scheduled_records['STATE'] == 'FAILED'])
            scheduled_executing_runs = len(scheduled_records.loc[scheduled_records['STATE'] == 'EXECUTING'])

            manual_runs = len(task_records.loc[task_records['SCHEDULED_FROM'] == 'EXECUTE TASK'])
            manual_successful_runs = len(manual_records.loc[manual_records['STATE'] == 'SUCCEEDED'])
            manual_failed_runs = len(manual_records.loc[manual_records['STATE'] == 'FAILED'])
            manual_executing_runs = len(manual_records.loc[manual_records['STATE'] == 'EXECUTING'])

            plot_df = pd.DataFrame({
                'Type': ['Scheduled', 'Scheduled', 'Scheduled', 'Manual', 'Manual', 'Manual'],
                'Status': ['Successful', 'Failed', 'Successful', 'Executing',  'Failed', 'Executing'],
                'Count': [
                    scheduled_successful_runs, scheduled_failed_runs, scheduled_executing_runs,
                    manual_successful_runs, manual_failed_runs, manual_executing_runs]
            })

            if plot_df['Count'].sum() == 0:
                st.info('Task not yet executed')
            else:
                fig = px.sunburst(
                    plot_df,
                    path=['Type', 'Status'],
                    values='Count',
                    color='Status',
                    color_discrete_map={
                        'Successful': blue_color,
                        'Failed': red_color
                    },
                    template='plotly_white',
                )
                st.plotly_chart(fig, use_container_width=True)
        with line_col:
            # st.write(task_records)
            temp_df = task_records.copy()
            temp_df['SCHEDULED_TIME'] = pd.to_datetime(temp_df['SCHEDULED_TIME'])
            temp_df['COUNT'] = 1

            grouped_df = temp_df.groupby([pd.Grouper(key='SCHEDULED_TIME', freq='D'), 'STATE'], as_index=False).agg(
                {'COUNT': 'count'})
            # st.write(grouped_df)
            if grouped_df['COUNT'].sum() == 0:
                st.warning('')
            else:
                line_plot = px.line(grouped_df, x='SCHEDULED_TIME', y='COUNT', color='STATE', symbol='STATE')
                st.plotly_chart(line_plot, use_container_width=True,)

    with grid_tab:
        if task_records.empty:
            st.info('Task not yet executed')
        else:
            tasks_edit_grid(task_records, cbox=False, key='task_records')


