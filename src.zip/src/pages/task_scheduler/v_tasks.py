
from src.pages.utils.src_agstyler import draw_grid


class Color:
    RED_LIGHT = "#fcccbb"
    GREEN_LIGHT = "#abf7b1"

    BLUE = "#8ecae6"
    GREEN = "#219ebc"
    ORANGE = "#ffb703"
    PINK_RED = "#fb8500"


def tasks_edit_grid(df, cbox: bool = False, key=''):
    key = f"Tasks edit : {key}"

    formatter = {c : (c.upper(), {}) for c in df.columns}

    # gd.configure_columns("Notes", wrapText=True)
    # gd.configure_columns("Notes", autoHeight=True)
    grid_options = None
    custom_css = None
    selection = 'single'
    use_checkbox = cbox

    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=False,
        auto_height=True,
        pagination=True
    )


def tasks_view_grid(df, cbox: bool = False, key=''):
    key = f"Task view grid : {key}"

    formatter = {c : (c.upper(), {}) for c in df.columns}

    # gd.configure_columns("Notes", wrapText=True)
    # gd.configure_columns("Notes", autoHeight=True)
    grid_options = None
    custom_css = None
    selection = 'single'
    use_checkbox = cbox

    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=False,
        auto_height=True,
        pagination=True
    )
