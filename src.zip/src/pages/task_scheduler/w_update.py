import re
from cron_validator import CronValidator
import streamlit as st

from src.pages.task_scheduler.f_manage import update_snowflake_task
from src.pages.utils.elements import refresh_page


def validate_cron_string(cron_string):
    if not cron_string:
        return False
    cron_string = str(cron_string).strip()
    try:
        cron_validation = CronValidator.parse(cron_string)
        return True
    except Exception as e:
        return False

@st.fragment()
def render_task_scheduler_update_tab(product_data: dict, warehouse_state: str, task_data: dict, key=''):

    key = 'update_task_scheduler' + key
    old_warehouse = task_data.get('WAREHOUSE')
    old_task_name = task_data.get('NAME', '')

    old_definition = task_data.get('DEFINITION', '')
    arguments = re.findall(r"'([^']*)'", old_definition)
    # st.write(arguments)
    if len(arguments) == 4:
        old_jname = arguments[0]
        old_estep = arguments[1]
        old_env_id = int(arguments[2].strip())
        old_sfreq = arguments[3].strip()
    else:
        old_jname, old_estep, old_env_id,  old_sfreq = '', '', None, ''
    old_cron_string = task_data.get('SCHEDULE', '').replace('USING CRON', '').strip().replace('UTC', '').strip()
    old_cron_string_status = validate_cron_string(old_cron_string)

    proc_name = 'DS_SP_JOBQUEUE'
    # parameters
    with st.container():

        warehouse_col, env_col, _ = st.columns([1, 1, 2])

        with warehouse_col:
            # product_warehouse = product_data['product_warehouse']
            warehouse = st.selectbox(
                label='Warehouse',
                options=[old_warehouse],
                disabled=True,
                key=f'warehouse {key}'
            )

        with env_col:
            env_name_options = ['PRD', 'STG', 'DEV']
            old_env_name = 'PRD' if old_env_id == 1 else 'STG' if old_env_id == 2 else 'DEV'
            env_name = st.selectbox(
                label='Environment',
                options=env_name_options,
                index=env_name_options.index(old_env_name) if old_env_name in env_name_options else 0,
                key=f'environment {key}'
            )
            env_id = 1 if env_name == 'PRD' else 2 if env_name == 'STG' else 3

        tname_col, jname_col, estep_col, sfreq_col = st.columns([1, 1, 1, 1])
        with tname_col:
            task_name = st.text_input(
                label='Task Name',
                value=old_task_name,
                disabled=True,
                key=f'task name {key}',
            ).strip()
        with jname_col:
            job_name = st.text_input(
                label='Job Name',
                value=old_jname,
                placeholder='Enter Job Name',
                key=f'job name {key}',
                disabled=True,
            ).strip()
        with estep_col:
            estep_options = ['POST-CHECK', 'PRE-CHECK']
            index = estep_options.index(old_estep) if old_estep in estep_options else 0
            estep = st.selectbox(
                label='Execution Step',
                options=estep_options,
                index=index,
                key=f'estep {key}',
                disabled=True,
            ).strip()
        with sfreq_col:
            sfreq_options = ['0', '1']
            index = sfreq_options.index(old_sfreq) if old_sfreq in sfreq_options else 0
            sfreq = st.selectbox(
                label='Schedule Frequency',
                options=sfreq_options,
                index=index,
                disabled=True,
                key=f'sfreq {key}'
            )

    with st.expander('Schedule Task', expanded=True):
        freq_col, time_col = st.columns([1, 5])
        with freq_col:
            freq_options = [
                'BY MINUTES', 'BY HOURS', 'HOURLY', 'DAILY', 'WEEKLY', 'WEEKDAYS', 'WEEKENDS',
                'MONTHLY', 'QUARTERLY', 'SEMI-ANNUALLY',  'YEARLY',
                'CRON']
            freq = st.selectbox(
                label='Frequency',
                options=freq_options,
                index=freq_options.index('CRON') if old_cron_string_status else 0,
                key=f'frequency {key}'
            )

        with time_col:
            cron_string = None
            if freq == 'CRON':
                cron_string = st.text_input(
                    label='Cron String',
                    value=old_cron_string if old_cron_string_status else '',
                    key=f'cron string {key}'
                )

            elif freq == 'BY MINUTES':
                by_minutes = st.selectbox(
                    label='Minutes',
                    options=[None, 1]+[str(i) for i in range(5, 60, 5)],
                    key=f'by minutes {key}'
                )
                if by_minutes:
                    cron_string = f'*/{by_minutes} * * * *'

            elif freq == 'BY HOURS':
                hour_col, minute_col = st.columns([1, 1])
                with hour_col:
                    by_hours = st.selectbox(
                        label='Hours',
                        options=[None] + [str(i) for i in range(1, 24)],
                        key=f'by hours {key}'
                    )
                with minute_col:
                    by_minutes = st.selectbox(
                        label='Minutes',
                        options=[None] + [str(i) for i in range(5, 60, 5)],
                        key=f'by minutes {key}'
                    )

                if by_hours and by_minutes:
                    cron_string = f'{by_minutes} */{by_hours} * * *'

            elif freq == 'HOURLY':
                hourly_time = st.select_slider(
                    label='Time',
                    options=[None]+[str(i) for i in range(60)],
                    key=f'hourly time {key}'
                )
                if hourly_time:
                    cron_string = f'{hourly_time} * * * *'

            elif freq == 'DAILY':
                daily_time = st.time_input(
                    label='Time',
                    value=None,
                    key=f'daily time {key}'
                )
                if daily_time:
                    cron_string = daily_time.strftime('%M %H * * *')

            elif freq == 'WEEKLY':
                day_col, time_col = st.columns([1, 1])
                with day_col:
                    weekly_day = st.selectbox(
                        label='Day',
                        options=['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'],
                        key=f'weekly day {key}'
                    )
                with time_col:
                    weekly_time = st.time_input(
                        label='Time',
                        value=None,
                        key=f'weekly time {key}'
                    )
                if weekly_day and weekly_time:
                    cron_string = f'{weekly_time.strftime("%M %H")} * * {weekly_day}'

            elif freq == 'WEEKDAYS':
                weekdays_time = st.time_input(
                    label='Time',
                    value=None,
                    key=f'weekdays time {key}'
                )
                if weekdays_time:
                    cron_string = weekdays_time.strftime('%M %H * * 1-5')

            elif freq == 'WEEKENDS':
                weekends_time = st.time_input(
                    label='Time',
                    value=None,
                    key=f'weekends time {key}'
                )
                if weekends_time:
                    cron_string = weekends_time.strftime('%M %H * * 0,6')

            elif freq == 'MONTHLY':
                day_col, time_col = st.columns([1, 1])
                with day_col:
                    monthly_day = st.selectbox(
                        label='Day',
                        options=[str(i) for i in range(1, 32)],
                        key=f'monthly day {key}'
                    )
                with time_col:
                    monthly_time = st.time_input(
                        label='Time',
                        value=None,
                        key=f'monthly time {key}'
                    )
                if monthly_time and monthly_day:
                    cron_string = f'{monthly_time.strftime("%M %H")} {monthly_day} * *'

            elif freq == 'QUARTERLY':

                first_qmonth_col, second_qmonth_col, third_qmonth_col, fourth_month_col, day_col, time_col = st.columns([1, 1, 1, 1, 1, 1])

                with first_qmonth_col:
                    first_quarterly_month = st.selectbox(
                        label='First Quarter Month',
                        options=['JAN', 'FEB', 'MAR'],
                        key=f'first quarterly month {key}'
                    )

                with second_qmonth_col:
                    second_quarterly_month = st.selectbox(
                        label='Second Quarter Month',
                        options=['APR', 'MAY', 'JUN'],
                        key=f'second quarterly month {key}'
                    )

                with third_qmonth_col:
                    third_quarterly_month = st.selectbox(
                        label='Third Quarter Month',
                        options=['JUL', 'AUG', 'SEP'],
                        key=f'third quarterly month {key}'
                    )

                with fourth_month_col:
                    fourth_quarterly_month = st.selectbox(
                        label='Fourth Quarter Month',
                        options=['OCT', 'NOV', 'DEC'],
                        key=f'fourth quarterly month {key}'
                    )

                with day_col:
                    quarterly_day = st.selectbox(
                        label='Day',
                        options=[str(i) for i in range(1, 32)],
                        key=f'quarterly day {key}'
                    )
                with time_col:
                    quarterly_time = st.time_input(
                        label='Time',
                        value=None,
                        key=f'quarterly time {key}'
                    )

                if quarterly_time and quarterly_day and first_quarterly_month and second_quarterly_month and third_quarterly_month and fourth_quarterly_month:
                    cron_string = f'{quarterly_time.strftime("%M %H")} {quarterly_day} {first_quarterly_month},{second_quarterly_month},{third_quarterly_month},{fourth_quarterly_month} *'

            elif freq == 'SEMI-ANNUALLY':
                first_month_col, second_month_col, day_col, time_col = st.columns([1, 1, 1, 1])
                with first_month_col:
                    first_semi_annual_month = st.selectbox(
                        label='Month',
                        options=['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',],
                        key=f'first semi-annual month {key}'
                    )

                with second_month_col:
                    second_semi_annual_month = st.selectbox(
                        label='Month',
                        options=['JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
                        key=f'second semi-annual month {key}'
                    )

                with day_col:
                    semi_annual_day = st.selectbox(
                        label='Day',
                        options=[str(i) for i in range(1, 32)],
                        key=f'semi-annual day {key}'
                    )
                with time_col:
                    semi_annual_time = st.time_input(
                        label='Time',
                        value=None,
                        key=f'semi-annual time {key}'
                    )

                if semi_annual_time and semi_annual_day and first_semi_annual_month and second_semi_annual_month:
                    cron_string = f'{semi_annual_time.strftime("%M %H")} {semi_annual_day} {first_semi_annual_month},{second_semi_annual_month} *'

            elif freq == 'YEARLY':
                month_col, day_col, time_col = st.columns([1, 1, 1])

                with month_col:
                    yearly_month = st.selectbox(
                        label='Month',
                        options=['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
                                 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
                        key=f'yearly month {key}'
                    )

                with day_col:
                    yearly_day = st.selectbox(
                        label='Day',
                        options=[str(i) for i in range(1, 32)],
                        key=f'yearly day {key}'
                    )

                with time_col:
                    yearly_time = st.time_input(
                        label='Time',
                        value=None,
                        key=f'yearly time {key}'
                    )


                if yearly_time and yearly_day and yearly_month:
                    cron_string = f'{yearly_time.strftime("%M %H")} {yearly_day} {yearly_month} *'

            else:
                pass

    cron_validation = validate_cron_string(cron_string)
    st.markdown(f"Selected Cron String: :blue[{cron_string}], Valid Status: :blue[{cron_validation}]")
    st.markdown(f"Old Cron String: :blue[{old_cron_string}]")
    update_task = st.button(
        label='Update Task',
        key=f'Update task {key}'
    )

    if update_task:
        # validate inputs
        validation_states = []

        if not task_name:
            st.error('Task Name Should not be Empty')
            validation_states.append(False)

        if ' ' in task_name:
            st.error('Task Name Should not contain spaces')
            validation_states.append(False)

        if not job_name:
            st.error('Job Name Should not be empty')
            validation_states.append(False)

        if not warehouse:
            st.error('Warehouse is Required')
            validation_states.append(False)

        if warehouse_state == 'Not Found':
            st.error('Warehouse is Suspended')
            validation_states.append(False)

        if not cron_string:
            st.error('Schedule is Invalid / Empty')
            validation_states.append(False)

        if False not in validation_states:
            with st.spinner('Updating Task Please Wait ..'):
                status = update_snowflake_task(warehouse, proc_name, task_name, job_name, estep, env_id, sfreq, cron_string)

            refresh_page(status, ['ts_list_tasks'], 5)
