
from src.pages.utils.src_agstyler import draw_grid


class Color:
    RED_LIGHT = "#fcccbb"
    GREEN_LIGHT = "#abf7b1"

    BLUE = "#8ecae6"
    GREEN = "#219ebc"
    ORANGE = "#ffb703"
    PINK_RED = "#fb8500"


def job_config_jobid_select_grid(df, key=''):
    key = f"Job Config : deletable : {key}"

    formatter = {
        'JOBID': ('JOBID', {'editable': False}),
        'JOBNAME': ('JOBNAME', {'editable': False}),
        'JOBDESCRIPTION': ('JOBDESCRIPTION', {'editable': False}),
        'EXECUTIONSTEP': ('EXECUTIONTYPE', {'editable': False}),
        'EMAILTO': ('EMAILTO', {'editable': False}),
        'FAILUREEMAILTO': ('FAILUREEMAILTO', {'editable': False}),
        'JOBTIMEOUT': ('JOBTIMEOUT', {'editable': False}),
    }
    grid_options = None
    custom_css = None
    selection = 'single'
    use_checkbox = True
    return draw_grid(
        df,
        formatter=formatter,
        selection=selection,
        use_checkbox=use_checkbox,
        grid_options=grid_options,
        css=custom_css,
        key=key,
        fit_columns=False,
        theme="streamlit",
        wrap_text=False,
        auto_height=True,
        pagination=True,
    )
