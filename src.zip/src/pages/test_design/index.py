
import streamlit as st
from streamlit import session_state as sst

from src.pages.test_design.tab_update import render_ac_testplan

from src.pages.utils.console_components import back_button
from src.auth.auth_widgets import logout_button

st.set_page_config(layout="wide", initial_sidebar_state='collapsed')


if sst.get('filter_data') is None:
    # if st.button('⬅️ Back', key='back from jobconfig', type='primary'):
    st.switch_page('app.py')


page_key = 'test_design_page'
unsaved_changes_state = 'unsaved_testplan_changes'
page_states = [
    'tp_job_config_df',
    'tp_threshold_df',
    'previous_tp_job_id',
    'tp_testplan_df',
    'tp_testplan_df_key',
    'edited_tp_testplan_df',
    'tp_test_results_df',
    'unsaved_testplan_changes',

    'new_test_thresholds_df',
    'new_test_thresholds_df_key',
    'edited_new_test_threshold_df',

    'edit_test_thresholds_df',
    'edit_test_thresholds_df_key',
    'edited_edit_test_threshold_df',
]
back_page = 'pages/1_Admin_Console.py'




def main():
    # Logout Button
    with st.sidebar:
        logout_button()

    # Go Back button
    back_button(page_key, back_page, unsaved_changes_state, page_states)



    selected_product_id = sst['filter_data']['product_id']
    selected_product_name = sst['filter_data']['product_name']
    selected_data_domain = sst['filter_data']['data_domain']
    selected_database = sst['filter_data']['product_database']
    selected_warehouse = sst['filter_data']['product_warehouse']
    random_id = sst['filter_data']['random_id']

    st.markdown(f"### ❄️ :blue[Test Design]")
    render_ac_testplan(selected_product_id, selected_database, selected_warehouse, random_id)
