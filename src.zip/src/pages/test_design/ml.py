import os
from loguru import logger
from src.services.llm import LLMFactory


def extract_result_columns(query: str) -> tuple:
    """Parse the query and find out no of result columns and their names"""
    try:
        provider = LLMFactory.get_provider(os.getenv('LLM_PROVIDER', 'openai'))


        system_message = """
        You are a Snowflake SQL Validator and Column Extractor.

        You will receive snowflake SQL . It may include CTEs (WITH …), different snowflake supported subqueries, JOINs, window functions, QUALIFY, ORDER BY, LIMIT, and UNION/UNION ALL.

        TASK
        1) Validate it is a single, executable SELECT-only statement.
        - Final statement must be SELECT (CTEs allowed).
        - No DML/DDL/utility (INSERT/UPDATE/DELETE/MERGE/COPY/CALL/CREATE/ALTER/DROP/GRANT/REVOKE/USE, etc.).
        - No multiple statements; a single trailing semicolon is OK.
        - No wildcard in the final projection except inside COUNT(*).
        - Must be syntactically coherent for Snowflake.

        2) Business rules
        - Single-column SELECT:
            • Valid if it contains any aggregate function (e.g., SUM, COUNT, MIN, MAX, AVG).
            • If no explicit alias is provided (e.g., SELECT SUM(col)), use the function name in lowercase as the name (e.g., "sum", "count").
            • Any single-column projection of a bare column without an alias (e.g., SELECT col FROM t) → INVALID.
        - Multi-column SELECT (2–10 columns inclusive):
            • Snowflake-specific clauses like `GROUP BY ALL` are permitted.
            • Every output column MUST have a resolvable name. If an expression or bare column lacks an explicit alias, use the inferred Snowflake column name (typically the column name or the function name in lowercase).
        - Greater than 10 columns .
        - Incomplete Syntax: The query must be a complete, executable SELECT statement (e.g., `SELECT SUM(col) FROM table`). A fragment like `select sum` without arguments or a source is → INVALID.


        OUTPUT FORMAT (STRICT)
        - If VALID: return ONLY the column names from the OUTERMOST (final) SELECT, in order,
        as a single comma-separated string with NO SPACES, NO QUOTES, NO EXTRA TEXT.
        • Use aliases exactly as written.
        • For UNION/UNION ALL, use Snowflake’s resolved column names from the first SELECT branch after alias resolution.
        • Preserve identifier case as written.
        - If INVALID for ANY reason → return exactly: ""

        Do NOT include explanations, diagnostics, or any additional characters beyond the required output.
        
        """.strip()

        context = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": query}
        ]
        status, col_names = provider.get_completions('gpt-5-chat', context, 150, 0.1)
        print(query,status,col_names)
        if status is True:
            col_names = col_names.strip().strip('"')  # Remove any surrounding spaces and quotes
            if col_names == "":
                return 0, ""
            # Split by commas and count columns
            col_count = len(col_names.split(','))
            return col_count, col_names
        else:
            logger.error(f"LLM Request failed with error: {col_names}")
            return 0, ""
    except Exception as e:
        logger.error(f"Error extracting result columns from query: {query}. Error: {e}")
        return 0, ""


if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv('../../core/prod.env')
    query = "select count(*) as cnt   from QUMXA_PRD_STARS_DO_DB.DATAOPS_FOUNDATION.MNR_MDE_VW_DLY_MBR_CORE"
    #query = """select sum"""
    col_count, col_names = extract_result_columns(query)
    print(f"Column Count: {col_count}, Column Names: {col_names}")

