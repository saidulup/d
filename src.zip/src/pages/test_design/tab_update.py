
import random
import streamlit as st
from loguru import logger
from streamlit import session_state as sst

from src.pages.test_design.grids import *
from src.pages.data_utils import get_job_config_table, get_test_plan, get_threshold_table, get_test_categories
from src.pages.test_design.db import get_monitored_objects
from src.pages.test_design.w_results import results_widget
from src.pages.test_design.w_multiple_tests import multiple_tests_management_widget
from src.pages.test_design.w_single_test import single_test_management_widget


@st.fragment()
def render_ac_testplan(product_id, product_database,  product_warehouse, random_id):
    """Contents of the Test Design page's testplan table management tab"""

    # key for all the widgets in the page
    tab_key = 'manage_testplan_tab' + str(random_id)

    # Load the job config table when the page is reloaded
    if sst.get('tp_job_config_df') is None:
        logger.info("Loading Job configurations from DB")
        with st.spinner('Loading ...'):
            sst['tp_job_config_df'] = get_job_config_table(product_id, product_warehouse)
            # No need to reset, reload this state on page switching these are constants
            sst['tp_test_categories'] = get_test_categories(product_warehouse)

    test_categories = sst['tp_test_categories']

    # Load the job config table from session state
    job_config_df = sst['tp_job_config_df']

    # Load the product objects(cached as a session state, as it is not changed frequently)
    #product_database = 'DQM_DB'
    product_objects = get_monitored_objects(product_database)

    # If no jobs exist
    if job_config_df.empty:
        msg = f"No Job Config records found for the selected product id : {product_id}"
        logger.info(msg)
        st.info(msg)
        st.stop()

    # Display jobs as a grid and allow user to select a job/jobid
    grid_job_config = job_config_jobid_select_grid(job_config_df, key=f'{tab_key} : select a dsid')
    srows_job_config = grid_job_config['selected_rows']

    # Dont show below contents if no jobid is selected
    if len(srows_job_config) <= 0:
        return

    # Get the selected jobid/job name/execution step/environment id
    selected_job_id = srows_job_config[0]['JOBID']
    selected_job_name = srows_job_config[0]['JOBNAME']
    selected_exec_step = srows_job_config[0]['EXECUTIONSTEP']
    selected_env_id = srows_job_config[0]['ENVIRONMENT_ID']

    # Reset testplan related keys and states when job id is changed
    if sst.get('previous_tp_job_id') is None:
        sst['previous_tp_job_id'] = selected_job_id
    else:
        if sst['previous_tp_job_id'] != selected_job_id:
            # Job id changes drop all testplan and test results associated states
            sst['tp_testplan_df'] = None
            sst['tp_testplan_df_key'] = None
            sst['edited_tp_testplan_df'] = None
            sst['unsaved_testplan_changes'] = 0
            sst['tp_test_results_df'] = None

            sst['new_test_thresholds_df'] = None
            sst['new_test_thresholds_df_key'] = None
            sst['edited_new_test_threshold_df'] = None

            sst['edit_test_thresholds_df'] = None
            sst['edit_test_thresholds_df_key'] = None
            sst['edited_edit_test_threshold_df'] = None

            sst['previous_tp_job_id'] = selected_job_id

    # Show testplan and test results side by side
    testplan_tab, test_results_tab = st.tabs(['Test Plan', 'Test Results'])

    with test_results_tab:
        results_widget(product_warehouse, selected_job_id, selected_job_name, selected_exec_step, selected_env_id)

    with testplan_tab:
        # Reload testplan table, page loads for first time, job id is changed, cancel button is clicked
        if sst.get('tp_testplan_df') is None:
            logger.info("Loading Testplan table from DB")
            testplan_df = get_test_plan(selected_job_id, product_warehouse)

            # Convert DSID to string for consistency
            testplan_df['DSID'] = testplan_df['DSID'].astype(str)

            # Mark all records as 'edited' if the testplan table is not empty
            if not testplan_df.empty:
                testplan_df['COLOR_FLAG'] = 'edited'

            testplan_df.insert(0, '', False)
            sst['tp_testplan_df'] = testplan_df
            sst['tp_testplan_df_key'] = f"{tab_key}-tp edit grid-{random.randrange(0, 1000)}"

        # Reload threshold table if it doesn't exist
        if sst.get('tp_threshold_df') is None:
            sst['tp_threshold_df'] = get_threshold_table(product_warehouse)

        update_mode = st.radio(
            label='Update Mode',
            options=['Multi Row Updates', 'Single Row Update'],
            key=f'{tab_key} : update mode',
            horizontal=True,
            label_visibility='collapsed',
            help='Select the update mode for the test plan. Multi-row allows editing multiple rows at once, while single-row allows editing one row at a time.'
        )





        if update_mode == 'Multi Row Updates':
            multiple_tests_management_widget(
                product_id, product_database,
                product_warehouse,
                product_objects,
                selected_job_id,
                selected_job_name,
                test_categories,
                tab_key
            )
        else:
            single_test_management_widget(
                product_id,
                product_database,
                product_warehouse,
                product_objects,
                selected_job_id,
                selected_job_name,
                test_categories,
                tab_key
            )
