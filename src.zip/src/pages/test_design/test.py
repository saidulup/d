import os
from loguru import logger
from src.services.llm import LLMFactory


def extract_result_columns(query: str) -> tuple:
    """Parse the query and find out no of result columns and their names"""
    try:
        provider = LLMFactory.get_provider(os.getenv('LLM_PROVIDER', 'openai'))

        system_message = """
        You are snowflake SQL Expert you will be given a SQL SELECT statement.

        Your task:
        1. Check if the statement is a valid Snowflake executable SELECT query.
        2. If valid, return the column names, separated by commas (no spaces, no extra text).
           Example:
             Input:  "
             SELECT 
                s.student_id,
                s.first_name || ' ' || s.last_name AS full_name,
                c.course_name,
                CASE 
                    WHEN g.grade >= 90 THEN 'A'
                    WHEN g.grade >= 80 THEN 'B'
                    ELSE 'C'
                END AS letter_grade
            FROM students s
            JOIN grades g ON s.student_id = g.student_id
            JOIN courses c ON g.course_id = c.course_id
            WHERE s.active = TRUE;
             "
             Output: "student_id, full_name, course_name, letter_grade"            
             INPUT: "select name, count * from students"
             Output: ""

        3. If the query is invalid, has no selected columns, or does not make sense, return an empty string.
        """.strip()

        context = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": query}
        ]
        status, col_names = provider.get_completions('gpt-4o-mini', context, 150, 0.1)
        if status is True:
            col_names = col_names.strip().strip('"')  # Remove any surrounding spaces and quotes
            if col_names == "":
                return 0, ""
            # Split by commas and count columns
            col_count = len(col_names.split(','))
            return col_count, col_names
        else:
            logger.error(f"LLM Request failed with error: {col_names}")
            return 0, ""
    except Exception as e:
        logger.error(f"Error extracting result columns from query: {query}. Error: {e}")
        return 0, ""


if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv('../../core/prod.env')
    #query = "select msr_abr,Count( DISTINCT CASE WHEN c.msr_cmpln_val= 1 or c.msr_cmpln_val= 0 THEN c.enterprise_indv_id END) as DENOM, Count( DISTINCT CASE WHEN c.msr_cmpln_val= 1  THEN c.enterprise_indv_id END) as NUM, Count( DISTINCT CASE WHEN c.msr_cmpln_val= 0 THEN c.enterprise_indv_id END) as Opengaps  from QUMXA_PRD_STARS_DO_DB.DATAOPS_COMPACT.MNR_MDE_TBL_CMTH_MBR_MSR_PARTC c inner join QUMXA_PRD_STARS_DO_DB.DATAOPS_COMPACT.MNR_MDE_TBL_CMTH_MBR_CORE core on c.enterprise_indv_id=core.enterprise_indv_id inner join  QUMXA_PRD_STARS_DO_DB.DATAOPS_COMPACT.MNR_MDE_TBL_CMTH_MBR_DEMO demo on c.enterprise_indv_id=demo.enterprise_indv_id where  msr_cmpln_val in ('0','1')  group by msr_abr order by 1;"
    query = """SELECT  'abc' as cd ,
	count(*) AS Tot_Mismatch_count_By_PPM
FROM
	(
	SELECT
		PPM,
		count(*) AS QA_PPM_Count
	FROM
		(
		SELECT
			DM.mbr_mbi,
			CASE
				WHEN (n.PPM IS NULL
				OR n.PPM = '') THEN 'N/A'
				ELSE n.PPM
			END AS PPM
		FROM
			QUMXA_PRD_STARS_DO_DB.DATAOPS_FOUNDATION.MNR_MDE_VW_DLY_MBR_CORE DM
		LEFT JOIN QUMXA_PRD_STARS_DO_DB.DATAOPS_FOUNDATION.MNR_MDE_VW_DLY_MBR_PROV_XW xw ON
			DM.ENTERPRISE_INDV_ID = xw.ENTERPRISE_INDV_ID
		LEFT JOIN YDJV_PRD_STARS_BI_DB.BI_COMPACT.PROVIDER_GROUP_PPM_PPC_PPS n ON
			XW.ASSOC_PROV_GRP_ID = n.PROV_GRP_ID
			AND n.iyear = YEAR(CURRENT_DATE()) )A
	GROUP BY
		PPM )A
FULL OUTER JOIN (
	SELECT
		DISTINCT CASE
			WHEN (PPM IS NULL
				OR PPM = ''
				OR trim(PPM)= 'N/A') THEN 'N/A'
			ELSE PPM
		END AS PPM,
		count(*)AS dev_PPM_Count
	FROM
		YDJV_PRD_STARS_BI_DB.BI_COMPACT.CENSUS_SUPPLEMENTAL
	WHERE
		iyear = YEAR(CURRENT_DATE())
			AND month_key = (
			SELECT
				max(month_key)
			FROM
				YDJV_PRD_STARS_BI_DB.BI_COMPACT.CENSUS_SUPPLEMENTAL
			WHERE
				LENGTH(month_key)= 6)
		GROUP BY
			CASE
				WHEN (PPM IS NULL
					OR PPM = ''
					OR trim(PPM)= 'N/A') THEN 'N/A'
				ELSE PPM
			END )B ON
	A.PPM = B.PPM
WHERE
	QA_PPM_Count != dev_PPM_Count"""
    col_count, col_names = extract_result_columns(query)
    print(f"Column Count: {col_count}, Column Names: {col_names}")