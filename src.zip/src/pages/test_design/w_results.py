

import pandas as pd
import streamlit as st
from loguru import logger
from streamlit import session_state as sst

from src.pages.test_design.db import generate_dsid, get_dsid_results, save_testplan_changes, get_monitored_objects




status_colors = {
    'PASS': 'background-color: #abf7b1',
    'FAIL': 'background-color: #f7b1b1',
    'WARNING': 'background-color: #f7d6b1'
}


# Function that maps status to color
def color_status(val):
    return status_colors.get(str(val).strip().upper(), '')


@st.fragment()
def results_widget(product_warehouse, job_id, job_name, exec_step, env_id):
    # Reload test results table when the page is reloaded, job id is changed, cancel button is clicked
    if sst.get('tp_test_results_df') is None:
        logger.info("Loading Test Results from DB")
        with st.spinner('Loading ...'):
            sst['tp_test_results_df'] = get_dsid_results(
                job_name,
                exec_step,
                env_id,
                product_warehouse
            )

    test_results_df = sst['tp_test_results_df']

    if test_results_df.empty:
        st.info(f'No records found for the selected Job ID : {job_id}')
    else:
        # testresults['RUNDATE'] = pd.to_datetime(testresults['RUNDATE']).dt.date
        max_run_date = test_results_df['RUNDATE'].max()
        min_run_date = test_results_df['RUNDATE'].min()

        teststatus_list = test_results_df['TESTSTATUS'].unique()
        dsid_list = test_results_df['DSID'].unique()

        start_date_col, end_date_col, test_status_col, dsid_col = st.columns([1, 1, 1, 1])
        with start_date_col:
            start_date = st.date_input(
                label='Start Date',
                value=min_run_date,
                min_value=min_run_date,
                max_value=max_run_date,
                key='test results start_date'
            )
        with end_date_col:
            end_date = st.date_input(
                label='End Date',
                value=max_run_date,
                min_value=min_run_date,
                max_value=max_run_date,
                key='test results end_date'
            )

        with test_status_col:
            test_status = st.selectbox(
                label='Test Status',
                options=teststatus_list,
                key='test results test_status'

            )
            select_all_status = st.checkbox(
                label='All',
                value=False,
                key='test results all status',

            )

        with dsid_col:
            dsid = st.selectbox(
                label='DSID',
                options=dsid_list,
                key='test results dsid'
            )
            select_all_dsid = st.checkbox(
                label='All',
                value=False
            )

        if start_date > end_date:
            st.error('Start Date cannot be greater than End Date')
            return

        if start_date > max_run_date or end_date < min_run_date:
            st.error('No records found for the selected date range')
            return

        filtered_df = test_results_df[
            (test_results_df['RUNDATE'] >= start_date) &
            (test_results_df['RUNDATE'] <= end_date)
            ]
        if select_all_status is False:
            filtered_df = filtered_df[filtered_df['TESTSTATUS'] == test_status]
        if select_all_dsid is False:
            filtered_df = filtered_df[filtered_df['DSID'] == dsid]

        # List of status columns
        status_columns = [
            'TESTSTATUS',
            'TESTSTATUS1', 'TESTSTATUS2', 'TESTSTATUS3', 'TESTSTATUS4', 'TESTSTATUS5',
            'TESTSTATUS6', 'TESTSTATUS7', 'TESTSTATUS8', 'TESTSTATUS9', 'TESTSTATUS10'
        ]

        # Apply styling directly
        styled_df = filtered_df.style.applymap(color_status, subset=status_columns)

        pd.set_option("styler.render.max_elements", 665200)
        st.dataframe(styled_df, hide_index=True)