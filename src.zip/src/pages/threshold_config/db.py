
import os
import pandas as pd
from copy import deepcopy
from loguru import logger
from src.db.snowflake.database import get_snowpark_product_session


def format_cell_data(value):
    """
    Snowflake doesn't care about datatype as long it is not null you can insert any value with quotes and
    it will automatically convert it to the datatype of the column
    This func only parses int,float,string,date,bool related cols and not json or list related datatype values
    """
    value = str(value)
    if value.lower() in {'nan', 'none', '', 'nat'}:
        return f"null"
    value = value.replace("'", "''")
    return f"'{value}'"


def generate_threshold_id():
    """Get next id from the sequence used to generate Threshold"""
    session = get_snowpark_product_session()

    seq_name = os.environ.get("DSE_THRESHOLD_ID_SEQ")

    query = f"select {seq_name}.nextval as id"
    df = pd.DataFrame(session.sql(query).collect())
    if df.empty:
        raise Exception('Unable to generate Threshold ID, sequence is empty')

    new_id = df['ID'][0]
    return new_id


def update_threshold_table(data, warehouse=None):
    # Table names
    threshold_table = os.environ.get('THRESHOLD_TABLE_NAME')

    session = get_snowpark_product_session(warehouse)

    # All columns in threshold table
    thc_col_names = [
        'THRESHOLDID', 'THRESHOLDTYPE', 'MINWARNINGTHRESHOLD', 'MAXWARNINGTHRESHOLD', 'MINFAILTHRESHOLD',
        'MAXFAILTHRESHOLD', 'FLOORVALUE', 'CEILINGVALUE', 'JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY',
        'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'
    ]

    # Record any error in the process
    data = deepcopy(data)
    data['ERROR'] = None
    data['QUERY'] = None

    # Start transaction
    session.sql("begin").collect()
    for index, row in data.iterrows():
        query = None
        error = None



        try:
            threshold_id = row['THRESHOLDID']
            check_threshold_id_exist_query = f"""
            select count(*) as count 
            from {threshold_table}
            where  THRESHOLDID = '{threshold_id}';
            """
            count = pd.DataFrame(session.sql(check_threshold_id_exist_query).collect())['COUNT'][0]

            if count > 1:
                error = f'There are multiple records in table with same threshold id {threshold_id}'
            elif count == 0:
                query = f""" 
                insert into {threshold_table}(
                    THRESHOLDID, THRESHOLDTYPE, MINWARNINGTHRESHOLD, MAXWARNINGTHRESHOLD, MINFAILTHRESHOLD,
                    MAXFAILTHRESHOLD, FLOORVALUE, CEILINGVALUE, JANUARY, FEBRUARY, MARCH, APRIL, MAY,
                    JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER
                ) values (
                    {format_cell_data(row['THRESHOLDID'])}, {format_cell_data(row['THRESHOLDTYPE'])}, 
                    {format_cell_data(row['MINWARNINGTHRESHOLD'])}, {format_cell_data(row['MAXWARNINGTHRESHOLD'])}, 
                    {format_cell_data(row['MINFAILTHRESHOLD'])}, {format_cell_data(row['MAXFAILTHRESHOLD'])}, 
                    {format_cell_data(row['FLOORVALUE'])}, {format_cell_data(row['CEILINGVALUE'])}, 
                    {format_cell_data(row['JANUARY'])}, {format_cell_data(row['FEBRUARY'])}, {format_cell_data(row['MARCH'])}, 
                    {format_cell_data(row['APRIL'])}, {format_cell_data(row['MAY'])}, {format_cell_data(row['JUNE'])}, 
                    {format_cell_data(row['JULY'])}, {format_cell_data(row['AUGUST'])}, {format_cell_data(row['SEPTEMBER'])}, 
                    {format_cell_data(row['OCTOBER'])}, {format_cell_data(row['NOVEMBER'])}, 
                    {format_cell_data(row['DECEMBER'])}
                );
                """
            else:
                query = f"""
                update {threshold_table}
                set
                    -- THRESHOLDID={format_cell_data(row['THRESHOLDID'])},
                    THRESHOLDTYPE={format_cell_data(row['THRESHOLDTYPE'])}, 
                    MINWARNINGTHRESHOLD={format_cell_data(row['MINWARNINGTHRESHOLD'])}, 
                    MAXWARNINGTHRESHOLD={format_cell_data(row['MAXWARNINGTHRESHOLD'])}, 
                    MINFAILTHRESHOLD={format_cell_data(row['MINFAILTHRESHOLD'])}, 
                    MAXFAILTHRESHOLD={format_cell_data(row['MAXFAILTHRESHOLD'])}, 
                    FLOORVALUE={format_cell_data(row['FLOORVALUE'])}, 
                    CEILINGVALUE={format_cell_data(row['CEILINGVALUE'])}, 
                    JANUARY={format_cell_data(row['JANUARY'])}, 
                    FEBRUARY={format_cell_data(row['FEBRUARY'])}, 
                    MARCH={format_cell_data(row['MARCH'])}, 
                    APRIL={format_cell_data(row['APRIL'])}, 
                    MAY={format_cell_data(row['MAY'])}, 
                    JUNE={format_cell_data(row['JUNE'])}, 
                    JULY={format_cell_data(row['JULY'])}, 
                    AUGUST={format_cell_data(row['AUGUST'])}, 
                    SEPTEMBER={format_cell_data(row['SEPTEMBER'])}, 
                    OCTOBER={format_cell_data(row['OCTOBER'])}, 
                    NOVEMBER={format_cell_data(row['NOVEMBER'])}, 
                    DECEMBER={format_cell_data(row['DECEMBER'])}
                where THRESHOLDID = '{threshold_id}';
                """

            session.sql(query).collect()
        except Exception as e:
            error = str(e)

        data.at[index, 'ERROR'] = error
        data.at[index, 'QUERY'] = query

    if data['ERROR'].notna().any():
        session.sql("rollback").collect()
        logger.error('Changes are not saved due the errors in following records')
        return 'Failed', {
            'failed_records': data.loc[data['ERROR'].notna()][['THRESHOLDID', 'QUERY', 'ERROR']]
        }

    else:
        session.sql("commit").collect()
        # session.sql("rollback").collect()

        logger.success('All changes saved Successfully')
        return 'Success', None
