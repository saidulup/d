
import streamlit as st
from streamlit import session_state as sst

from src.pages.threshold_config.tab_main import render_threshold_config_tab

from src.pages.utils.console_components import back_button
from src.auth.auth_widgets import logout_button


st.set_page_config(layout="wide", initial_sidebar_state='collapsed')

if sst.get('filter_data') is None:
    # if st.button('⬅️ Back', key='back from jobconfig', type='primary'):
    st.switch_page('app.py')


page_key = 'threshold_config_page'
unsaved_changes_state = 'unsaved_threshold_config_changes'
page_states = [
    'thc_threshold_df',
    'thc_threshold_df_key',
    'edited_thc_threshold_df',
    'unsaved_threshold_config_changes',
]
back_page = 'pages/1_Admin_Console.py'


def main():
    # Logout Button
    with st.sidebar:
        logout_button()

    # Go Back button
    back_button(page_key, back_page, unsaved_changes_state, page_states)

    selected_product_id = sst['filter_data']['product_id']
    selected_product_name = sst['filter_data']['product_name']
    selected_data_domain = sst['filter_data']['data_domain']
    selected_database = sst['filter_data']['product_database']
    selected_warehouse = sst['filter_data']['product_warehouse']
    random_id = sst['filter_data']['random_id']

    st.markdown(f"### ❄️ :blue[DSE Threshold Configuration]")
    render_threshold_config_tab(selected_product_id, selected_product_name, selected_data_domain, selected_database, selected_warehouse, random_id)
