
import time
import random
import pandas as pd
import streamlit as st
from streamlit import session_state as sst
from loguru import logger

from src.pages.data_utils import get_threshold_table, product_warehouse_status
from src.pages.threshold_config.db import update_threshold_table, generate_threshold_id


# Color map
row_colors = {
    'added': 'background-color: #8ecae6; color: black',
    'edited': 'background-color: #abf7b1; color: black',
    'deleted': 'background-color: #fcccbb; color: black',
}


def style_edited_rows(df):
    """Color testplan table rows based on COLOR_FLAG column"""
    # Create Series of styles per row
    return pd.DataFrame(
        [[row_colors.get(v, '')]*len(df.columns) for v in df['COLOR_FLAG']],
        index=df.index,
        columns=df.columns
    )



def add_new_row(product_id):
    """
    Add a new row to the threshold table
    """
    df = sst['edited_thc_threshold_df']
    start_threshold_id = generate_threshold_id()

    new_row = {
        '': False,
        'THRESHOLDID': start_threshold_id,
        'THRESHOLDTYPE': None,
        'MINWARNINGTHRESHOLD': None,
        'MAXWARNINGTHRESHOLD': None,
        'MINFAILTHRESHOLD': None,
        'MAXFAILTHRESHOLD': None,
        'FLOORVALUE': None,
        'CEILINGVALUE': None,
        'JANUARY': None,
        'FEBRUARY': None,
        'MARCH': None,
        'APRIL': None,
        'MAY': None,
        'JUNE': None,
        'JULY': None,
        'AUGUST': None,
        'SEPTEMBER': None,
        'OCTOBER': None,
        'NOVEMBER': None,
        'DECEMBER': None,
        'COLOR_FLAG': 'added'
    }

    new_row = pd.DataFrame([new_row])

    # Threshold data is by default sorted on thresholdid in desc
    # So the new id(highest value) should be on top even in the new data, thus avoiding sorting and improving efficiency
    sst['thc_threshold_df'] = pd.concat([new_row, df], ignore_index=True)
    st.rerun()


@st.fragment()
def render_threshold_config_tab(product_id, product_name, product_data_domain, product_db, product_warehouse, random_id):
    tab_key = 'ac-threshold-config' + str(random_id)

    st.text(' ')
    st.text(' ')
    warehouse_status = product_warehouse_status(product_warehouse)
    database_status = 'Not Found' if str(product_db).lower() in {'none', 'nan', ''} else ''
    st.markdown(f"""
        ###### Product Id : :blue[{product_id}], Product Name : :blue[{product_name}], Data Domain : :blue[{product_data_domain}], Warehouse : :blue[{product_warehouse} {warehouse_status}]
        """)
    st.markdown(f"##### :blue[DSE Threshold Table]")

    # Load data if it doesn't exist in session state
    if sst.get('thc_threshold_df') is None:
        with st.spinner('Loading...'):
            logger.info(f"Loading Threshold Config from DB")
            threshold_table = get_threshold_table(product_id)

            threshold_table.insert(0, '', False)
            threshold_table['THRESHOLD_ID'] = threshold_table['THRESHOLDID'].astype(str)
            threshold_table['COLOR_FLAG'] = 'edited'
            threshold_table = threshold_table.sort_values(by=['THRESHOLDID'], ascending=False)
            sst['thc_threshold_df'] = threshold_table
            sst['thc_threshold_df_key'] = f"{tab_key}-thc edit grid-{random.randrange(0, 1000)}"

    # Display a data grid to accept user changes
    sst['edited_thc_threshold_df'] = st.data_editor(
        data=sst['thc_threshold_df'],
        key=sst['thc_threshold_df_key'],
        use_container_width=True,
        hide_index=True,
        column_order=[
            '', 'THRESHOLDID', 'THRESHOLDTYPE', 'MINWARNINGTHRESHOLD', 'MAXWARNINGTHRESHOLD',
            'MINFAILTHRESHOLD', 'MAXFAILTHRESHOLD', 'FLOORVALUE', 'CEILINGVALUE',
            'JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE',
            'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'
        ],
        column_config={
            '': st.column_config.CheckboxColumn(pinned=True),
            'THRESHOLDID': st.column_config.TextColumn(pinned=True),
            'THRESHOLDTYPE': st.column_config.SelectboxColumn(options=[None, 'NUMBER', 'PERCENT'], pinned=True),
            'MINWARNINGTHRESHOLD': st.column_config.NumberColumn(),
            'MAXWARNINGTHRESHOLD': st.column_config.NumberColumn(),
            'MINFAILTHRESHOLD': st.column_config.NumberColumn(),
            'MAXFAILTHRESHOLD': st.column_config.NumberColumn(),
            'FLOORVALUE': st.column_config.NumberColumn(),
            'CEILINGVALUE': st.column_config.NumberColumn(),
            'JANUARY': st.column_config.NumberColumn(step=1),
            'FEBRUARY': st.column_config.NumberColumn(step=1),
            'MARCH': st.column_config.NumberColumn(step=1),
            'APRIL': st.column_config.NumberColumn(step=1),
            'MAY': st.column_config.NumberColumn(step=1),
            'JUNE': st.column_config.NumberColumn(step=1),
            'JULY': st.column_config.NumberColumn(step=1),
            'AUGUST': st.column_config.NumberColumn(step=1),
            'SEPTEMBER': st.column_config.NumberColumn(step=1),
            'OCTOBER': st.column_config.NumberColumn(step=1),
            'NOVEMBER': st.column_config.NumberColumn(step=1),
            'DECEMBER': st.column_config.NumberColumn(step=1),
        },
        disabled=['THRESHOLDID', 'COLOR_FLAG'],
    )

    add_col, _ = st.columns([1, 7], gap='small')
    with add_col:
        st.button(
            label='➕ :green[Add]',
            use_container_width=True,
            on_click=add_new_row,
            args=(product_id,)
        )

    if sst['edited_thc_threshold_df'].empty:
        pass
    else:
        edited_threshold_df = sst['edited_thc_threshold_df']

        # Get the selected records
        selected_threshold_recrods = edited_threshold_df.loc[edited_threshold_df[''] == True]
        if selected_threshold_recrods.shape[0] == 0:
            pass
        else:
            save_thc_data = selected_threshold_recrods
            sst['unsaved_threshold_config_changes'] = save_thc_data.shape[0]

            # Style and display selected records for confirmation
            styled_df = save_thc_data.style.apply(style_edited_rows, axis=None)
            st.dataframe(
                data=styled_df,
                hide_index=True,
                use_container_width=True
            )

            if warehouse_status == 'Not Found' or database_status == 'Not Found':
                st.markdown(f"Databases : :blue[{product_db} {database_status}], Warehouse : :blue[{product_warehouse} {warehouse_status}]")
                st.warning(f"Cannot Save changes")
                logger.warning('Cannot Save changes, Warehouse or Database not found')
                st.stop()

            save_col, cancel_col, _ = st.columns([1, 1, 6], gap='small')
            with cancel_col:
                on_cancel = st.button('❌ :red[Cancel]', use_container_width=True)
                if on_cancel:
                    logger.info('Canceling changes to threshold table')
                    sst['thc_threshold_df'] = None
                    sst['thc_threshold_df_key'] = None
                    sst['edited_thc_threshold_df'] = None
                    sst['unsaved_threshold_config_changes'] = None

                    time.sleep(1)
                    st.rerun()

            with save_col:
                submit_update = st.button('💾 Save', key=f"{tab_key}_update_job_config", use_container_width=True)


            if submit_update:
                with st.spinner('Saving Changes...'):
                    status, msg = update_threshold_table(save_thc_data, product_warehouse)

                if status == 'Success':
                    logger.success('Records Successfully Updated')
                    st.success('Records Successfully Updated')
                    # st.dataframe(save_jc_data, hide_index=True)
                    with st.spinner('Reloading in 5 sec'):
                        time.sleep(5)
                        # reload_page('Success', 5)
                        reset_states = [
                            'thc_threshold_df',
                            'thc_threshold_df_key',
                            'edited_thc_threshold_df',
                            'unsaved_threshold_config_changes',
                        ]
                        for state in reset_states:
                            if sst.get(state) is not None:
                                del sst[state]
                        st.rerun()

                else:
                    logger.warning('Error Updating Records')
                    st.warning('The following error occurred while updating the records')
                    st.dataframe(msg['failed_records'])

