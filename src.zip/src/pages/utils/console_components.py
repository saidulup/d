# Common components for all pages falling under admin console
# job,test,threshold,task

import streamlit as st
from streamlit import session_state as sst




@st.fragment
def back_button(key, back_page: str, unsaved_changes: str, states: list[str]):
    """
    Func shows a back button verifies whether the there are any unsaved changes and displays a dialog
    : param key: Unique key for the button
    : param back_page: The page to switch to when user confirms to go back
    : param unsaved_changes: The state key that holds the count of unsaved changes
    : param states: List of states to be deleted when user confirms to go back
    """
    if st.button(
            label="⬅️ Back",
            key=f"button {key}",
            # use_container_width=True,
            help="Go back to Admin Console"
    ):
        unsaved_changes = sst.get(unsaved_changes)
        flag = unsaved_changes is not None and int(unsaved_changes) > 0
        if flag:
            back_dialog(key, states, back_page)
        else:
            st.switch_page(back_page)


@st.dialog(title='Go Back Confirmation', width='small')
def back_dialog(key, states: list[str], back_page: str):
    """
    Display a warning message when user tries to go back from job config page
    Delete all states in current page and switch to the given mentioned back page
    :param key: Unique key for the dialog
    :param states: List of states to be deleted when user confirms to go back
    :param back_page: The page to switch to when user confirms to go back
    """

    st.markdown(f"#### There are unsaved Changes in current Page-Would you like to proceed ?")

    cancel_col, submit_col, _ = st.columns([1, 1, 2])
    with cancel_col:
        cancel = st.button("Cancel", use_container_width=True, key=f'modal cancel: {key}')
    with submit_col:
        submit = st.button("Proceed", use_container_width=True, key=f'modal submit: {key}')

    if cancel:
        st.rerun()
    if submit:

        # Drop all states in job config page as we are leaving the page
        for key in states:
            if sst.get(key) is not None:
                del sst[key]
        st.switch_page(back_page)
