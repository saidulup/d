
import os
import time
import streamlit as st
from streamlit import session_state as sst
from streamlit_js_eval import streamlit_js_eval


def solid_line(color='tomato'):
    """function to display a solid line"""
    st.markdown(f"""
                    <div style="background-color: {color}; padding: 0px; border: 2px solid #def; height: 1px;">
                    </div>
                    """, unsafe_allow_html=True)


def format_streamlit_page():
    """Control the layout of streamlit pages"""
    # remove made with streamlit footer in the page and remove extra space on top
    st.markdown("""
        <style>
        footer {
            visibility: hidden;
        }
        footer:after {
            content:'goodbye'; 
            visibility: hidden;
            display: block;
            position: relative;
            #background-color: red;
            padding: 5px;
            top: 2px;
        }   
        .block-container {
            padding-top: 0rem;
            padding-bottom: 0rem;
            padding-left: 2rem;
            padding-right: 2rem;
        }

        </style>
    """, unsafe_allow_html=True)

    # remove hamburger menu
    st.markdown("""
                <style>
                #MainMenu {visibility: hidden;}
                </style>
                """, unsafe_allow_html=True)




def reload_page(success_flag=None, reload_time=10):
    if success_flag == 'Success':
        with st.spinner(f'Reloading page in {reload_time} seconds ...'):
            time.sleep(reload_time)
            streamlit_js_eval(js_expressions="parent.window.location.reload()")


def refresh_page(success_flag=None, reset_states=[], reload_time=10):
    # just refreshes the page, states wont be lost
    if success_flag == 'Success':
        with st.spinner(f'Reloading page in {reload_time} seconds ...'):
            time.sleep(reload_time)
            for state in reset_states:
                if sst.get(state) is not None:
                    del sst[state]
            st.rerun()



def space(value: float = 0.7):
    """Insert space in streamlit app"""
    st.html(f"""<div style="height: {value}rem;"></div>""")

def hide_navbar():
    # Hide page 1
    st.markdown(
        """
        <style>
        [data-testid="stSidebarNav"] {
            display: none;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )
