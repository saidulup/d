

def is_integer(text:str)->bool:
    """
    Verify whether the text is an integer or not.
    Flags an valid python integer representation as True
    - Handles +,-,_ in the text
    - Doesn't consider float as integer
    """
    try:
        int(text)
        return True
    except ValueError:
        return False


def is_float(text:str, strict=False)->bool:
    """
    Verify whether the text is a float or not
    Flags an valid python float representation as True
    - Handles +,-,_ in the text
    strict : if False, will also flag integers as float
    """
    try:
        float(text)
        if not strict:
            return True
        else:
            return not is_integer(text)
    except ValueError:
        return False


def is_null(text:str|None, strict=True)-> bool:
    """
    Verify whether the text is null or not
    strict : True , treat as null if text is in s else in ns
    """

    s = {'None', 'nan', 'NaN', 'null', 'NULL', 'Null', 'NAN', 'nAN', 'nAn', 'nAN'}
    ns = {'', 'None', 'nan', 'NaN', 'null', 'NULL', 'Null', 'NAN', 'nAN', 'nAn', 'nAN'}

    if text is None:
        return True

    if strict:
        return text in s

    return text in ns


if __name__ == '__main__':
    print(is_integer('123'), is_integer('-123'), is_integer('12.3'), is_integer('-12.3'))
    print(is_float('123'), is_float('-123'), is_float('12.3'), is_float('-12.3'))