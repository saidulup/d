
import pandas as pd


df = pd.DataFrame({
    'col1': [1, 2, 3, None]
})


df.sort_values(by='col1', inplace=True, ignore_index=True, ascending=False)
print(df)

for indes, row in df.iterrows():
    print(indes, row['col2'])