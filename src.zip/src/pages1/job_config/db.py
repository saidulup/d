

import os
import time
import json
import streamlit as st
from streamlit import session_state as sst

import pandas as pd
from src.db.snowflake.database import get_snowpark_product_session, get_snowpark_session
from src.db.athena.database import validate_athena_connection


def format_cell_data(value):
    """
    Snowflake doesn't care about datatype as long it is not null you can insert any value with quotes and
    it will automatically convert it to the datatype of the column
    This func only parses int,float,string,date,bool related cols and not json or list related datatype values
    """
    value = str(value)
    if value.lower() in {'nan', 'none', '', 'nat'}:
        return f"null"
    value = value.replace("'", "''")
    return f"'{value}'"


def generate_job_id():
    """Get next id from the sequence used to generate JOB ID"""
    session = get_snowpark_product_session()

    seq_name = os.environ.get("DSE_JOB_ID_SEQ")

    query = f"select {seq_name}.nextval as id"
    df = pd.DataFrame(session.sql(query).collect())
    if df.empty:
        raise Exception('Unable to generate JOB ID, sequence is empty')

    new_id = df['ID'][0]
    return new_id


def update_job_config(data, database, warehouse):
    # Table names
    job_config_table = os.environ.get('JOB_CONFIG_TABLE_NAME')
    env_table = os.environ.get('ENV_TABLE_NAME')
    testplan_table = os.environ.get('TESTPLAN_TABLE_NAME')
    job_auditlog_table = os.environ.get('JOB_AUDITLOG_TABLE_NAME')
    test_results_table = os.environ.get('TESTRESULTS_TABLE_NAME')

    session = get_snowpark_product_session(warehouse)

    job_warehouse_name = warehouse.lower().replace('_dev_', '_xxx_').replace('_stg_', '_xxx_').replace('_prd_', '_xxx_')
    job_db_name = database.lower().replace('_dev_', '_xxx_').replace('_stg_', '_xxx_').replace('_prd_', '_xxx_')
    job_role_name = 'azu_sdrp_ckf_xxx_developer_role'


    target_env_status_codes = {
        'dev': 3,
        'stg': 2,
        'prd': 1
    }  # status codes associated with each environment in dse_environment table

    # All columns in job_config table
    job_config_column_names = [
        'JOBID', 'ENVIRONMENT_ID', 'JOBNAME', 'JOBDESCRIPTION', 'EXECUTIONSTEP', 'EMAILID',
        'EMAILTO', 'FAILUREEMAILTO', 'EMAILFROM', 'REPLYTO', 'JOBTIMEOUT', 'INSERTTIMESTAMP',
        'CREATEDBYUSERID', 'FORCEFAIL', 'JOB_FAILED_QUERY', 'PRODUCT_ID'
    ]

    queries = []
    error_log = []
    created_user = sst.get('user_name')

    # Start the transactions
    session.sql(f"begin").collect()
    for index, row in data.iterrows():
        query = None
        error = None

        try:
            jobid = row['JOBID']
            check_jobid_exist_query = f"""
            select count(*) as count 
            from {job_config_table}
            where JOBID = '{jobid}';
            """
            count = pd.DataFrame(session.sql(check_jobid_exist_query).collect())['COUNT'][0]

            # data validation step for each column value ask sir and implement

            if count > 1:
                error = f'There are multiple records in table with same jobid {jobid}'
            elif count == 0:
                query = f"""
                insert into {job_config_table} (
                    JOBID, ENVIRONMENT_ID, JOBNAME, JOBDESCRIPTION, EXECUTIONSTEP, EMAILID,
                    EMAILTO, FAILUREEMAILTO, EMAILFROM, REPLYTO, JOBTIMEOUT, INSERTTIMESTAMP,
                    CREATEDBYUSERID, FORCEFAIL, JOB_FAILED_QUERY, PRODUCT_ID
                )
                values(
                    {format_cell_data(row['JOBID'])}, {format_cell_data(row['ENVIRONMENT_ID'])}, {format_cell_data(row['JOBNAME'])},
                    {format_cell_data(row['JOBDESCRIPTION'])}, {format_cell_data(row['EXECUTIONSTEP'])}, {format_cell_data(row['EMAILID'])},
                    {format_cell_data(row['EMAILTO'])}, {format_cell_data(row['FAILUREEMAILTO'])}, 'example@gmail.com',
                    'example@gmail.com', {format_cell_data(row['JOBTIMEOUT'])}, current_timestamp(),
                    {format_cell_data(created_user)}, {format_cell_data(row['FORCEFAIL'])}, {format_cell_data(row['JOB_FAILED_QUERY'])},
                    {format_cell_data(row['PRODUCT_ID'])}
                ); 
                """
            else:
                query = f"""
                update {job_config_table}
                set
                    -- JOBID = {format_cell_data(row['JOBID'])},
                    ENVIRONMENT_ID = {format_cell_data(row['ENVIRONMENT_ID'])},
                    JOBNAME = {format_cell_data(row['JOBNAME'])},
                    JOBDESCRIPTION = {format_cell_data(row['JOBDESCRIPTION'])},
                    EXECUTIONSTEP = {format_cell_data(row['EXECUTIONSTEP'])},
                    EMAILID = {format_cell_data(row['EMAILID'])},
                    EMAILTO = {format_cell_data(row['EMAILTO'])},
                    FAILUREEMAILTO = {format_cell_data(row['FAILUREEMAILTO'])},
                    EMAILFROM = 'example@gmail.com',
                    REPLYTO = 'example@gmail.com',
                    JOBTIMEOUT = {format_cell_data(row['JOBTIMEOUT'])},
                    INSERTTIMESTAMP = current_timestamp(),
                    CREATEDBYUSERID = {format_cell_data(created_user)},
                    FORCEFAIL = {format_cell_data(row['FORCEFAIL'])},
                    JOB_FAILED_QUERY = {format_cell_data(row['JOB_FAILED_QUERY'])}
                    -- PRODUCT_ID = {format_cell_data(row['PRODUCT_ID'])}
                where JOBID = '{jobid}'
                """

            # execute query
            session.sql(query).collect()

            # Delete any environment's associated current jobid
            query = f"""
            delete from {env_table}
            where jobid = '{jobid}'
            """
            session.sql(query).collect()

            # Add the environments for this jobid
            target_envs = {
                'prd': row['PROD'],
                'stg': row['STAGE'],
                'dev': row['DEV']
            }
            for env, flag in target_envs.items():
                if flag:
                    # Insert an environment for this jobid
                    insert_query = f"""
                    insert into {env_table}
                    (JOBID, ENVIRONEMNT_ID, DBNAME, WAREHOUSE_NAME, CONNECTION_TYPE, SNOW_ROLE)  values
                    ('{jobid}', '{target_env_status_codes[env]}', '{job_db_name.replace('xxx', env)}', 
                    '{job_warehouse_name.replace('xxx', env)}', 'snowflake', 
                    '{job_role_name.replace('xxx', env)}');
                    """
                    query = insert_query
                    session.sql(query).collect()

            # Update job data on other tables
            if count == 1:
                # Update jobname & executionstep in testplan table
                query = f"""
                update {testplan_table}
                set 
                    JOBNAME = {format_cell_data(row['JOBNAME'])},
                    EXECUTIONSTEP = {format_cell_data(row['EXECUTIONSTEP'])}
                where JOBID = '{jobid}'
                """
                session.sql(query).collect()

                # Update jobname, executionstep in auditlog table
                query = f"""
                update {job_auditlog_table}
                set
                    JOBNAME = {format_cell_data(row['JOBNAME'])},
                    EXECUTIONSTEP = {format_cell_data(row['EXECUTIONSTEP'])}
                where JOBID = '{jobid}'
                """
                session.sql(query).collect()

                # Update jobname, executionstep in test_results table
                query = f"""
                update {test_results_table}
                set
                    JOBNAME = {format_cell_data(row['JOBNAME'])},
                    EXECUTIONSTEP = {format_cell_data(row['EXECUTIONSTEP'])}
                where DSID in (
                    select distinct DSID
                    from {testplan_table}
                    where JOBID = '{jobid}'
                )
                """
                session.sql(query).collect()

        except Exception as e:
            error = str(e)

        queries.append(query)
        error_log.append(error)

    data['ERROR'] = error_log
    data['QUERY'] = queries
    if error_log.count(None) != len(error_log):
        session.sql("rollback").collect()
        print('Changes are not saved due the errors in following records')
        # print('These are the problematic records')
        # print(data.loc[data['ERROR'].notna()][['JOBID', 'ERROR']])
        # print(error_log)
        return 'Failed', {
            'queries': queries,
            'error_log': error_log,
            'failed_records': data.loc[data['ERROR'].notna()][['JOBID', 'QUERY', 'ERROR']]
        }

    else:
        # Commit transaction
        session.sql("commit").collect()
        # session.sql("rollback").collect()
        print('All changes saved Successfully')
        return 'Success', None


def get_job_env_states(warehouse):

    env_table_name = os.environ.get('ENV_TABLE_NAME')
    session = get_snowpark_product_session(warehouse)
    env_table = session.sql(f"select * from {env_table_name}").collect()
    env_table = pd.DataFrame(env_table)
    if env_table.empty:
        env_table_desc = pd.DataFrame(session.sql(f'desc table {env_table_name};').collect())
        env_table = pd.DataFrame(columns=env_table_desc['name'].tolist())
    return env_table


def execute_job(jobname, execution_step, env_flag):

    job_queue_table_name = os.environ.get('JOBQUEUE_TABLE_NAME')
    job_auditlog_table_name = os.environ.get('JOB_AUDITLOG_TABLE_NAME')
    sproc_name = os.environ.get('DSE_SPROC_NAME')

    session = get_snowpark_session()

    # Query to Execute the procedure on selected job
    proc_query = f"call {sproc_name}( '{jobname}', '{execution_step}', '{env_flag}',  '0')"
    # Query to check if the job is inserted into job queue table
    job_queue_query = f"""
    select * from {job_queue_table_name}
    where
        job_name = '{jobname}' and step = '{execution_step}' and
        environment_id = {env_flag} and flag = 'N'
    """
    # Query to fetch latest runid for the job,estep from audit log table
    runid_query = f"""
    select max(RUNID) as RUNID from {job_auditlog_table_name}
    where
        jobname = '{jobname}' and executionstep = '{execution_step}' and
        environment_id = {env_flag}
    """

    try:
        # Get existing runid for job,estep,env from audit log table
        runid_df = pd.DataFrame(session.sql(runid_query).collect())
        existing_runid = runid_df['RUNID'][0] if runid_df.empty is False else 0

        # Execute the procedure
        session.sql(proc_query).collect()
        st.info('Procedure Started')

        # Check if the proc has inserted record into job queue table
        time.sleep(5)
        temp = pd.DataFrame(session.sql(job_queue_query).collect())
        if temp.empty is False:
            st.info('Job inserted into Job Queue successfully')
        else:
            st.warning('Job not yet inserted into Job Queue')
    except Exception as e:
        st.error('Error while executing the procedure')
        st.write(e)


def update_job_config_athena(data, database, warehouse):
    """Athena products dont have env's as they are already associated with the creds that have been provided"""
    validate_athena_creds = False

    # Table names
    job_config_table = os.environ.get('JOB_CONFIG_TABLE_NAME')
    env_table = os.environ.get('ENV_TABLE_NAME')
    testplan_table = os.environ.get('TESTPLAN_TABLE_NAME')
    job_auditlog_table = os.environ.get('JOB_AUDITLOG_TABLE_NAME')
    test_results_table = os.environ.get('TESTRESULTS_TABLE_NAME')

    session = get_snowpark_product_session(warehouse)

    # All columns in job_config table
    job_config_column_names = [
        'JOBID', 'ENVIRONMENT_ID', 'JOBNAME', 'JOBDESCRIPTION', 'EXECUTIONSTEP', 'EMAILID',
        'EMAILTO', 'FAILUREEMAILTO', 'EMAILFROM', 'REPLYTO', 'JOBTIMEOUT', 'INSERTTIMESTAMP',
        'CREATEDBYUSERID', 'FORCEFAIL', 'JOB_FAILED_QUERY', 'PRODUCT_ID'
    ]

    queries = []
    error_log = []
    created_user = sst.get('user_name')

    # Start transaction
    session.sql(f"begin").collect()
    for index, row in data.iterrows():
        query = None
        error = None


        try:
            jobid = row['JOBID']

            # Json object/string used to store the connection credentials for jobs for athena
            conn_creds = json.dumps({
                'AWS_ACCESS_KEY_ID': row['AWS_ACCESS_KEY_ID'],
                'AWS_SECRET_ACCESS_KEY': row['AWS_SECRET_ACCESS_KEY'],
                'AWS_S3_BUCKET_DIR': row['AWS_S3_BUCKET_DIR'],
                'AWS_REGION_NAME': row['AWS_REGION_NAME'],
                'AWS_SCHEMA_NAME': row['AWS_SCHEMA_NAME']
            }).replace("'", "''")

            check_jobid_exist_query = f"""
            select count(*) as count 
            from {job_config_table}
            where JOBID = '{jobid}';
            """
            count = pd.DataFrame(session.sql(check_jobid_exist_query).collect())['COUNT'][0]

            if validate_athena_creds is True:
                # Validate athena connection creds first
                athena_status = validate_athena_connection(
                    row['AWS_REGION_NAME'],
                    row['AWS_S3_BUCKET_DIR'],
                    row['AWS_SCHEMA_NAME'],
                    row['AWS_ACCESS_KEY_ID'],
                    row['AWS_SECRET_ACCESS_KEY']
                )

                if athena_status['status'] == 'error':
                    error = athena_status['message']
                    error_log.append(error)
                    queries.append('Incorrect Athena Connection Credentials')
                    continue

            if count > 1:
                error = f'There are multiple records in table with same jobid {jobid}'
            elif count == 0:
                query = f"""
                insert into {job_config_table} (
                    JOBID, ENVIRONMENT_ID, JOBNAME, JOBDESCRIPTION, EXECUTIONSTEP, EMAILID,
                    EMAILTO, FAILUREEMAILTO, EMAILFROM, REPLYTO, JOBTIMEOUT, INSERTTIMESTAMP,
                    CREATEDBYUSERID, FORCEFAIL, JOB_FAILED_QUERY, PRODUCT_ID
                )
                values(
                    {format_cell_data(row['JOBID'])}, 
                    {format_cell_data(row['ENVIRONMENT_ID'])}, 
                    {format_cell_data(row['JOBNAME'])},
                    {format_cell_data(row['JOBDESCRIPTION'])}, 
                    {format_cell_data(row['EXECUTIONSTEP'])}, 
                    {format_cell_data(row['EMAILID'])},
                    {format_cell_data(row['EMAILTO'])}, 
                    {format_cell_data(row['FAILUREEMAILTO'])}, 
                    'example@gmail.com',
                    'example@gmail.com', 
                    {format_cell_data(row['JOBTIMEOUT'])}, 
                    current_timestamp(),
                    {format_cell_data(created_user)}, 
                    {format_cell_data(row['FORCEFAIL'])}, 
                    {format_cell_data(row['JOB_FAILED_QUERY'])},
                    {format_cell_data(row['PRODUCT_ID'])}
                ); 
                """
            else:
                query = f"""
                update {job_config_table}
                set
                    -- JOBID = {format_cell_data(row['JOBID'])},
                    ENVIRONMENT_ID = {format_cell_data(row['ENVIRONMENT_ID'])},
                    JOBNAME = {format_cell_data(row['JOBNAME'])},
                    JOBDESCRIPTION = {format_cell_data(row['JOBDESCRIPTION'])},
                    EXECUTIONSTEP = {format_cell_data(row['EXECUTIONSTEP'])},
                    EMAILID = {format_cell_data(row['EMAILID'])},
                    EMAILTO = {format_cell_data(row['EMAILTO'])},
                    FAILUREEMAILTO = {format_cell_data(row['FAILUREEMAILTO'])},
                    EMAILFROM = 'example@gmail.com',
                    REPLYTO = 'example@gmail.com',
                    JOBTIMEOUT = {format_cell_data(row['JOBTIMEOUT'])},
                    INSERTTIMESTAMP = current_timestamp(),
                    CREATEDBYUSERID = {format_cell_data(created_user)},
                    FORCEFAIL = {format_cell_data(row['FORCEFAIL'])},
                    JOB_FAILED_QUERY = {format_cell_data(row['JOB_FAILED_QUERY'])}
                    -- PRODUCT_ID = {format_cell_data(row['PRODUCT_ID'])}
                where JOBID = '{jobid}'
                """

            # execute query
            session.sql(query).collect()

            # Delete any environment's associated current jobid
            query = f"""
            delete from {env_table}
            where jobid = '{jobid}'
            """
            session.sql(query).collect()

            # Insert an environment for this jobid
            query = f"""
            insert into {env_table}
            (JOBID, ENVIRONEMNT_ID, DBNAME, WAREHOUSE_NAME, CONNECTION_TYPE, SNOW_ROLE, NON_SNOWFLAKE_CONN_CREDS)  
            values
            ('{jobid}', '1', '{row['AWS_SCHEMA_NAME']}', Null, 'athena', Null, '{conn_creds}' );
            """
            session.sql(query).collect()

            # Update job data on other tables
            if count == 1:
                # Update jobname & executionstep in testplan table
                query = f"""
                update {testplan_table}
                set 
                    JOBNAME = {format_cell_data(row['JOBNAME'])},
                    EXECUTIONSTEP = {format_cell_data(row['EXECUTIONSTEP'])}
                where JOBID = '{jobid}'
                """
                session.sql(query).collect()

                # Update jobname, executionstep in auditlog table
                query = f"""
                update {job_auditlog_table}
                set
                    JOBNAME = {format_cell_data(row['JOBNAME'])},
                    EXECUTIONSTEP = {format_cell_data(row['EXECUTIONSTEP'])}
                where JOBID = '{jobid}'
                """
                session.sql(query).collect()

                # Update jobname, executionstep in test_results table
                query = f"""
                update {test_results_table}
                set
                    JOBNAME = {format_cell_data(row['JOBNAME'])},
                    EXECUTIONSTEP = {format_cell_data(row['EXECUTIONSTEP'])}
                where DSID in (
                    select distinct DSID
                    from {testplan_table}
                    where JOBID = '{jobid}'
                )
                """
                session.sql(query).collect()

        except Exception as e:
            error = str(e)

        queries.append(query)
        error_log.append(error)

    data['ERROR'] = error_log
    data['QUERY'] = queries
    if error_log.count(None) != len(error_log):
        session.sql("rollback").collect()
        print('Changes are not saved due the errors in following records')
        # print('These are the problematic records')
        # print(data.loc[data['ERROR'].notna()][['JOBID', 'ERROR']])
        # print(error_log)
        return 'Failed', {
            'queries': queries,
            'error_log': error_log,
            'failed_records': data.loc[data['ERROR'].notna()][['JOBID', 'QUERY', 'ERROR']]
        }

    else:
        # Commit transaction
        session.sql("commit").collect()
        # session.sql("rollback").collect()

        print('All changes saved Successfully')
        return 'Success', None


def execute_job_athena(jobname, execution_step):
    """
    Athena products dont have env's as they are already associated with the creds that have been provided
    Use 1 in place where env_flag is needed for athena products
    """

    job_queue_table_name = os.environ.get('JOBQUEUE_TABLE_NAME')
    job_auditlog_table_name = os.environ.get('JOB_AUDITLOG_TABLE_NAME')
    sproc_name = os.environ.get('DSE_SPROC_NAME')

    session = get_snowpark_session()

    # Query Execute the procedure on selected job
    proc_query = f"call {sproc_name}( '{jobname}', '{execution_step}', '{1}',  '0')"
    # Query to check if the job is inserted into job queue table
    job_queue_query = f"""
    select * from {job_queue_table_name}
    where
        job_name = '{jobname}' and step = '{execution_step}' and flag = 'N'
    """
    # Query to fetch latest runid for the job,estep from audit log table
    runid_query = f"""
    select max(RUNID) as RUNID from {job_auditlog_table_name}
    where
        jobname = '{jobname}' and executionstep = '{execution_step}'
    """
    try:
        # Get existing runid for job,estep from audit log table
        runid_df = pd.DataFrame(session.sql(runid_query).collect())
        existing_runid = runid_df['RUNID'][0] if runid_df.empty is False else 0

        # Execute the procedure
        session.sql(proc_query).collect()
        st.info('Procedure Started')

        # Check if the proc has inserted record into job queue table
        time.sleep(5)
        temp = pd.DataFrame(session.sql(job_queue_query).collect())
        if temp.empty is False:
            st.info('Job inserted into Job Queue successfully')
        else:
            st.warning('Job not yet inserted into Job Queue')
    except Exception as e:
        st.error('Error while executing the procedure')
        st.write(e)


def get_auditlogs(warehouse, jobname, estep, env_flag, runid=None):
    job_auditlog_table_name = os.environ.get('JOB_AUDITLOG_TABLE_NAME')

    session = get_snowpark_product_session(warehouse)

    if str(runid).lower().strip() in {'none', ''}:
        query = f"""
        select 
            TO_CHAR(JOBID) AS JOBID, RUNID, ENVIRONMENT_ID, JOBSTATUS, EMAILSENTTO as EMAILSENT, 
            STARTTIME, ENDTIME, ENABLEDTESTS, TOTALFAILEDCRITICAL, 
            TOTALFAILEDNONCRITICAL, TOTALWARNINGS, TOTALNOCHANGE, TOTALPASSED 
        from {job_auditlog_table_name} 
        where jobname = '{jobname}' and executionstep = '{estep}' and environment_id = '{env_flag}'
        order by RUNDATE DESC, RUNID desc , ENVIRONMENT_ID desc
        limit 10
        """
    else:
        query = f"""
        select 
            TO_CHAR(JOBID) AS JOBID, RUNID, ENVIRONMENT_ID, JOBSTATUS, EMAILSENTTO as EMAILSENT, 
            STARTTIME, ENDTIME, ENABLEDTESTS, TOTALFAILEDCRITICAL, 
            TOTALFAILEDNONCRITICAL, TOTALWARNINGS, TOTALNOCHANGE, TOTALPASSED 
        from {job_auditlog_table_name} 
        where jobname = '{jobname}' and executionstep = '{estep}' and environment_id = '{env_flag}' and runid = '{runid}' 
        order by RUNDATE DESC ,RUNID desc , ENVIRONMENT_ID desc
        limit 10
        """

    auditlog_data = pd.DataFrame(session.sql(query).collect())

    return auditlog_data


def get_execution_logs(warehouse, jobname, estep, env_flag, runid=None):

    exec_log_table = os.environ.get('EXECUTION_LOG_TABLE_NAME')

    session = get_snowpark_product_session(warehouse)

    if str(runid).lower().strip() in {'none', ''}:
        query = f""" 
        select 
            RUNID, PRODUCT_ID,DSID,STATUS, 
            MESSAGE,INSERTED_TIME from {exec_log_table} 
        where jobname = '{jobname}' and executionstep = '{estep}' and environment_id = '{env_flag}'
        order by INSERTED_TIME DESC,RUNID desc 
        """
    else:
        query = f""" 
        select 
            RUNID, PRODUCT_ID,DSID,STATUS, 
            MESSAGE,INSERTED_TIME from {exec_log_table} 
        where jobname = '{jobname}' and executionstep = '{estep}' and environment_id = '{env_flag}' and runid = '{runid}'
        order by INSERTED_TIME DESC,RUNID desc 
        """

    logs_data = pd.DataFrame(session.sql(query).collect())
    return logs_data

