
import os
import pandas as pd
from copy import deepcopy
from loguru import logger
import streamlit as st
from loguru import logger
from streamlit import session_state as sst
from src.db.snowflake.database import get_snowpark_product_session
from src.pages.test_design.ml import extract_result_columns

def string_format(value):
    """
    Snowflake doesn't care about datatype as long it is not null you can insert any value with quotes and
    it will automatically convert it to the datatype of the column
    This func only parses int,float,string,date,bool related cols and not json or list related datatype values
    """
    value = str(value)
    if value.lower() in {'nan', 'none', '', 'nat'}:
        return f"null"
    value = value.replace("'", "''")
    return f"'{value}'"


def generate_dsid():
    """Get next id from the sequence used to generate DSID"""
    session = get_snowpark_product_session()

    seq_name = os.environ.get("DSE_DSID_SEQ")

    query = f"select {seq_name}.nextval as id"
    df = pd.DataFrame(session.sql(query).collect())
    if df.empty:
        raise Exception('Unable to generate DSID, sequence is empty')

    new_id = df['ID'][0]
    return new_id

def generate_threshold_id():
    """Get next id from the sequence used to generate Threshold ID"""
    session = get_snowpark_product_session()

    threshold_seq = os.environ.get('DSE_THRESHOLD_ID_SEQ')

    query = f"select {threshold_seq}.nextval as id"
    df = pd.DataFrame(session.sql(query).collect())
    if df.empty:
        raise Exception('Unable to generate Threshold ID, sequence is empty')

    threshold_id = df['ID'][0]
    return threshold_id


def get_dsid_results(job_name, exec_step, env_id, warehouse):
    """Fetch test results associated with a test/dsid"""
    test_results_pivot_view_name = os.environ.get("TESTRESULTS_PIVOT_VIEW_NAME")

    session = get_snowpark_product_session(warehouse)
    empty_df = pd.DataFrame()

    try:
        query = f"""
        select 
            environment, DSID, JOBNAME, EXECUTIONSTEP, TESTCASEDESCRIPTION, TESTSTATUS, METRICID, METRICNAME, 
            RESULT1, PRIORRESULT1, DELTA1, PERCENTCHANGE1, TESTSTATUS1, 
            RESULT2, PRIORRESULT2, DELTA2, PERCENTCHANGE2, TESTSTATUS2, 
            RESULT3, PRIORRESULT3, DELTA3, PERCENTCHANGE3, TESTSTATUS3, 
            RESULT4, PRIORRESULT4, DELTA4, PERCENTCHANGE4, TESTSTATUS4, 
            RESULT5, PRIORRESULT5, DELTA5, PERCENTCHANGE5, TESTSTATUS5, 
            RESULT6, PRIORRESULT6, DELTA6, PERCENTCHANGE6, TESTSTATUS6, 
            RESULT7, PRIORRESULT7, DELTA7, PERCENTCHANGE7, TESTSTATUS7, 
            RESULT8, PRIORRESULT8, DELTA8, PERCENTCHANGE8, TESTSTATUS8, 
            RESULT9, PRIORRESULT9, DELTA9, PERCENTCHANGE9, TESTSTATUS9, 
            RESULT10, PRIORRESULT10, DELTA10, PERCENTCHANGE10, TESTSTATUS10, 
            RUNID, DATE(RUNDATE) as RUNDATE, ACTV_IND, TOTALRUNTIME, FREQUENCYCOUNTER, 
            Rank1 as runnumber 
            from ( 
                select 'PROD' as environment, to_char(DSID) as DSID, 
                JOBNAME, EXECUTIONSTEP, TESTCASEDESCRIPTION, TESTSTATUS, METRICID, METRICNAME, 
                RESULT1, PRIORRESULT1, DELTA1, PERCENTCHANGE1, TESTSTATUS1, 
                RESULT2, PRIORRESULT2, DELTA2, PERCENTCHANGE2, TESTSTATUS2, 
                RESULT3, PRIORRESULT3, DELTA3, PERCENTCHANGE3, TESTSTATUS3, 
                RESULT4, PRIORRESULT4, DELTA4, PERCENTCHANGE4, TESTSTATUS4, 
                RESULT5, PRIORRESULT5, DELTA5, PERCENTCHANGE5, TESTSTATUS5, 
                RESULT6, PRIORRESULT6, DELTA6, PERCENTCHANGE6, TESTSTATUS6, 
                RESULT7, PRIORRESULT7, DELTA7, PERCENTCHANGE7, TESTSTATUS7, 
                RESULT8, PRIORRESULT8, DELTA8, PERCENTCHANGE8, TESTSTATUS8, 
                RESULT9, PRIORRESULT9, DELTA9, PERCENTCHANGE9, TESTSTATUS9, 
                RESULT10, PRIORRESULT10, DELTA10, PERCENTCHANGE10, TESTSTATUS10, 
                RUNID, DATE(RUNDATE) as RUNDATE, ACTV_IND, FREQUENCYCOUNTER, TOTALRUNTIME,
                RANK() OVER(PARTITION BY environment_id,DSID ORDER BY RUNID  DESC) Rank1
                from {test_results_pivot_view_name} 
                where 
                    jobname='{job_name}' and 
                    executionstep = '{exec_step}' and 
                    environment_id='Production'
            ) 
        """

        df = pd.DataFrame(session.sql(query).collect())
        return df

    except Exception as e:
        logger.error(f"Error while fetching test results")
        # logger.error(e)
        return empty_df


@st.cache_data(ttl=120)
def get_monitored_objects(product_database:str) -> list:
    """
    Fetch monitored objects under current database(product database)  or
    Fetch tables/views from dq objects falling under the selected product database
    """
    objects_table = os.environ.get('DQM_OBJECTS_TABLE_NAME')

    query = f"""
    select object_database, object_schema, object_name 
    from {objects_table}
    where 
        object_database = '{str(product_database).upper()}' and
        object_deleted != TRUE
    """

    session = get_snowpark_product_session()

    df = pd.DataFrame(session.sql(query).collect())
    if df.empty:
        logger.warning("No objects found in the selected product database")
        return [None]

    # Construct absolute object names
    df['NAME'] = df['OBJECT_DATABASE'] + '.' + df['OBJECT_SCHEMA'] + '.' + df['OBJECT_NAME']

    logger.info(f"Found {df.shape[0]} objects in the selected product database")
    return [None] + sorted(df['NAME'].unique().tolist())



def save_testplan_changes(data:pd.DataFrame, warehouse=None):
    # Table names
    testplan_table = os.environ.get('TESTPLAN_TABLE_NAME')

    # Get Snowpark session
    session = get_snowpark_product_session(warehouse)
    logger.info("Connected to Snowflake")

    # All columns in testplan table
    tp_col_names = [
        'JOBID', 'JOBNAME', 'DSID', 'SECONDARYDSID', 'TESTTYPE',
        'TESTCASEDESCRIPTION', 'TESTCATEGORY', 'SOURCEPRESQL', 'SOURCETESTSCRIPT',
        'TARGETPRESQL', 'TARGETTESTSCRIPT', 'DS_COVERAGE_OBJECT',
        'EXECUTIONSTEP', 'RESULTSETCOLS',
        'RESULTSETCOLNAME', 'ENABLEDFLAG', 'CRITICALITY', 'THRESHOLDID',
        'DATAVALIDATIONFLAG', 'FREQUENCYCHECK', 'SCHEDULER_FREQ','SCHEDULER_EXECUTED_AT',
        'INSERTTIMESTAMP', 'CREATEDBYUSERID', 'TARGETTABLE'
    ]

    # Mandatory columns : Non nullable columns
    mandatory_cols = [
        'TESTTYPE', 'TESTCASEDESCRIPTION', 'TESTCATEGORY', 'TARGETTESTSCRIPT',
        'DS_COVERAGE_OBJECT', 'EXECUTIONSTEP', 'THRESHOLDID', 'ENABLEDFLAG', 'CRITICALITY',
    ]

    # Record any error in the process
    data = deepcopy(data)
    data['ERROR'] = None
    data['QUERY'] = None

    created_user = sst.get('user_name')

    # Start transaction
    session.sql("begin").collect()
    logger.info("Transaction started")

    for index, row in data.iterrows():
        query = None
        error = None
        dsid = None

        try:
            dsid = row['DSID']
            logger.info(f"Processing DSID: {dsid}")

            # Validate column values
            ds_coverage_object = row['DS_COVERAGE_OBJECT']
            for col in mandatory_cols:
                if pd.isna(row[col]) or row[col] == '':
                    error = f"Mandatory column '{col}' is missing for DSID: {dsid}"
                    raise ValueError(error)

            check_dsid_exist_query = f"""
            select count(*) as count 
            from {testplan_table}
            where DSID = '{dsid}';
            """
            count = pd.DataFrame(session.sql(check_dsid_exist_query).collect())['COUNT'][0]

            # Use llm to parse targettestscript and extract 'RESULTSETCOLS', 'RESULTSETCOLNAME',
            if row['TESTTYPE'] == 'MINUS QUERY':
                result_col_count, result_set_cols = 1, 'Mismatch_Count'
            else:
                if count in {0, 1}:
                    result_set_count, result_set_cols = extract_result_columns(row['TARGETTESTSCRIPT'])
                    if result_set_count == 0:
                        raise Exception(
                            "✨ AI Validation Failure: Unable to extract columns from the target test script. Please check the SQL syntax.")
                else:
                    result_set_count, result_set_cols = None, None

            if count > 1:
                error = f'Multiple tests are found in the table with the same {dsid}'
                logger.warning(error)
            elif count == 0:
                query = f"""
                insert into {testplan_table} (
                    JOBID, JOBNAME, DSID, SECONDARYDSID, TESTTYPE, RESULTTYPE, TESTCASEDESCRIPTION, TESTCATEGORY,
                    SOURCEPRESQL, SOURCETESTSCRIPT, TARGETPRESQL, TARGETTESTSCRIPT, DS_COVERAGE_OBJECT,
                    EXECUTIONSTEP, RESULTSETCOLS,
                    RESULTSETCOLNAME, ENABLEDFLAG, CRITICALITY, THRESHOLDID, DATAVALIDATIONFLAG, FREQUENCYCHECK,
                    SCHEDULER_FREQ, SCHEDULER_EXECUTED_AT, INSERTTIMESTAMP, CREATEDBYUSERID, TARGETTABLE
                    ) 
                values (
                    {string_format(row['JOBID'])}, {string_format(row['JOBNAME'])}, {string_format(row['DSID'])}, {string_format(row['SECONDARYDSID'])}, {string_format(row['TESTTYPE'])}, 'COUNT', {string_format(row['TESTCASEDESCRIPTION'])}, {string_format(row['TESTCATEGORY'])},
                    {string_format(row['SOURCEPRESQL'])}, {string_format(row['SOURCETESTSCRIPT'])}, {string_format(row['TARGETPRESQL'])}, {string_format(row['TARGETTESTSCRIPT'])}, {string_format(ds_coverage_object)},
                    {string_format(row['EXECUTIONSTEP'])}, {string_format(result_set_count)},
                    {string_format(result_set_cols)}, {string_format(row['ENABLEDFLAG'])}, {string_format(row['CRITICALITY'])}, {string_format(row['THRESHOLDID'])}, {string_format(row['DATAVALIDATIONFLAG'])}, {string_format(row['FREQUENCYCHECK'])},
                    {string_format(row['SCHEDULER_FREQ'])}, current_timestamp(), current_timestamp(), {string_format(created_user)}, 'DSE_TESTRESULTS'
                );
                """

                logger.info("Inserting new test")
            else:
                query = f"""
                update {testplan_table}
                set
                    -- JOBID={string_format(row['JOBID'])}, 
                    JOBNAME={string_format(row['JOBNAME'])}, 
                    -- DSID={string_format(row['DSID'])}, 
                    SECONDARYDSID={string_format(row['SECONDARYDSID'])}, 
                    TESTTYPE={string_format(row['TESTTYPE'])}, 
                    RESULTTYPE='COUNT', 
                    TESTCASEDESCRIPTION={string_format(row['TESTCASEDESCRIPTION'])}, 
                    TESTCATEGORY={string_format(row['TESTCATEGORY'])},
                    SOURCEPRESQL={string_format(row['SOURCEPRESQL'])}, 
                    SOURCETESTSCRIPT={string_format(row['SOURCETESTSCRIPT'])}, 
                    TARGETPRESQL={string_format(row['TARGETPRESQL'])}, 
                    TARGETTESTSCRIPT={string_format(row['TARGETTESTSCRIPT'])}, 
                    DS_COVERAGE_OBJECT={string_format(ds_coverage_object)},
                    EXECUTIONSTEP={string_format(row['EXECUTIONSTEP'])}, 
                    RESULTSETCOLS={string_format(row['RESULTSETCOLS'])},
                    RESULTSETCOLNAME={string_format(row['RESULTSETCOLNAME'])}, 
                    ENABLEDFLAG={string_format(row['ENABLEDFLAG'])}, 
                    CRITICALITY={string_format(row['CRITICALITY'])}, 
                    THRESHOLDID={string_format(row['THRESHOLDID'])}, 
                    DATAVALIDATIONFLAG={string_format(row['DATAVALIDATIONFLAG'])}, 
                    FREQUENCYCHECK={string_format(row['FREQUENCYCHECK'])},
                    SCHEDULER_FREQ={string_format(row['SCHEDULER_FREQ'])}, 
                    SCHEDULER_EXECUTED_AT={string_format(row['SCHEDULER_EXECUTED_AT'])}, 
                    INSERTTIMESTAMP=current_timestamp(), 
                    CREATEDBYUSERID={string_format(created_user)}, 
                    TARGETTABLE={string_format(row['TARGETTABLE'])}
                where DSID={dsid};
                """
                logger.info("Updating the test")
            session.sql(query).collect()
        except Exception as e:
            error = str(e)
            logger.error(f"Error while processing DSID: {dsid}")
            logger.error(error)

        data.at[index, 'ERROR'] = error
        data.at[index, 'QUERY'] = query

    if data['ERROR'].notna().any():
        session.sql("rollback").collect()
        logger.info('Changes are not saved due the errors in following records')
        return 'Failed', {
            'failed_records': data.loc[data['ERROR'].notna()][['DSID', 'QUERY', 'ERROR']]
        }

    else:
        session.sql("commit").collect()
        # session.sql("rollback").collect()
        logger.info('All changes saved Successfully')
        return 'Success', None


def save_thresholds(data:pd.DataFrame, warehouse=None):
    """
    Save thresholds to the database
    """
    # Table names
    thresholds_table = os.environ.get('THRESHOLD_TABLE_NAME')
    threshold_seq = os.environ.get('DSE_THRESHOLD_ID_SEQ')

    # Get Snowpark session
    session = get_snowpark_product_session(warehouse)
    logger.info("Connected to Snowflake")

    # Start transaction
    session.sql("begin").collect()
    logger.info("Transaction started")

    existing_ids = []
    newly_added_ids = []

    # Iterate over each row find if its already in the table if true get the id else generate id and save it
    for index, row in data.iterrows():
        try:
            find_id_query = f"""
            select THRESHOLDID 
            from {thresholds_table}
            where
                THRESHOLDTYPE = '{row['THRESHOLDTYPE']}' and
                MINWARNINGTHRESHOLD = '{row['MINWARNINGTHRESHOLD']}' and
                MAXWARNINGTHRESHOLD = '{row['MAXWARNINGTHRESHOLD']}' and
                MINFAILTHRESHOLD = '{row['MINFAILTHRESHOLD']}' and
                MAXFAILTHRESHOLD = '{row['MAXFAILTHRESHOLD']}' and
                FLOORVALUE = '{row['FLOORVALUE']}' and
                CEILINGVALUE = '{row['CEILINGVALUE']}'
                ;
            """

            df = pd.DataFrame(session.sql(find_id_query).collect())
            if not df.empty:
                # Threshold already exists, get the id
                threshold_id = df['THRESHOLDID'][0]
                logger.info(f"Threshold already exists with ID: {threshold_id}")
                existing_ids.append(threshold_id)
                continue


            # Generate new threshold id
            threshold_id = generate_threshold_id()
            logger.info(f"Generated new Threshold ID: {threshold_id}")

            insert_query = f"""
            insert into {thresholds_table} (
                THRESHOLDID, THRESHOLDTYPE, MINWARNINGTHRESHOLD, MAXWARNINGTHRESHOLD,
                MINFAILTHRESHOLD, MAXFAILTHRESHOLD, FLOORVALUE, CEILINGVALUE )
            VALUES (
                {string_format(threshold_id)}, {string_format(row['THRESHOLDTYPE'])},
                {string_format(row['MINWARNINGTHRESHOLD'])}, {string_format(row['MAXWARNINGTHRESHOLD'])},
                {string_format(row['MINFAILTHRESHOLD'])}, {string_format(row['MAXFAILTHRESHOLD'])}, 
                {string_format(row['FLOORVALUE'])}, {string_format(row['CEILINGVALUE'])}
            );
            """

            session.sql(insert_query).collect()
            newly_added_ids.append(threshold_id)
            logger.info(f"Inserted new threshold with ID: {threshold_id}")


        except Exception as e:
            logger.error(f"Error while processing row {index} for threshold: {row['THRESHOLDTYPE']}")
            logger.error(e)
            session.sql("rollback").collect()
            return {
                'status': 'Failed',
                'error': str(e),
                'failed_row': row.to_dict(),
                'existing_ids': existing_ids,
                'newly_added_ids': newly_added_ids
            }


    # Commit the transaction
    session.sql("commit").collect()
    logger.info("All thresholds saved successfully")
    return {
        'status': 'Success',
        'existing_ids': existing_ids,
        'newly_added_ids': newly_added_ids
    }


def save_single_test(data:dict, warehouse=None):
    """Save single new test into testplan table"""

    # Table names
    testplan_table = os.environ.get('TESTPLAN_TABLE_NAME')

    # Get Snowpark session
    session = get_snowpark_product_session(warehouse)
    logger.info("Connected to Snowflake")



    created_user = sst.get('user_name')

    # Start transaction
    session.sql("begin").collect()
    logger.info("Transaction started")

    try:
        dsid = data['DSID']
        logger.info(f"Processing DSID: {dsid}")

        # Validate column values
        ds_coverage_object = data['DS_COVERAGE_OBJECT']

        check_dsid_exist_query = f"""
        select count(*) as count 
        from {testplan_table}
        where DSID = '{dsid}';
        """
        count = pd.DataFrame(session.sql(check_dsid_exist_query).collect())['COUNT'][0]

        row = data
        if count > 1:
            error = f'Multiple tests are found in the table with the same {dsid}'
            logger.warning(error)
            return 'Failed', error
        elif count == 0:
            data['SECONDARYDSID'] = None
            data['DATAVALIDATIONFLAG'] = None


            query = f"""
            insert into {testplan_table} (
                JOBID, JOBNAME, DSID, SECONDARYDSID, TESTTYPE, RESULTTYPE, TESTCASEDESCRIPTION, TESTCATEGORY,
                SOURCEPRESQL, SOURCETESTSCRIPT, TARGETPRESQL, TARGETTESTSCRIPT, DS_COVERAGE_OBJECT,
                EXECUTIONSTEP, RESULTSETCOLS,
                RESULTSETCOLNAME, ENABLEDFLAG, CRITICALITY, THRESHOLDID, DATAVALIDATIONFLAG, FREQUENCYCHECK,
                SCHEDULER_FREQ, SCHEDULER_EXECUTED_AT, INSERTTIMESTAMP, CREATEDBYUSERID, TARGETTABLE
                ) 
            values (
                {string_format(row['JOBID'])}, {string_format(row['JOBNAME'])}, {string_format(row['DSID'])}, {string_format(row['SECONDARYDSID'])}, {string_format(row['TESTTYPE'])}, 'COUNT', {string_format(row['TESTCASEDESCRIPTION'])}, {string_format(row['TESTCATEGORY'])},
                {string_format(row['SOURCEPRESQL'])}, {string_format(row['SOURCETESTSCRIPT'])}, {string_format(row['TARGETPRESQL'])}, {string_format(row['TARGETTESTSCRIPT'])}, {string_format(ds_coverage_object)},
                {string_format(row['EXECUTIONSTEP'])}, {string_format(row['RESULTSETCOLS'])},
                {string_format(row['RESULTSETCOLNAME'])}, {string_format(row['ENABLEDFLAG'])}, {string_format(row['CRITICALITY'])}, {string_format(row['THRESHOLDID'])}, {string_format(row['DATAVALIDATIONFLAG'])}, {string_format(row['FREQUENCYCHECK'])},
                {string_format(row['SCHEDULER_FREQ'])}, current_timestamp(), current_timestamp(), {string_format(created_user)}, 'DSE_TESTRESULTS'
            );
            """

            logger.info("Inserting new test")
        else:
            query = f"""
            update {testplan_table}
            set
                -- JOBID={string_format(row['JOBID'])}, 
                JOBNAME={string_format(row['JOBNAME'])}, 
                -- DSID={string_format(row['DSID'])}, 
                SECONDARYDSID={string_format(row['SECONDARYDSID'])}, 
                TESTTYPE={string_format(row['TESTTYPE'])}, 
                RESULTTYPE='COUNT', 
                TESTCASEDESCRIPTION={string_format(row['TESTCASEDESCRIPTION'])}, 
                TESTCATEGORY={string_format(row['TESTCATEGORY'])},
                SOURCEPRESQL={string_format(row['SOURCEPRESQL'])}, 
                SOURCETESTSCRIPT={string_format(row['SOURCETESTSCRIPT'])}, 
                TARGETPRESQL={string_format(row['TARGETPRESQL'])}, 
                TARGETTESTSCRIPT={string_format(row['TARGETTESTSCRIPT'])}, 
                DS_COVERAGE_OBJECT={string_format(ds_coverage_object)},
                EXECUTIONSTEP={string_format(row['EXECUTIONSTEP'])}, 
                RESULTSETCOLS={string_format(row['RESULTSETCOLS'])},
                RESULTSETCOLNAME={string_format(row['RESULTSETCOLNAME'])}, 
                ENABLEDFLAG={string_format(row['ENABLEDFLAG'])}, 
                CRITICALITY={string_format(row['CRITICALITY'])}, 
                THRESHOLDID={string_format(row['THRESHOLDID'])}, 
                DATAVALIDATIONFLAG={string_format(row['DATAVALIDATIONFLAG'])}, 
                FREQUENCYCHECK={string_format(row['FREQUENCYCHECK'])},
                SCHEDULER_FREQ={string_format(row['SCHEDULER_FREQ'])}, 
                SCHEDULER_EXECUTED_AT={string_format(row['SCHEDULER_EXECUTED_AT'])}, 
                INSERTTIMESTAMP=current_timestamp(), 
                CREATEDBYUSERID={string_format(created_user)}, 
                TARGETTABLE={string_format(row['TARGETTABLE'])}
            where DSID={dsid};
            """

            logger.info("Updating the test")

        session.sql(query).collect()
        session.sql("commit").collect()

        return 'Success', None

    except Exception as e:
        error = str(e)
        logger.error(f"Error while processing DSID: {dsid}")
        logger.error(error)
        session.sql("rollback").collect()
        return 'Failed', error
