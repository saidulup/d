
import os
from loguru import logger
from src.services.llm import LLMFactory


def extract_result_columns(query:str) -> (int, str):
    """Parse the query and find out no of result columns and their names"""
    try:
        provider = LLMFactory.get_provider(os.getenv('LLM_PROVIDER', 'openai'))

        system_message = """
        You will be given a SQL SELECT statement.

        Your task:
        1. Check if the statement is a valid Snowflake SELECT query.
        2. If valid, return only the selected column names, separated by commas (no spaces, no extra text).
           Example:
             Input:  "SELECT col1, col2, col3 FROM table WHERE condition"
             Output: "col1,col2,col3"
        3. If the query is invalid, has no selected columns, or does not make sense, return an empty string.
        """.strip()

        context = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": query}
        ]
        status, col_names = provider.get_completions('gpt-4o-mini', context, 150, 0.1)
        if status is True:
            col_names = col_names.strip().strip('"')  # Remove any surrounding spaces and quotes
            if col_names == "":
                return 0, ""
            # Split by commas and count columns
            col_count = len(col_names.split(','))
            return col_count, col_names
        else:
            logger.error(f"LLM Request failed with error: {col_names}")
            return 0, ""
    except Exception as e:
        logger.error(f"Error extracting result columns from query: {query}. Error: {e}")
        return 0, ""


if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv('../../core/dev.env')
    query = f"""select    msr_abr, sum (  msr_denom_cn t ) as denom, sum(  msr_nmt_cnt  ) as num from QUMXA_PRD_STARS_DO_DB.DATAOPS_COMPACT.MNR_MDE_TBL_DLY_JAN_TO_APR_QA_MBR_MSR_HOSP H  group by msr_abr"""
    col_count, col_names = extract_result_columns(query)
    print(f"Column Count: {col_count}, Column Names: {col_names}")