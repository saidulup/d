
import time
import random
import pandas as pd
import streamlit as st
from loguru import logger
from streamlit import session_state as sst

from src.pages.test_design.db import generate_dsid, save_testplan_changes

# Color map
row_colors = {
    'added': 'background-color: #8ecae6; color: black',
    'edited': 'background-color: #abf7b1; color: black',
    'deleted': 'background-color: #fcccbb; color: black',
}


def style_edited_rows(df):
    """Color testplan table rows based on COLOR_FLAG column"""
    # Create Series of styles per row
    return pd.DataFrame(
        [[row_colors.get(v, '')]*len(df.columns) for v in df['COLOR_FLAG']],
        index=df.index,
        columns=df.columns
    )


def add_new_row():
    """Add a new row to the testplan table"""

    df = sst['edited_tp_testplan_df']

    # Get a new DSID for the new record
    start_dsid = generate_dsid()

    default_threshold_id = '4'
    default_scheduler_freq = 'DAILY'
    default_criticality = 1

    new_row = {
        '': False,
        'DSID': str(start_dsid),
        'TESTTYPE': None,
        'TESTCASEDESCRIPTION': None,
        'TESTCATEGORY': None,
        'SOURCEPRESQL': None,
        'SOURCETESTSCRIPT': None,
        'TARGETPRESQL': None,
        'TARGETTESTSCRIPT': None,
        'DS_COVERAGE_OBJECT': None,
        'EXECUTIONSTEP': None,
        'THRESHOLDID': default_threshold_id,
        'RESULTSETCOLS': None,
        'RESULTSETCOLNAME': None,
        'ENABLEDFLAG': None,
        'CRITICALITY': default_criticality,
        'FREQUENCYCHECK': None,
        'SCHEDULER_FREQ': default_scheduler_freq,
        'COLOR_FLAG': 'added'
    }

    new_row = pd.DataFrame([new_row])

    # Testplan data is by default sorted on dsid in desc
    # So the new dsid(highest value) should be on top even in the new data, thus avoiding sorting and improving efficiency
    sst['tp_testplan_df'] = pd.concat([new_row, df], ignore_index=True)


@st.fragment()
def multiple_tests_management_widget(product_id, product_database, product_warehouse, product_objects, job_id, job_name, test_categories, tab_key):

    # Display the testplan table as a grid and allow user to select records
    sst['edited_tp_testplan_df'] = st.data_editor(
        data=sst['tp_testplan_df'],
        key=sst['tp_testplan_df_key'],
        hide_index=True,
        column_order=[
            '', 'DSID', 'TESTTYPE', 'TESTCASEDESCRIPTION', 'TESTCATEGORY',
            'SOURCEPRESQL', 'SOURCETESTSCRIPT', 'TARGETPRESQL', 'TARGETTESTSCRIPT', 'DS_COVERAGE_OBJECT',
            'EXECUTIONSTEP', 'THRESHOLDID',
            'ENABLEDFLAG', 'CRITICALITY', 'FREQUENCYCHECK', 'SCHEDULER_FREQ',
            'RESULTSETCOLS', 'RESULTSETCOLNAME'
        ],
        column_config= {
            'TESTTYPE': st.column_config.SelectboxColumn(
                options=['SINGLE DATAPOINT', 'MULTI DATAPOINT', 'MINUS QUERY', None],
                help='Type of test',
                required=True
            ),
            'TESTCASEDESCRIPTION': st.column_config.TextColumn(
                help='Description of the test case and its objective',
                required=True
            ),
            'TESTCATEGORY': st.column_config.SelectboxColumn(
                options=test_categories,
                help='Category of the test for easier classification',
                required=True
            ),
            'SOURCEPRESQL': st.column_config.TextColumn(
                help='Pre-SQL script for the source table, if required'
            ),
            'SOURCETESTSCRIPT': st.column_config.TextColumn(
                help='Main SQL script for testing on the source table'
            ),
            'TARGETPRESQL': st.column_config.TextColumn(
                help='Pre-SQL script for the target table, if required'
            ),
            'TARGETTESTSCRIPT': st.column_config.TextColumn(
                help='Main SQL script for testing on the target table',
                required=True
            ),
            'DS_COVERAGE_OBJECT': st.column_config.SelectboxColumn(
                options=product_objects,
                width='large',
                help='Test case supposed to map which target table name',
                required=True
            ),
            'EXECUTIONSTEP': st.column_config.SelectboxColumn(
                options=['POST-CHECK', 'PRE-CHECK', None],
                help='Execution step or phase of the test',
                required=True,
            ),
            'THRESHOLDID': st.column_config.TextColumn(
                help='Identifier for any thresholds set for the test',
                required=True
            ),
            'ENABLEDFLAG': st.column_config.SelectboxColumn(
                options=['OFF', 'ON', None],
                help='Indicates if the test is enabled (Y or N)',
                required=True
            ),
            'CRITICALITY': st.column_config.SelectboxColumn(
                options=[1, 2, None],
                help='Indicates the criticality level of the test',
                required=True
            ),
            'FREQUENCYCHECK': st.column_config.NumberColumn(
                help='Frequency of the test execution'
            ),
            'SCHEDULER_FREQ': st.column_config.SelectboxColumn(
                options=['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY'],
                default='DAILY',
                help='Frequency of test execution (e.g., Daily)'
            )
        }
        ,
        disabled=['DSID', 'REESULTSETCOLS', 'RESULTSETCOLNAME'],
        use_container_width=True,
    )


    # Columns containing components to add/duplicate records in the above testplan grid
    add_col, _ = st.columns([1, 7], gap='small')

    with add_col:
        add_new_test = st.button(
            label='➕ :green[Add]',
            use_container_width=True,
            key=f"{tab_key} add new dsid",
            help='Add a new row to the testplan table',
            on_click=add_new_row
        )


    if sst['edited_tp_testplan_df'].empty:
        pass
    else:
        edited_testplan_df = sst['edited_tp_testplan_df']

        # Get the selected records
        selected_testplan_records = edited_testplan_df.loc[edited_testplan_df[''] == True]


        # Get threshold's for tests and display them
        threshold_df = sst['tp_threshold_df']
        with st.expander('Threshold Table', expanded=False):
            # If no records are selected display the full threshold table
            if selected_testplan_records.shape[0] == 0:
                st.dataframe(
                    data=threshold_df,
                    hide_index=True
                )
                threshold_id_status = []

            # Display the threshold's only for the selected tests/records
            else:
                # st.dataframe(threshold_df)
                # Display only those threshold records which have been referenced in selected testplan records THRESHOLDID column
                # List of all threshold ids from threshold table
                all_ids = set(threshold_df['THRESHOLDID'].tolist())

                # Referenced ids
                referred_ids = set()          # all ids that have been referred in selected testplan records
                invalid_referred_ids = set()  # ids that are non integers or doesn't exist in table
                valid_referred_ids = set()    # ids that are ints and exist in table

                # Flag the records which are invalid
                threshold_id_status = []

                for i, row in selected_testplan_records.iterrows():
                    ids = str(row['THRESHOLDID']).strip().split(',')
                    ids = {i.strip() for i in ids}
                    referred_ids.update(ids)

                    flag = True # By default mark all ids entered in THRESHOLDID col as valid
                    for ri in ids:
                        if ri.isdigit() and int(ri) in all_ids:
                            valid_referred_ids.add(int(ri))
                        else:
                            invalid_referred_ids.add(ri)
                            flag = False # Mark the record as invalid if any of the ids are invalid

                    threshold_id_status.append(flag)

                # Show the threshold records which have been properly referenced in testplan table
                st.dataframe(
                    data=threshold_df.loc[threshold_df['THRESHOLDID'].isin(valid_referred_ids)],
                    hide_index=True
                )
                if len(invalid_referred_ids) > 0:
                    st.warning('Incorrect Thresholds found in the selected testplan records')
                    st.write(invalid_referred_ids)

                    logger.warning('Invalid Threshold IDs found in the selected testplan records')
                    # logger.warning(invalid_referred_ids)

        # Components to save the selected testplan records
        if selected_testplan_records.shape[0] == 0:
            pass
        else:
            save_tp_data = selected_testplan_records[threshold_id_status]
            sst['unsaved_testplan_changes'] = save_tp_data.shape[0]

            st.markdown(f"##### :blue[Updated TestPlan Records]")
            if save_tp_data.shape[0] == 0:
                st.info('Testplan records are neither selected nor valid')

            styled_save_tp_data = save_tp_data.style.apply(style_edited_rows, axis=None)
            st.dataframe(
                data=styled_save_tp_data,
                column_order=[
                    'DSID', 'TESTTYPE', 'TESTCASEDESCRIPTION', 'TESTCATEGORY',
                    'SOURCEPRESQL', 'SOURCETESTSCRIPT', 'TARGETPRESQL', 'TARGETTESTSCRIPT',
                    'DS_COVERAGE_OBJECT', 'EXECUTIONSTEP', 'THRESHOLDID', 'RESULTSETCOLS',
                    'RESULTSETCOLNAME', 'ENABLEDFLAG', 'CRITICALITY', 'FREQUENCYCHECK',
                    'SCHEDULER_FREQ'
                ],
                hide_index=True
            )
            save_col, cancel_col, _ = st.columns([1, 1, 6], gap='small')
            with cancel_col:
                on_cancel = st.button('❌ :red[Cancel]', use_container_width=True)
                if on_cancel:
                    sst['tp_testplan_df'] = None
                    sst['tp_testplan_df_key'] = None
                    sst['edited_tp_testplan_df'] = None
                    sst['unsaved_testplan_changes'] = 0


                    st.rerun()
            with save_col:
                submit_update = st.button(
                    label='💾 Save',
                    key=f"{tab_key}_update_job_config",
                    use_container_width=True
                )

            if submit_update:
                # edited_rows.to_csv('jconfig.csv', index=False)
                # Setting selected values in newly added records
                save_tp_data['PRODUCT_ID'] = product_id
                save_tp_data['PRODUCT_DATABASE'] = product_database
                save_tp_data['JOBID'] = job_id
                save_tp_data['JOBNAME'] = job_name
                with st.spinner():
                    status, msg = save_testplan_changes(save_tp_data, product_warehouse)
                if status == 'Success':
                    st.success('Records Successfully Updated')
                    # reload_page('Success', 5)
                    with st.spinner('Reloading in 5 sec'):
                        time.sleep(5)
                        reset_states = [
                            # 'tp_job_config_df', # no need to refresh only the test_design table is effected
                            # 'tp_threshold_df,   # no need to refresh only the test_design table is effected
                            'tp_testplan_df',
                            'tp_testplan_df_key',
                            'edited_tp_testplan_df',
                            'previous_tp_job_id',
                            'unsaved_testplan_changes',
                            'tp_test_results_df'

                        ]
                        for state in reset_states:
                            if sst.get(state) is not None:
                                del sst[state]
                        st.rerun()

                    # st.dataframe(save_tp_data, hide_index=True)
                else:
                    st.warning('The following error occurred while updating the records')
                    st.dataframe(msg['failed_records'], hide_index=True)

