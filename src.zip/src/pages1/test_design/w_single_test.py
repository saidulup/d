

import time
import random
import pandas as pd
import streamlit as st
from loguru import logger
from typing import Literal
from streamlit import session_state as sst

from src.pages.test_design.db import save_single_test, save_thresholds, generate_dsid
from src.pages.test_design.ml import extract_result_columns



from src.pages.data_utils import get_test_plan


def add_new_threshold(kind:Literal['new', 'edit'] = 'new'):
    """insert a empty record into threshold dataframe"""
    if kind == 'new':
        df_state = 'new_test_thresholds_df'
        df_key_state = 'new_test_thresholds_df_key'
        edited_df_state = 'edited_new_test_threshold_df'
    else:
        df_state = 'edit_test_thresholds_df'
        df_key_state = 'edit_test_thresholds_df_key'
        edited_df_state = 'edited_edit_test_threshold_df'

    # Get the current edited dataframe from session state
    edited_df = sst[edited_df_state]

    # add a new row to the edited dataframe
    new_row = {
        '': False,  # Checkbox column
        'THRESHOLDTYPE': None,  # Type of threshold (e.g., NUMBER, PERCENT)
        'MINWARNINGTHRESHOLD': None,  # Minimum warning threshold
        'MAXWARNINGTHRESHOLD': None,  # Maximum warning threshold
        'MINFAILTHRESHOLD': None,  # Minimum fail threshold
        'MAXFAILTHRESHOLD': None,  # Maximum fail threshold
        'FLOORVALUE': None,  # Floor value for the threshold
        'CEILINGVALUE': None,  # Ceiling value for the threshold
    }

    edited_df = pd.concat([edited_df, pd.DataFrame([new_row])], ignore_index=True)

    # Update the session state with the new dataframe
    # sst['edited_new_test_threshold_df'] = edited_df

    sst[df_key_state] = f"{kind}_test_thresholds_df-{random.randrange(0, 1000)}"
    sst[df_state] = edited_df
    logger.info('New threshold added to the edited dataframe')


def parse_threshold_ids(threshold_ids: str | None) -> list[int]:
    """Convert comma-separated string of threshold ids into a list of integers"""
    if threshold_ids is None:
        return []
    threshold_ids = str(threshold_ids).strip().split(',')
    threshold_ids = [i.strip() for i in threshold_ids if i.strip().isdigit()]
    return [int(i) for i in threshold_ids]



@st.dialog(title='Add New Test', width='large')
def add_new_test_dialog(product_objects, product_warehouse, job_id, job_name, threshold_ids, test_categories):
    """Dialog to add a new test to the testplan table"""
    # st.markdown("### Add New Test")
    st.markdown("Fill in the details for the new test below :red[✨ AI]")

    con1 = st.container(
        horizontal=True,
        horizontal_alignment='distribute',
        vertical_alignment='center',
    )

    with con1:
        dsid = None # Generate later no need to generate it here




        test_type = st.selectbox(
            label='Test Type :red[*]',
            options=['SINGLE DATAPOINT', 'MULTI DATAPOINT', 'MINUS QUERY', None],
            help='Type of test to be performed',
            key='new_test_type',
        )



        test_description = st.text_input(
            label='Test Case Description :red[*]',
            help='Description of the test case and its objective',
            key='new_test_description',
        )

        test_category = st.selectbox(
            label='Test Category :red[*]',
            options=test_categories,                help='Category of the test for easier classification',
            key='new_test_category'
        )

    con2 = st.container(
        horizontal=True,
        horizontal_alignment='distribute',
        vertical_alignment='center',
    )

    with con2:
        execution_step = ['POST-CHECK']


        enabled_flag = st.selectbox(
            label='Enabled :red[*]',
            options=['OFF', 'ON', None],
            help='Indicates if the test is enabled (Y or N)',
            key='new_enabled_flag',
        )

        criticality = st.selectbox(
            label='Criticality :red[*]',
            options=[1, 2, None],
            help='Indicates the criticality level of the test',
            key='new_criticality',
        )


        frequency_check = st.number_input(
            label='Frequency Check',
            help='Frequency of the test execution',
            key='new_frequency_check',
            min_value=0,
            value=0,  # Default value
        )

        scheduler_freq = st.selectbox(
            label='Scheduler Freq :red[*]',
            options=['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY'],
            help='Frequency of test execution (e.g., Daily)',
            key='new_scheduler_freq',
        )


    col1, col2 = st.columns(2)

    with col1:

        source_pre_sql = st.text_input(
            label='Source Pre-SQL',
            help='Pre-SQL script for the source table, if required',
            key='new_source_pre_sql',
            placeholder='Enter pre-SQL script for source table'
        )
        source_test_script = st.text_area(
            label='Source Test Script',
            help='Main SQL script for testing on the source table',
            key='new_source_test_script',
            placeholder='Enter main SQL script for source table'
        )

        ds_coverage_object = st.selectbox(
            label='DS Coverage Object :red[*]',
            options=product_objects,
            width='stretch',
            help='Test case supposed to map which target table name',
            key='new_ds_coverage_object',
        )

    with col2:
        target_pre_sql = st.text_input(
            label='Target Pre-SQL',
            help='Pre-SQL script for the target table, if required',
            key='new_target_pre_sql',
            placeholder='Enter pre-SQL script for target table'
        )

        target_test_script = st.text_area(
            label='Target Test Script :red[* ✨ AI]',
            help='Main SQL script for testing on the target table',
            key='new_target_test_script',
            placeholder='Enter main SQL script for target table'
        )


        threshold_ids = st.multiselect(
            label='Threshold IDs',
            options=threshold_ids,
            default=[4],
            help='Select threshold IDs for the test',
            key='new_threshold_ids',
        )

    if sst.get('new_test_thresholds_df') is None:
        df = pd.DataFrame(
            columns=[
                '', 'THRESHOLDTYPE', 'MINWARNINGTHRESHOLD',
               'MAXWARNINGTHRESHOLD', 'MINFAILTHRESHOLD', 'MAXFAILTHRESHOLD',
               'FLOORVALUE', 'CEILINGVALUE'
            ],
        )
        sst['new_test_thresholds_df_key'] = f"new_test_thresholds_df-{random.randrange(0, 1000)}"
        sst['new_test_thresholds_df'] = df


    st.markdown('Thresholds')
    sst['edited_new_test_threshold_df'] = st.data_editor(
        data=sst['new_test_thresholds_df'],
        key=sst['new_test_thresholds_df_key'],
        use_container_width=True,
        hide_index=True,
        column_order=[
            '', 'THRESHOLDTYPE', 'MINWARNINGTHRESHOLD',
            'MAXWARNINGTHRESHOLD', 'MINFAILTHRESHOLD', 'MAXFAILTHRESHOLD',
            'FLOORVALUE', 'CEILINGVALUE'
        ],
        column_config={
            '': st.column_config.CheckboxColumn(),
            'THRESHOLDTYPE': st.column_config.SelectboxColumn(
                label='TYPE',
                options=['NUMBER', 'PERCENT'],
                help='Type of threshold (e.g., NUMBER, PERCENT)'
            ),
            'MINWARNINGTHRESHOLD': st.column_config.NumberColumn(
                label='MINWARN',
                # required=True,
                help='Minimum warning threshold'
            ),
            'MAXWARNINGTHRESHOLD': st.column_config.NumberColumn(
                label='MAXWARN',
                # required=True,
                help='Maximum warning threshold'
            ),
            'MINFAILTHRESHOLD': st.column_config.NumberColumn(
                label='MINFAIL',
                # required=True,
                help='Minimum fail threshold'
            ),
            'MAXFAILTHRESHOLD': st.column_config.NumberColumn(
                label='MAXFAIL',
                # required=True,
                help='Maximum fail threshold'
            ),
            'FLOORVALUE': st.column_config.NumberColumn(
                label='FLOOR',
                # required=True,
                help='Floor value for the threshold'
            ),
            'CEILINGVALUE': st.column_config.NumberColumn(
                label='CEIL',
                # required=True,
                help='Ceiling value for the threshold'
            ),
        },
    )


    con3 = st.container(
        horizontal=True,
        horizontal_alignment='left',
        vertical_alignment='center',
    )
    with con3:
        st.button(
            label='New',
            # use_container_width=True,
            key='new_test_threshold',
            help='Add a new row to the testplan table',
            on_click=add_new_threshold
        )

        cancel_test = st.button(
            label='Cancel',
            # use_container_width=True,
            key='cancel_new_test',
            help='Cancel adding a new test and close the dialog'
        )



        save_test = st.button(
            label='Save',
            # use_container_width=True,
            key='save_new_test',
            help='Save the new test to the testplan table'
        )

    if cancel_test:
        # Reset the session state for new test thresholds
        del_states = [
            'new_test_thresholds_df',
            'new_test_thresholds_df_key',
            'edited_new_test_threshold_df',
        ]
        for state in del_states:
            if sst.get(state) is not None:
                del sst[state]
        st.rerun()

    if save_test:
        # Capture form data into a dict
        data = {
            'JOBID': job_id,
            'JOBNAME': job_name,
            'TESTTYPE': test_type,
            'TESTCASEDESCRIPTION': test_description,
            'TESTCATEGORY': test_category,
            'SOURCEPRESQL': source_pre_sql,
            'SOURCETESTSCRIPT': source_test_script,
            'TARGETPRESQL': target_pre_sql,
            'TARGETTESTSCRIPT': target_test_script,
            'DS_COVERAGE_OBJECT': ds_coverage_object,
            'EXECUTIONSTEP': execution_step,
            'RESULTSETCOLS': None,  # Assuming this is not required for new tests
            'RESULTSETCOLNAME': None,  # Assuming this is not required for new tests
            'ENABLEDFLAG': enabled_flag,
            'CRITICALITY': criticality,
            'FREQUENCYCHECK': frequency_check,
            'SCHEDULER_FREQ': scheduler_freq,
        }

        # Mandatory columns : Non nullable columns
        mandatory_cols = [
            'TESTTYPE', 'TESTCASEDESCRIPTION', 'TESTCATEGORY', 'TARGETTESTSCRIPT',
            'DS_COVERAGE_OBJECT', 'EXECUTIONSTEP', 'ENABLEDFLAG', 'CRITICALITY',
        ]
        # Validate mandatory columns
        for col in mandatory_cols:
            if data[col] is None or data[col] == '':
                st.warning(f"{col} cannot be empty")
                return

        # Make on field in threshold df is null
        selected_thresholds = sst['edited_new_test_threshold_df']
        selected_thresholds = selected_thresholds[selected_thresholds[''] == True]
        if selected_thresholds['THRESHOLDTYPE'].isnull().values.any():
            st.warning("Threshold type cannot be empty. Please select a threshold type for all selected thresholds.")
            return

        with st.spinner('Extracting Result Set Columns using LLMs ...'):
            # Extract column names from the target test script
            if test_type == 'MINUS QUERY':
                col_count, col_names = 1, 'Mismatch_Count'
            else:
                col_count, col_names = extract_result_columns(data['TARGETTESTSCRIPT'])
                if col_count == 0:
                    st.error("✨ AI Validation Failure: Unable to extract columns from the target test script. Please check the SQL syntax.")
                    return None

            data['RESULTSETCOLS'] = col_count
            data['RESULTSETCOLNAME'] = col_names

        with st.spinner('Saving thresholds ...'):
            # Save thresholds
            threshold_ids = threshold_ids if threshold_ids else []
            new_ids = []
            if not selected_thresholds.empty:
                res = save_thresholds(selected_thresholds, product_warehouse)
                if res['status'] != 'Success':
                    st.error(f"Failed to save thresholds: {res['error']}")
                    return None
                else:
                    st.success('Thresholds saved successfully')
                    # Add the ids to the threshold_ids list
                    existing_ids = res['existing_ids']
                    new_ids = res['newly_added_ids']

                    # Update the threshold_ids in the data dict
                    threshold_ids = list(set(threshold_ids + existing_ids + new_ids))

            # Convert threshold ids into a comma-separated string
            data['THRESHOLDID'] = ','.join(map(str, threshold_ids))
            logger.info(f"Saving IDS, {data['THRESHOLDID']}")

        # Save the new test to the database
        with st.spinner('Saving the new test...'):
            data['DSID'] = generate_dsid()
            status, msg = save_single_test(data, product_warehouse)

        if status == 'Success':
            st.success('Test successfully added to the testplan table')
            # reload_page('Success', 5)
            with st.spinner('Reloading in 5 sec'):
                time.sleep(4)
                reset_states = [
                    # 'tp_job_config_df', # no need to refresh only the test_design table is effected
                    # 'tp_threshold_df,   # no need to refresh only the test_design table is effected
                    'tp_testplan_df',
                    'tp_testplan_df_key',
                    'edited_tp_testplan_df',
                    'previous_tp_job_id',
                    'unsaved_testplan_changes',
                    'tp_test_results_df',

                    'new_test_thresholds_df',
                    'new_test_thresholds_df_key',
                    'edited_new_test_threshold_df',

                ]
                # reload thresholds table if new ids are added
                if new_ids:
                    reset_states.append('tp_threshold_df')

                for state in reset_states:
                    if sst.get(state) is not None:
                        del sst[state]
                st.rerun()


@st.dialog(title='Edit Selected Test', width='large')
def edit_selected_test_dialog(product_objects, product_warehouse, job_id, job_name, threshold_ids, test_data, test_categories):
    """Dialog to edit the selected test in the testplan table"""
    st.markdown(f"Edit test: {test_data['DSID']}, :red[✨ AI]")

    con1 = st.container(
        horizontal=True,
        horizontal_alignment='distribute',
        vertical_alignment='center',
    )

    with con1:
        prev_test_type = test_data['TESTTYPE']
        test_type_options = ['SINGLE DATAPOINT', 'MULTI DATAPOINT', 'MINUS QUERY', None]
        test_type_index = test_type_options.index(prev_test_type) if prev_test_type in test_type_options else 0

        test_type = st.selectbox(
            label='Test Type :red[*]',
            options=test_type_options,
            index=test_type_index,
            help='Type of test to be performed',
            key='new_test_type',
        )



        test_description = st.text_input(
            label='Test Case Description :red[*]',
            value=test_data['TESTCASEDESCRIPTION'],
            help='Description of the test case and its objective',
            key='new_test_description',
        )

        prev_test_category = test_data['TESTCATEGORY']
        test_category_options = test_categories
        test_category_index = test_category_options.index(prev_test_category) if prev_test_category in test_category_options else 0
        test_category = st.selectbox(
            label='Test Category :red[*]',
            options=test_category_options,
            index=test_category_index,
            help='Category of the test for easier classification',
            key='new_test_category'
        )

    con2 = st.container(
        horizontal=True,
        horizontal_alignment='distribute',
        vertical_alignment='center',
    )

    with con2:
        execution_step = test_data['EXECUTIONSTEP']

        prev_enabled_flag = test_data['ENABLEDFLAG']
        enabled_flag_options = ['OFF', 'ON']
        enabled_flag_index = enabled_flag_options.index(prev_enabled_flag) if prev_enabled_flag in enabled_flag_options else 0

        enabled_flag = st.selectbox(
            label='Enabled :red[*]',
            options=enabled_flag_options,
            index=enabled_flag_index,
            help='Indicates if the test is enabled (Y or N)',
            key='new_enabled_flag',
        )

        prev_criticality = test_data['CRITICALITY']
        criticality_options = [1, 2, None]
        criticality_index = criticality_options.index(prev_criticality) if prev_criticality in criticality_options else 0

        criticality = st.selectbox(
            label='Criticality :red[*]',
            options=criticality_options,
            index=criticality_index,
            help='Indicates the criticality level of the test',
            key='new_criticality',
        )

        prev_frequency_check = test_data['FREQUENCYCHECK']
        if isinstance(prev_frequency_check, int):
            pass
        elif isinstance(prev_frequency_check, str):
            prev_frequency_check = int(prev_frequency_check) if prev_frequency_check.isdigit() else 0
        else:
            prev_frequency_check = 0

        frequency_check = st.number_input(
            label='Frequency Check',
            help='Frequency of the test execution',
            key='new_frequency_check',
            min_value=0,
            value=prev_frequency_check,  # Default value
        )

        prev_scheduler_freq = test_data['SCHEDULER_FREQ']
        scheduler_freq_options = ['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY']
        scheduler_freq_index = scheduler_freq_options.index(prev_scheduler_freq) if prev_scheduler_freq else 0
        scheduler_freq = st.selectbox(
            label='Scheduler Freq :red[*]',
            options=scheduler_freq_options,
            index=scheduler_freq_index,
            help='Frequency of test execution (e.g., Daily)',
            key='new_scheduler_freq',
        )


    col1, col2 = st.columns(2)

    with col1:

        prev_source_pre_sql = test_data['SOURCEPRESQL'] if test_data['SOURCEPRESQL'] else ''
        source_pre_sql = st.text_input(
            label='Source Pre-SQL',
            help='Pre-SQL script for the source table, if required',
            key='new_source_pre_sql',
            placeholder='Enter pre-SQL script for source table',
            value=prev_source_pre_sql
        )

        prev_test_script = test_data['SOURCETESTSCRIPT'] if test_data['SOURCETESTSCRIPT'] else ''
        source_test_script = st.text_area(
            label='Source Test Script',
            help='Main SQL script for testing on the source table',
            key='new_source_test_script',
            placeholder='Enter main SQL script for source table',
            value=prev_test_script
        )

        prev_ds_coverage_object = test_data['DS_COVERAGE_OBJECT'] if test_data['DS_COVERAGE_OBJECT'] else ''
        ds_coverage_object_options = product_objects
        ds_coverage_object_index = ds_coverage_object_options.index(prev_ds_coverage_object) if prev_ds_coverage_object in ds_coverage_object_options else 0

        ds_coverage_object = st.selectbox(
            label='DS Coverage Object :red[*]',
            options=ds_coverage_object_options,
            index=ds_coverage_object_index,
            width='stretch',
            help='Test case supposed to map which target table name',
            key='new_ds_coverage_object',
        )

    with col2:
        prev_target_pre_sql = test_data['TARGETPRESQL'] if test_data['TARGETPRESQL'] else ''
        target_pre_sql = st.text_input(
            label='Target Pre-SQL',
            help='Pre-SQL script for the target table, if required',
            key='new_target_pre_sql',
            placeholder='Enter pre-SQL script for target table',
            value=prev_target_pre_sql
        )

        prev_target_test_script = test_data['TARGETTESTSCRIPT'] if test_data['TARGETTESTSCRIPT'] else ''
        target_test_script = st.text_area(
            label='Target Test Script :red[* ✨ AI]',
            help='Main SQL script for testing on the target table',
            key='new_target_test_script',
            placeholder='Enter main SQL script for target table',
            value=prev_target_test_script
        )

        prev_threshold_ids = test_data['THRESHOLDID'] if test_data['THRESHOLDID'] else ''
        prev_threshold_ids = parse_threshold_ids(prev_threshold_ids)

        threshold_ids = st.multiselect(
            label='Threshold IDs',
            options=threshold_ids,
            default=prev_threshold_ids,
            help='Select threshold IDs for the test',
            key='new_threshold_ids',
        )

    if sst.get('edit_test_thresholds_df') is None:
        df = pd.DataFrame(
            columns=[
                '', 'THRESHOLDTYPE', 'MINWARNINGTHRESHOLD',
               'MAXWARNINGTHRESHOLD', 'MINFAILTHRESHOLD', 'MAXFAILTHRESHOLD',
               'FLOORVALUE', 'CEILINGVALUE'
            ],
        )
        sst['edit_test_thresholds_df_key'] = f"new_test_thresholds_df-{random.randrange(0, 1000)}"
        sst['edit_test_thresholds_df'] = df

    st.markdown('Thresholds')
    sst['edited_edit_test_threshold_df'] = st.data_editor(
        data=sst['edit_test_thresholds_df'],
        key=sst['edit_test_thresholds_df_key'],
        use_container_width=True,
        hide_index=True,
        column_order=[
            '', 'THRESHOLDTYPE', 'MINWARNINGTHRESHOLD',
            'MAXWARNINGTHRESHOLD', 'MINFAILTHRESHOLD', 'MAXFAILTHRESHOLD',
            'FLOORVALUE', 'CEILINGVALUE'
        ],
        column_config={
            '': st.column_config.CheckboxColumn(),
            'THRESHOLDTYPE': st.column_config.SelectboxColumn(
                label='TYPE',
                options=['NUMBER', 'PERCENT'],
                help='Type of threshold (e.g., NUMBER, PERCENT)'
            ),
            'MINWARNINGTHRESHOLD': st.column_config.NumberColumn(
                label='MINWARN',
                # required=True,
                help='Minimum warning threshold'
            ),
            'MAXWARNINGTHRESHOLD': st.column_config.NumberColumn(
                label='MAXWARN',
                # required=True,
                help='Maximum warning threshold'
            ),
            'MINFAILTHRESHOLD': st.column_config.NumberColumn(
                label='MINFAIL',
                # required=True,
                help='Minimum fail threshold'
            ),
            'MAXFAILTHRESHOLD': st.column_config.NumberColumn(
                label='MAXFAIL',
                # required=True,
                help='Maximum fail threshold'
            ),
            'FLOORVALUE': st.column_config.NumberColumn(
                label='FLOOR',
                # required=True,
                help='Floor value for the threshold'
            ),
            'CEILINGVALUE': st.column_config.NumberColumn(
                label='CEIL',
                # required=True,
                help='Ceiling value for the threshold'
            ),
        },
    )


    con3 = st.container(
        horizontal=True,
        horizontal_alignment='left',
        vertical_alignment='center',
    )

    with con3:
        st.button(
            label='New',
            # use_container_width=True,
            key='edit_existing_test_threshold',
            help='Add a new row to the testplan table',
            on_click=add_new_threshold,
            args=('edit',)  # Pass 'edit' to differentiate from new test
        )

        cancel_test = st.button(
            label='Cancel',
            # use_container_width=True,
            key='cancel_edit_test',
            help='Cancel editing the test and close the dialog'
        )

        save_test = st.button(
            label='Save',
            # use_container_width=True,
            key='save_edit_test',
            help='Save the edited test to the testplan table'
        )


    if cancel_test:
        # Reset the session state for edit test thresholds
        del_states = [
            'edit_test_thresholds_df',
            'edit_test_thresholds_df_key',
            'edited_edit_test_threshold_df',
        ]
        for state in del_states:
            if sst.get(state) is not None:
                del sst[state]
        st.rerun()

    if save_test:
        # Capture form data into a dict
        data = test_data.to_dict()

        data.update({
            'JOBID': job_id,
            'JOBNAME': job_name,
            'TESTTYPE': test_type,
            'TESTCASEDESCRIPTION': test_description,
            'TESTCATEGORY': test_category,
            'SOURCEPRESQL': source_pre_sql,
            'SOURCETESTSCRIPT': source_test_script,
            'TARGETPRESQL': target_pre_sql,
            'TARGETTESTSCRIPT': target_test_script,
            'DS_COVERAGE_OBJECT': ds_coverage_object,
            'EXECUTIONSTEP': execution_step,

            'ENABLEDFLAG': enabled_flag,
            'CRITICALITY': criticality,
            'FREQUENCYCHECK': frequency_check,
            'SCHEDULER_FREQ': scheduler_freq,
        })

        # Mandatory columns : Non nullable columns
        mandatory_cols = [
            'TESTTYPE', 'TESTCASEDESCRIPTION', 'TESTCATEGORY', 'TARGETTESTSCRIPT',
            'DS_COVERAGE_OBJECT', 'EXECUTIONSTEP', 'ENABLEDFLAG', 'CRITICALITY',
        ]
        # Validate mandatory columns
        for col in mandatory_cols:
            if data[col] is None or data[col] == '':
                st.warning(f"{col} cannot be empty")
                return

        # Make on field in threshold df is null
        selected_thresholds = sst['edited_edit_test_threshold_df']
        selected_thresholds = selected_thresholds[selected_thresholds[''] == True]
        if selected_thresholds['THRESHOLDTYPE'].isnull().values.any():
            st.warning('Threshold type cannot be empty')
            return

        with st.spinner('Extracting Result Set Columns using LLMs ...'):
            # Extract column names from the target test script
            if test_type == 'MINUS QUERY':
                col_count, col_names = 1, 'Mismatch_Count'
            else:
                col_count, col_names = extract_result_columns(data['TARGETTESTSCRIPT'])
                if col_count == 0:
                    st.error("✨ AI Validation Failure: Unable to extract columns from the target test script. Please check the SQL syntax.")
                    return None

            data['RESULTSETCOLS'] = col_count
            data['RESULTSETCOLNAME'] = col_names

        with st.spinner('Saving thresholds ...'):
            # Save thresholds
            threshold_ids = threshold_ids if threshold_ids else []
            new_ids = []
            if not selected_thresholds.empty:
                res = save_thresholds(selected_thresholds, product_warehouse)
                if res['status'] != 'Success':
                    st.error(f"Failed to save thresholds: {res['error']}")
                    return None
                else:
                    st.success('Thresholds saved successfully')
                    # Add the ids to the threshold_ids list
                    existing_ids = res['existing_ids']
                    new_ids = res['newly_added_ids']

                    # Update the threshold_ids in the data dict
                    threshold_ids = list(set(threshold_ids + existing_ids + new_ids))


            # Convert threshold ids into a comma-separated string
            data['THRESHOLDID'] = ','.join(map(str, threshold_ids))
            logger.info(f"Saving IDS, {data['THRESHOLDID']}")

        # Save the edited test to the database
        with st.spinner('Saving the edited test...'):
            status, msg = save_single_test(data, product_warehouse)
        if status == 'Success':
            st.success('Test successfully updated in the testplan table')
            # reload_page('Success', 5)
            with st.spinner('Reloading in 5 sec'):
                time.sleep(5)
                reset_states = [
                    'tp_testplan_df',
                    'tp_testplan_df_key',
                    'edited_tp_testplan_df',
                    'previous_tp_job_id',
                    'unsaved_testplan_changes',
                    'tp_test_results_df',
                    'tp_threshold_df',

                    'edit_test_thresholds_df',
                    'edit_test_thresholds_df_key',
                    'edited_edit_test_threshold_df',


                ]

                # reload thresholds table if new ids are added
                if new_ids:
                    reset_states.append('tp_threshold_df')

                for state in reset_states:
                    if sst.get(state) is not None:
                        del sst[state]
                st.rerun()



@st.fragment()
def single_test_management_widget(product_id, product_database, product_warehouse, product_objects, job_id, job_name, test_categories, tab_key):
    """Widget to manage single test"""
    # Reload testplan table, page loads for first time, job id is changed, cancel button is clicked
    if sst.get('tp_testplan_df') is None:
        logger.info("Loading Testplan table from DB")
        testplan_df = get_test_plan(job_id, product_warehouse)

        # Convert DSID to string for consistency
        testplan_df['DSID'] = testplan_df['DSID'].astype(str)

        # Mark all records as 'edited' if the testplan table is not empty
        if not testplan_df.empty:
            testplan_df['COLOR_FLAG'] = 'edited'

        testplan_df.insert(0, '', False)
        sst['tp_testplan_df'] = testplan_df
        sst['tp_testplan_df_key'] = f"{tab_key}-tp edit grid-{random.randrange(0, 1000)}"

    # Display the testplan table as a grid and allow user to select records
    edited_testplan_df = st.data_editor(
        data=sst['tp_testplan_df'],
        key=sst['tp_testplan_df_key'],
        hide_index=True,
        column_order=[
            '', 'DSID', 'TESTTYPE',
            'TESTCASEDESCRIPTION', 'TESTCATEGORY',
            'SOURCEPRESQL', 'SOURCETESTSCRIPT',
            'TARGETPRESQL', 'TARGETTESTSCRIPT',

            'DS_COVERAGE_OBJECT', 'THRESHOLDID',
            'EXECUTIONSTEP',
            'ENABLEDFLAG', 'CRITICALITY',
            'FREQUENCYCHECK', 'SCHEDULER_FREQ',
            'RESULTSETCOLS', 'RESULTSETCOLNAME'
        ],
        use_container_width=True,
        disabled=[
            'DSID', 'TESTTYPE',
            'TESTCASEDESCRIPTION', 'TESTCATEGORY',
            'SOURCEPRESQL', 'SOURCETESTSCRIPT',
            'TARGETPRESQL', 'TARGETTESTSCRIPT',

            'DS_COVERAGE_OBJECT', 'THRESHOLDID',
            'EXECUTIONSTEP',
            'ENABLEDFLAG', 'CRITICALITY',
            'FREQUENCYCHECK', 'SCHEDULER_FREQ',
            'RESULTSETCOLS', 'RESULTSETCOLNAME'
        ]
    )

    add_test_col, edit_test_col, _ = st.columns([1, 1, 7], gap='small')

    with add_test_col:
        add_test = st.button(
            label='➕ :green[Add]',
            use_container_width=True,
            key=f"{tab_key} new test popup",
            help='Add a new row to the testplan table',
        )

    with edit_test_col:
        edit_test = st.button(
            label='✏️ :blue[Edit]',
            use_container_width=True,
            key=f"{tab_key} edit selected test",
            help='Edit the selected test in the testplan table'
        )

    if add_test:
        threshold_ids = sst['tp_threshold_df']['THRESHOLDID'].tolist()
        add_new_test_dialog(product_objects, product_warehouse, job_id, job_name, threshold_ids, test_categories)

    if edit_test:
        # Get the selected records
        selected_testplan_records = edited_testplan_df.loc[edited_testplan_df[''] == True]

        if selected_testplan_records.shape[0] == 0:
            st.warning('No test selected for editing')
            return

        if selected_testplan_records.shape[0] > 1:
            st.warning('Please select only one test for editing')
            return

        # Get the first record to edit
        test_data = selected_testplan_records.iloc[0]

        # Get threshold's for tests and display them
        threshold_ids = sst['tp_threshold_df']['THRESHOLDID'].tolist()
        edit_selected_test_dialog(product_objects, product_warehouse, job_id, job_name, threshold_ids, test_data, test_categories)



