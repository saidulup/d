

import os
from openai import OpenAI, AzureOpenAI
from datetime import date
from enum import StrEnum
from abc import ABC, abstractmethod
import streamlit as st
import requests


# Enums
class LLMProviders(StrEnum):
    OPENAI = "openai"
    AZURE_OPENAI = "azure_openai"
    GOOGLE = "google"
    ANTHROPIC = "anthropic"

class LLM:
    def __init__(self, provider: LLMProviders, name: str, version: str, context: int, release_date: date, input_token_price: float, cached_input_token_price: float, output_token_price: float):
        """

        :param provider:  LLMProviders
        :param name:  Class of the model
        :param version:  Complete model name-version
        :param context:  Context length in K tokens (e.g., 8K, 32K)
        :param input_token_price:  Price per million input tokens in USD Example: 0.0004
        :param output_token_price: Price per million output tokens in USD Example: 0.0004
        """
        self.provider = provider
        self.name = name
        self.version = version
        self.context = context
        self.input_token_price = input_token_price
        self.cached_input_token_price = cached_input_token_price
        self.output_token_price = output_token_price
        self.release_date  = release_date


class LLMProvider(ABC):
    """
    Abstract base class for LLM providers.
    """
    # Store only the active models and their metadata
    models: dict[str, LLM] = {}
    default_model: LLM = None # The model to use when requested model is absent or not supported

    @abstractmethod
    def get_model(self, model_name: str) -> LLM:
        """
        Get a model by its name.
        :param model_name: Name of the model to retrieve.
        :return: LanguageModel instance.
        """
        pass

    @abstractmethod
    def get_models(self) -> list[str]:
        """
        Get all available models.
        :return: Dictionary of model names to LanguageModel instances.
        """
        pass

    @abstractmethod
    def get_default_model(self) -> str:
        """
        Get the default model.
        :return: LanguageModel instance.
        """
        pass

    @abstractmethod
    def _get_api_key(self) -> str:
        """
        Get the API key for the LLM provider.
        :return: API key as a string.
        """
        pass

    @abstractmethod
    def initialize_client(self):
        """Create and add client to a pool or singleton."""
        ...

    @abstractmethod
    def get_client(self):
        """Get client from a pool or singleton."""
        ...

    @abstractmethod
    def get_completions(self, model:str, context: list, tokens: int, temp: float) -> (bool, str):
        pass



class OpenAIProvider(LLMProvider):
    def __init__(self):

        # Set gpt-4o-mini as
        gpt_4o_mini = LLM(LLMProviders.OPENAI, "gpt-4o-mini", "gpt-4o-mini", 8, date(2024, 7, 18), 0.15, 0.075, 0.60)
        self.models: dict[str, LLM] = {}
        self.default_model: LLM = gpt_4o_mini  # The model to use when requested model is absent or not supported

        self.models[gpt_4o_mini.name] = gpt_4o_mini

        # client related
        self.client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
        self.initialize_client()


    def get_model(self, model_name: str) -> LLM:
        """
        Get a model by its name.
        :param model_name: Name of the model to retrieve.
        :return: LanguageModel instance.
        """
        return self.models.get(model_name, self.default_model)

    def get_models(self) -> list[str]:
        """
        Get all available models.
        :return: Dictionary of model names to LanguageModel instances.
        """
        return list(self.models.keys())

    def get_default_model(self) -> str:
        """
        Get the default model.
        :return: LanguageModel instance.
        """
        return self.default_model.name

    def _get_api_key(self) -> str:
        return os.getenv('OPENAI_API_KEY', '')

    def initialize_client(self):
        """
        Create and add client to a pool or singleton.
        This method is not used in this implementation but can be overridden in subclasses.
        """

        api_key = self._get_api_key()
        client = OpenAI(api_key=api_key)
        self.client = client

    def get_client(self):
        """
        Get client from a pool or singleton.
        This method is not used in this implementation but can be overridden in subclasses.
        """
        return self.client


    def get_completions(self, model:str, context: list, tokens:int, temp:float) -> (bool, str):
        try:
            # If model doesn't exist use the default model
            if model not in self.models:
                model = self.default_model.name


            client = self.get_client()

            response = client.chat.completions.create(
                model=model,
                messages=context,
                max_tokens=tokens,
                temperature=temp,
                n=1,
            )
            return True, response.choices[0].message.content
        except Exception as e:
            return False, 'LLM Request failed with error: ' + str(e)


class AzureOpenAIProvider(LLMProvider):
    def __init__(self):
        gpt_4o_mini = LLM(LLMProviders.OPENAI, "gpt-4o-mini", "gpt-4o-mini", 8, date(2024, 7, 18), 0.15, 0.075, 0.60)
        self.models: dict[str, LLM] = {}
        self.default_model: LLM = gpt_4o_mini  # The model to use when requested model is absent or not supported

        self.models[gpt_4o_mini.name] = gpt_4o_mini

        # Initialize Azure OpenAI client
        self.client = AzureOpenAI(
            azure_endpoint=os.getenv('AZURE_OPENAI_ENDPOINT'),
            api_version=os.getenv('AZURE_OPENAI_API_VERSION'),
            azure_deployment=os.getenv('AZURE_OPENAI_DEPLOYMENT'),
            azure_ad_token=os.getenv('AZURE_OPENAI_ACCESS_TOKEN'),
            default_headers={
                "projectId": "",
            }
        )
        self.initialize_client()

    def get_model(self, model_name: str) -> LLM:
        return self.models.get(model_name, self.default_model)

    def get_models(self) -> list[str]:
        return list(self.models.keys())

    def get_default_model(self) -> str:
        return self.default_model.name if self.default_model else None

    def _get_api_key(self) -> str:
        # Chat Completion with HCP App Identity:
        # Please update the values of client_id and client_secret in the below code.



        # Define the authentication URL and credentials.
        auth = "https://api.uhg.com/oauth2/token"
        # Note: Stage HCP App Identity will not support for production gateway.
        # auth = "https://api-stg.uhg.com/oauth2/token"
        scope = "https://api.uhg.com/.default"
        grant_type = "client_credentials"

        # Use an asynchronous client to make a POST request to the auth URL.
        body = {
            "grant_type": grant_type,
            "scope": scope,
            "client_id": "7a6c79a1-b563-438c-9780-eb1bc7e15edb",
            "client_secret": os.getenv('AZURE_OPENAI_CLIENT_SECRET'),
        }
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        resp = requests.post(auth, headers=headers, data=body, timeout=60)
        access_token = resp.json()["access_token"]
        return access_token

    def initialize_client(self):
        """
        Create and add client to a pool or singleton.
        This method is not used in this implementation but can be overridden in subclasses.
        """

        access_token = self._get_api_key()
        self.client = AzureOpenAI(
            azure_endpoint=os.getenv('AZURE_OPENAI_ENDPOINT'),
            api_version=os.getenv('AZURE_OPENAI_API_VERSION'),
            azure_deployment=os.getenv('AZURE_OPENAI_DEPLOYMENT'),
            azure_ad_token=access_token,
            default_headers={
                "projectId": os.getenv('AZURE_OPENAI_PROJECT_ID', ''),
            }
        )

    def get_client(self):
        return self.client

    def get_completions(self, model:str, context: list, tokens:int, temp:float) -> (bool, str):
        try:
            response = self.client.chat.completions.create(
                model='gpt-5-chat',
                messages=context,
                #max_tokens=tokens,
                temperature=temp,
                n=1,
            )
            return True, response.choices[0].message.content
        except Exception as e:
            return False, 'LLM Request failed with error: ' + str(e)


class LLMFactory:
    """
    Factory class to create instances of LLM providers.
    """

    @staticmethod
    #@st.cache_resource(ttl=300)
    def get_provider(provider: str) -> LLMProvider:
        """
        Get an instance of the specified LLM provider.
        :param provider: LLMProviders enum value.
        :return: Instance of the specified LLMProvider.
        """
        provider = LLMProviders(provider)
        if provider == LLMProviders.OPENAI:
            return OpenAIProvider()
        elif provider == LLMProviders.AZURE_OPENAI:
            return AzureOpenAIProvider()
        # Add other providers as needed
        else:
            raise ValueError(f"Unsupported provider: {provider}")


if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv('../core/prod.env')
    # Example usage
    openai_provider = LLMFactory.get_provider(LLMProviders.AZURE_OPENAI)

    model = openai_provider.get_model("gpt-5-chat")

    # Example completion request
    success, response = openai_provider.get_completions(
        model=model.name,
        context=[{"role": "user", "content": "Hello, how are you?"}],
        tokens=50,
        temp=0.7
    )
    print("Success:", success)
    print("Response:", response)
