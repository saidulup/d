

import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import streamlit as st


def dispatch_mail(subject:str, body:str, to):
    try:
        email = os.environ.get('EMAIL')
        email_password = os.environ.get('EMAIL_PASSWORD')
        email_server = os.environ.get('EMAIL_HOST')
        email_port = os.environ.get('EMAIL_PORT')

        message = MIMEMultipart()
        message['From'] = email
        message['To'] = ', '.join(to) if isinstance(to, list) else to

        message.add_header("x-EnterpriseClinical", "Yes")
        message['Subject'] = subject
        message.attach(MIMEText(body, 'html'))
        message = message.as_string()

        #conn = smtplib.SMTP(email_server,port=int(email_port))
        conn = smtplib.SMTP(email_server)
        #conn.starttls()
        #conn.login(user=email, password=email_password)

        status = conn.sendmail(from_addr=email, to_addrs=to, msg=message)

        conn.close()
        return True
    except Exception as e:
        print(f'An error occurred while sending one of the mails , Error is {e}')
        st.write(e)
        return False

